#include "gdiconfig.h"

VOID WINAPI gradientT(HDC hdc, int x1, int y1, int x2, int y2, int x3, int y3) {
	TRIVERTEX vertex[3];
	vertex[0].x = x1; vertex[0].y = y1; vertex[0].Red = 0xFFF0; vertex[0].Green = 0x0000; vertex[0].Blue = 0x0000; vertex[0].Alpha = 0x0000;
	vertex[1].x = x2; vertex[1].y = y2; vertex[1].Red = 0xCFF0; vertex[1].Green = 0x0000; vertex[1].Blue = 0xCFF0; vertex[1].Alpha = 0x0000;
	vertex[2].x = x3; vertex[2].y = y3; vertex[2].Red = 0x0000; vertex[2].Green = 0x0000; vertex[2].Blue = 0xFFF0; vertex[2].Alpha = 0x0000;
	GRADIENT_TRIANGLE gTriangle; gTriangle.Vertex1 = 0; gTriangle.Vertex2 = 1; gTriangle.Vertex3 = 2;
	GradientFill(hdc, vertex, 3, &gTriangle, 1, GRADIENT_FILL_TRIANGLE);
}

VOID WINAPI gradientR(HDC hdc, int x1, int y1, int x2, int y2) {
	TRIVERTEX vertex[2];
	vertex[0].x = x1; vertex[0].y = y1; vertex[0].Red = 0xFFF0; vertex[0].Green = 0x0000; vertex[0].Blue = 0x0000; vertex[0].Alpha = 0x0000;
	vertex[1].x = x2; vertex[1].y = y2; vertex[1].Red = 0x0000; vertex[1].Green = 0x0000; vertex[1].Blue = 0xFFF0; vertex[1].Alpha = 0x0000;
	GRADIENT_RECT gRect; gRect.UpperLeft = 0; gRect.LowerRight = 1;
	GradientFill(hdc, vertex, 2, &gRect, 1, GRADIENT_FILL_RECT_H);
}

void GradientCube(HDC hdc, int x, int y, int Prism_height) {
	int f = Prism_height;
    // Back face
    gradientR(hdc, x, y, 100+x, 100+y);
    // Front face
    gradientR(hdc, f+x, f+y, 100+f+x, 100+f+y);
	// Connect front and back faces
	gradientT(hdc, f+x, 100+f+y, f+x, 100+y, x, 100+y);
    gradientT(hdc, 100+f+x, f+y, 100+x, f+y, 100+x, y);
    MoveToEx(hdc, x, y, 0);
    LineTo(hdc, x+f, y+f);
}

void GradientPrism(HDC hdc, int x, int y, int size) {
int s = size;
gradientT(hdc, x, y+(30*s), x+(25*s), y, x+(25*s), y+(40*s));
gradientT(hdc, x+(25*s), y, x+(25*s), y+(40*s), x+(50*s), y+(30*s));
gradientT(hdc, x+(25*s), y+(60*s), x+(25*s), y+(40*s), x, y+(30*s));
gradientT(hdc, x+(25*s), y+(60*s), x+(50*s), y+(30*s), x+(25*s), y+(40*s));
}

void InvertCircle(HDC hdc, int x, int y, int x2, int y2, int w, int h, int IfDARK) {
    HDC hcdc = CreateCompatibleDC(hdc);
    HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hbm);
	Ellipse(hcdc, x, y, x2, y2);
    if (IfDARK == true) {
    BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
	} else {
	BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCINVERT);
	}
	DeleteDC(hcdc); DeleteObject(hbm);
}

VOID WINAPI SplitBlt(HDC hcdc, HDC hcdc2, int s, int w, int h, DWORD SRC) {
    BitBlt(hcdc, w/2+s, 0, w/2, h/2, hcdc2, w/2, s, SRC);
    BitBlt(hcdc, w/2+s, h/2+s, w/2, h/2, hcdc2, w/2, h/2, SRC);
    BitBlt(hcdc, 0, 0, w/2, h/2, hcdc2, s, s, SRC);
    BitBlt(hcdc, 0, h/2+s, w/2, h/2, hcdc2, s, h/2, SRC);
}

DWORD WINAPI payload1(LPVOID lpParam)
{
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        if (!i)RedrawWindow(0, 0, 0, 133);
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, 0x330008);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = randy()%0xff;
        for (int i = 0; w * h > i; i++) {
            if (i % h == 0 && randy() % 100 == 0)
                v = randy() % 50;
            ((BYTE*)(data + i))[v % 3] += ((BYTE*)(data + i + v))[v] ^ byte;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, randy() % 3 - 1, randy() % 3 - 1, w, h, hdcdc, 0, 0, 0xCC0020);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
} 

DWORD WINAPI payload8in(LPVOID lpParam)
{
	int time = GetTickCount(); HWND wnd = GetDesktopWindow();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    double angle = 0;
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, 4 * h * w, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 10)
            byte = randy()%0xff;
        for (int i = 0; w * h > i; ++i) {
            if (!(i % h) && !(randy() % 110))
                v = randy() % 24;
            *((BYTE*)data + 4 * i + v) -= 5;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
    	HDC hcdc = CreateCompatibleDC(desk);
		HBITMAP hbm2 = CreateCompatibleBitmap(desk, w, h);
        SelectObject(hcdc, hbm2);
        BitBlt(hcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        for (float z = 0; z < w + h; z += 0.99f) {
			int a = sin(angle) * 20;
			BitBlt(hcdc, 0, z, w, 1, hcdc, a, z, SRCCOPY);
			BitBlt(hcdc, z, 0, 1, h, hcdc, z, a, SRCCOPY);
			angle += M_PI / 40;
			DeleteObject(&z); DeleteObject(&a);
		}
        BitBlt(desk, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm); DeleteObject(hbm2);
        DeleteObject(hdcdc); DeleteObject(hcdc);
        DeleteObject(desk);
    }
}
VOID WINAPI audio1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(int(cbrt(cos((t*(2+(t>>11|t>>12)%10))/41))*(16+(t>>8&42)))+int(sin((t*t*t/9)/41)*10)+70);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI o1(LPVOID lpParam)
{
	int time = GetTickCount(); HWND wnd = GetDesktopWindow();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    int s = 20; //speed
    while (1) {
    	hdc = GetDC(0);
    	HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hbm2 = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hbm2);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hcdc, rand() % s, rand() % s, rand() % w, rand() % h, hcdc, rand() % s, rand() % s, SRCINVERT);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm2); DeleteObject(hcdc);
        DeleteObject(hdc); ReleaseDC(0, hdc);
    }
}

VOID WINAPI audio2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t<<t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI o2(LPVOID lpParam) //pixelate effect again
{
	int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    while (1) {
    	hdc = GetDC(0);
    	HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hbm2 = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hbm2);
        StretchBlt(hcdc, 0, 0, w/2, h/2, hdc, 0, 0, w, h, SRCCOPY);
        StretchBlt(hdc, 0, 0, w, h, hcdc, 0, 0, w/2, h/2, SRCCOPY);
        DeleteObject(hbm2); DeleteObject(hcdc);
        DeleteObject(hdc); ReleaseDC(0, hdc);
    }
}

DWORD WINAPI o3(LPVOID lpParam)
{
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int CODE = x^y;
			rgbScreen[i].rgb = Hue(239)-((CODE*ii)%255);
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

DWORD WINAPI gg(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 6;
    int x = 10;
    int y = 10;
    while (1) {
        HDC hdc = CreateDC(TEXT("DISPLAY"),NULL,NULL,NULL);
        x += incrementor * signX;
        y += incrementor * signY;
    	GradientCube(hdc, w-x, y, 40);
        if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
            signY = -1;
        }

        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -1;
        }

        if (y <= 0)
        {
            signY = 1;
        }

        if (x <= 0)
        {
            signX = 1;
        }
        Sleep(4);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI o4(LPVOID lpParam)
{
    int screenW = GetSystemMetrics(0), screenH = GetSystemMetrics(1);
    while (1) {
    	HDC hdc = GetDC(0);
        HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, screenW, screenH);
        SelectObject(hcdc, hBitmap);
    	StretchBlt(hcdc, -10, -10, screenW + 20, screenH + 20, hdc, 0, 0, screenW, screenH, SRCCOPY);
    	StretchBlt(hcdc, -10, -10, screenW + 20, screenH + 20, hcdc, 0, 0, screenW, screenH, SRCINVERT);
        BLENDFUNCTION blf = BLENDFUNCTION {AC_SRC_OVER, 1, 20, 0};
        AlphaBlend(hdc, 0, 0, screenW, screenH, hcdc, 0, 0, screenW, screenH, blf);
        DeleteObject(hcdc);
        DeleteObject(hBitmap);
    	ReleaseDC(0, hdc);

	}
	return 0;
}

VOID WINAPI audio3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(int(64*sqrt(tan(t*((t>>10)*10&30)/41))+64)|0);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI o5(LPVOID lpParam)
{
    int screenW = GetSystemMetrics(0), screenH = GetSystemMetrics(1);
    int w = screenW, h = screenH;
	int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 6;
    int x = 10;
    int y = 10;
    double a = 0;
    while (1) {
    	HDC hdc = GetDC(0);
        x += incrementor * signX + cos(a)*15;
        y += incrementor * signY + sin(a)*15;
        a += M_PI / 20;
    	StretchBlt(hdc, x, y, screenW/6, screenH/6, hdc, 0, 0, screenW, screenH, SRCCOPY);
    	if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
            signY = -1;
        }

        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -1;
        }

        if (y <= 0)
        {
            signY = 1;
        }

        if (x <= 0)
        {
            signX = 1;
        }
    	ReleaseDC(0, hdc);

	}
	return 0;
}

DWORD WINAPI o5d1(LPVOID lpParam)
{
    int screenW = GetSystemMetrics(0), screenH = GetSystemMetrics(1);
    while (1) {
    	HDC hdc = GetDC(0);
        HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, screenW, screenH);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, screenW, screenH, hdc, 0, 0, SRCCOPY);
    	BitBlt(hcdc, 4, 4, screenW, screenH, hcdc, 0, 0, 0x111111);
        BLENDFUNCTION blf = BLENDFUNCTION {AC_SRC_OVER, 1, 20, 0};
        AlphaBlend(hdc, 0, 0, screenW, screenH, hcdc, 0, 0, screenW, screenH, blf);
        DeleteDC(hcdc); DeleteObject(hBitmap); ReleaseDC(0, hdc);

	}
	return 0;
}

DWORD WINAPI o6(LPVOID lpParam)
{
    int screenW = GetSystemMetrics(0), screenH = GetSystemMetrics(1);
    while (1) {
    	int h = rand()*M_PI/3;
    	HDC hdc = GetDC(0);
    	if (h%3==2){
		StretchBlt(hdc, 0, 1, screenW-1, screenH, hdc, 0, 0, screenW, screenH, NOTSRCERASE);
		} else { if (h%4==3) {
		StretchBlt(hdc, -10, -10, screenW + 20, screenH + 20, hdc, 0, 0, screenW, screenH, SRCINVERT);}
		else {
		StretchBlt(hdc, rand()%-screenW/2, 0, rand()%screenW*2, screenH, hdc, 0, 0, screenW, screenH, SRCPAINT);
		StretchBlt(hdc, rand()%-screenW/2, 0, rand()%screenW*2, screenH, hdc, 0, 0, screenW, screenH, SRCAND);
		}}
    	ReleaseDC(0, hdc);
    	Sleep(50);

	}
	return 0;
}

VOID WINAPI audio4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t*((42&(t>>10&5+t>>12)|33)-20)>>(t<<(t>>10&234)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(((t/800|10)*t&85)-t&t/4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>((t>>13)*128>>t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(127&t*(10&t>>8&t/8));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI o7(LPVOID lpParam)
{
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			INT c=max(752,Hue(239));
			rgbScreen[i].rgb = c;
		} ii++;
		StretchBlt(hdcScreen, rand()%w, rand()%h, rand()%w, rand()%h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(64*((t>>9^t/512-1^1)%13*t/10));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI o8(LPVOID lpParam)
{
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
		StretchBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, w, h, SRCCOPY);
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int fx = ((x^y)+x^(x^y)-x)+3000;
			int fy = ((x^y)+y^(x^y)-y)+3000;
			rgbScreen[i].rgb += fx^fy;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		Sleep(10);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 48000, 48000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[48000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t*t*t/6+(t*t>>5*t^61));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI o9(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
		StretchBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, w, h, SRCCOPY);
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int dx = ((((x^10)&x/2)&((x^5)&x))*x|y)<<x;
			int dy = ((((y^10)&y/2)&((y^5)&y))*y|x)<<y;
			rgbScreen[i].rgb += dx+dy;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		Sleep(50);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t>>(t<<t>>(t<<t))>>(t>>(t>>t)<<t>>(t>>t))<<(t>>t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI o10(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
		StretchBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, w, h, SRCCOPY);
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int fx = ((x^y)+x^(x^y)-x)+3000;
			int fy = ((x^y)+y^(x^y)-y)+3000;
			int dx = ((((x^10)&x/2)&((x^5)&x))*x|y)<<x;
			int dy = ((((y^10)&y/2)&((y^5)&y))*y|x)<<y;
			rgbScreen[i].rgb += dx^fx+dy^fy;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

DWORD WINAPI synth(LPVOID lpParam) {
    int screenW = GetSystemMetrics(0), screenH = GetSystemMetrics(1);
	int x = 0, y = 0, s = screenH/2; double a = 0;
    while (1) {
    	HDC hdc = GetDC(0);
        x+=5; y = s+(sin(a)*s/5*4); a += M_PI/40;
    	BitBlt(hdc, x, y, 50, 50, hdc, 0, 0, BLACKNESS);
    	BitBlt(hdc, screenW-x, screenH-y, 50, 50, hdc, 0, 0, WHITENESS);
		if (x >= screenW) {a=0,y=s,x=5;} ReleaseDC(0, hdc);
	}
}

DWORD WINAPI o11(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int i = 0;
    while (1) {
    	HDC hdc = GetDC(0);
    	i++;
    	SplitBlt(hdc, hdc, cos(i)*10, w, h, SRCCOPY);
    	HBRUSH brush = CreateSolidBrush(RGB(rand()%80+125,rand()%125+100,rand()%125+100));
    	SelectObject(hdc, brush);
    	PatBlt(hdc, 0, 0, w, h, PATINVERT);
    	BitBlt(hdc, rand()%2, rand()%2, w, h, hdc, rand()%2, rand()%2, SRCAND);
    	DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}

DWORD WINAPI o12(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
		StretchBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, w, h, SRCCOPY);
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += RGB(x+10,x,x-10)^y;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t<<t|t>>t)&(t>>t>>t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 13000, 13000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[13000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t>>10|t>>9|t>>4)&(t*t/4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI rfresh() {
	Sleep(50);
	InvalidateRect(0,0,0);
	Sleep(50);
}

DWORD WINAPI o13(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    while (1) {
    	HDC hdc = GetDC(0);
    	SplitBlt(hdc, hdc, 1, w, h, SRCINVERT);
		ReleaseDC(0, hdc);
	}
}

DWORD WINAPI bg(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 3;
    int x = 10;
    int y = 10;
    while (1) {
        HDC hdc = CreateDC(TEXT("DISPLAY"),NULL,NULL,NULL);
        x += incrementor * signX;
        y += incrementor * signY;
    	GradientPrism(hdc, x, y, 3);
        if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
            signY = -1;
        }

        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -1;
        }

        if (y <= 0)
        {
            signY = 1;
        }

        if (x <= 0)
        {
            signX = 1;
        }
        Sleep(4);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI ng(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int x = 10;
    int y = 10;
    int i = 0;
    while (1) {
        HDC hdc = CreateDC(TEXT("DISPLAY"),NULL,NULL,NULL);
        x += incrementor * signX + sin(i/5)*30;
        y += incrementor * signY + cos(i/2)*15;
    	InvertCircle(hdc, x-50, y-50, x+50, y+50, w, h, false);
        if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
            signY = -1;
        }

        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -1;
        }

        if (y <= 0)
        {
            signY = 1;
        }

        if (x <= 0)
        {
            signX = 1;
        }
        Sleep(4);
        ReleaseDC(0, hdc);
        i++;
    }
}

VOID WINAPI audio13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 60] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t>>17>14?0:t>>17==5||t>>17>11?(t*(t>>16&1?t>>15&1?36:38:t>>15&1?32:27)/((2-(2523490710>>t/1024&1))*(t>1E6?3:6))&(t>>17>13?96:192))-(t>>17>12?0:t>>11&t&15):(37649&1<<(t>>10&15)?int(((t+314)*128/((t>>5&31)+1)&255)/85)*85:0)|(t>>17?(((t*(t>>16&1?t>>15&1?36:38:t>>15&1?32:27)/(t>78E4?((2-(2523490710>>t/1024&1))*(t>>17>7?3:6)):12))&192)+(t>>18?t&15:0))*(128+(t>>18?t>>6&127:0))/128-(t>4E5?t>>11&15:0):0));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 60] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(((t*(t&16384?7:5)*(3-(3&t>>9)+(3&t>>(-t>>20&1?8:11)))>>(3&-t>>(t&(-t&57344?4096:6144)?2:16))|(-t&24576?(3*t>>5)%192:(t>>4)%192)|(t>>20&1?t>>4:t>>(-t>>18&1)+2))/2&127)-(t>>18&1?(-t/2*(t&16384?7:5)>>(-t>>10&3)&t>>4&255)/2:(-t>>2)*(t&16384?7:5)>>(-t>>10&3)&(t>>5&127))+(128&int(4E4/(1+t%((-t&28672?2:1)*2048))))+(t>>18&3&&-(t*(t^t%9)&255&-(t>>(t>>11&31?(-t&14336?5:4)-!(-t&28672)-!(-t&122880):6))<<2&255)>>2)+128);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 45] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(abs(t*(42&t>>10|t>>13)%256-128)*199/100);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 45] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(abs(t/2*(21&t>>10|t>>11|t>>12)%256-128)*199/100);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI g1(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		rgbScreen[i].rgb = (x*y)^(y*y)+(w-x-y)*ii;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

DWORD WINAPI g2(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		rgbScreen[i].r = -((x*x)&(x*y)+w*ii*2)/512;
		rgbScreen[i].b = ((x*x)|(x*y)+w*ii*2)/512;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

DWORD WINAPI g3(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		rgbScreen[i].rgb = (x*y)^(y*y)-(h/2+y+x)*ii;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

DWORD WINAPI g4(LPVOID lpParam) { //splitquad
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		int code = x^y; //code of rgbquad
		rgbScreen[i].rgb = y/4<<(code*ii/1024);
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>((abs(t/(1+((t>>10&t>>8^t>>7)&53))*((t>>10|t>>8|t>>14)&41))%256-128)*199/100);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI audio18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 60] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>((abs(t/(1+((t>>13&t>>2^t>>8)&126))*((t>>2|t>>7)&127))%256-128)*199/100);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI g5(LPVOID lpParam) { //splitquad
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		int code = (x*x)/10-y; //code of rgbquad
		rgbScreen[i].rgb = y/4<<(code*ii/1024);
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 60] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>((abs(t/(1+((t>>13^t>>10^t>>8)&126))*((t>>10|t>>6|t>>12)&127))%256-128)*199/100);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI g6(LPVOID lpParam) { //splitquad
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		int code = (x*y)^(y*y)+(w-x-y)*ii; //code of rgbquad
		rgbScreen[i].rgb = y/4<<(code/1024);
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 48000, 48000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[48000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>((255&(t*-(t>>8|t|t>>9|t>>13)^t))/2+64+int(64*sin(1+(5E3/(t&4095)))));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI g7(LPVOID lpParam) { //splitquad
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		int code = (x*x)^(y*y)+(w-(x*4)+y)*ii; //code of rgbquad
		rgbScreen[i].rgb = y/4<<(code/1024);
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio21() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 60] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>((t>>(t>>13&6|t>>8)<<(t>>13&7|t>>8))|1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI g8(LPVOID lpParam) { //splitquad
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		int code = (x*y-h)^(x*y)+(h-x+y)*ii; //code of rgbquad
		rgbScreen[i].rgb = code;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio22() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 60] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(9*t&t>>4|(5*t&t>>7|3*t&t>>8)-2);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI g9(LPVOID lpParam) { //splitquad
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		int code = (x*y-h)^(x*y)+(h-x+y)*ii; //code of rgbquad
		rgbScreen[i].rgb = code;
		} ii++;
		StretchBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio23() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 48000, 48000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[48000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
    buffer[t] = static_cast<char>(t>>t<<t/(1+((t>>12|t>>10)&6)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}


DWORD WINAPI g10(LPVOID lpParam) { //splitquad
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
    	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem,0,0,w,h,hdcScreen,0,0,SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
		INT x = i % w, y = i / w;
		int code = x^y^x/3; //code of rgbquad
		rgbScreen[i].b += y<<(code/1024);
		} ii++;
		SplitBlt(hdcScreen,hdcMem,3,w,h,SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}

VOID WINAPI audio24() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 45] = {};
    for (DWORD s = 0; s < sizeof(buffer); ++s) {
    int t = s/4;
    buffer[s] = static_cast<char>(((t>>1)*(1<<(t>>16&3))*(533515505>>(t>>10)*(t>>11)&7)|t/8)%128+64+int(32*sin(5000/((t&4095)+1))));
	}
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

int WINAPI WinMain(HINSTANCE a, HINSTANCE b, LPSTR c, int d)
{
    if (MessageBoxW(NULL, L"Run?", L"000Terminated000.exe (The New EvilMsgBox.exe)", MB_YESNO | MB_ICONINFORMATION) == IDNO)
        {
            ExitProcess(0);
        }
        else
        {
        	if (MessageBoxW(NULL, L"Terminate dwm For faster gdi? (only for windows 8.1 or below)", L"000Terminated000.exe (The New EvilMsgBox.exe)", MB_YESNO | MB_ICONINFORMATION) == IDYES) {system("taskkill /f /im dwm.exe");}
            HANDLE thread1 = CreateThread(0, 0, payload1, 0, 0, 0);
            MessageBoxA(NULL, "System Information: this messagebox is cursed", "o.exe", MB_CANCELTRYCONTINUE | MB_RTLREADING | MB_TOPMOST | MB_RIGHT | MB_HELP | MB_SYSTEMMODAL | MB_ICONWARNING | MB_DEFMASK | MB_NOFOCUS | MB_MISCMASK);
            TerminateThread(thread1, 0);
            MessageBoxA(NULL, "OOWING, PLEASE SET YOUR PC TO SAFE MODE TO CONTINUE", "o.exe", MB_ICONWARNING | MB_OK);
            Sleep(5000);
            HANDLE t1 = CreateThread(0, 0, o1, 0, 0, 0);
            HANDLE t1t2d1 = CreateThread(0, 0, synth, 0, 0, 0);
            audio1();
            Sleep(30000);
            TerminateThread(t1, 0);
            rfresh();
            HANDLE t2 = CreateThread(0, 0, o2, 0, 0, 0);
            audio2();
            Sleep(30000);
            TerminateThread(t2, 0);
            TerminateThread(t1t2d1, 0);
            rfresh();
            HANDLE t3 = CreateThread(0, 0, o3, 0, 0, 0);
            HANDLE t3d1 = CreateThread(0, 0, gg, 0, 0, 0);
            audio3();
            Sleep(30000);
            TerminateThread(t3, 0);
            TerminateThread(t3d1, 0);
            rfresh();
            HANDLE t4 = CreateThread(0, 0, o4, 0, 0, 0);
            audio4();
            Sleep(30000);
            TerminateThread(t4, 0);
            rfresh();
            HANDLE t5 = CreateThread(0, 0, o5, 0, 0, 0);
			HANDLE t5d1 = CreateThread(0, 0, o5d1, 0, 0, 0);
			audio5();
			Sleep(30000);
            TerminateThread(t5, 0);
            TerminateThread(t5d1, 0);
            rfresh();
            HANDLE t6 = CreateThread(0, 0, o6, 0, 0, 0);
			audio6();
			Sleep(30000);
            TerminateThread(t6, 0);
            HANDLE t7 = CreateThread(0, 0, o7, 0, 0, 0);
			audio7();
			Sleep(30000);
            TerminateThread(t7, 0);
            rfresh();
        	HANDLE t8 = CreateThread(0, 0, o8, 0, 0, 0);
			audio8();
			Sleep(30000);
            TerminateThread(t8, 0);
            rfresh();
            HANDLE t9 = CreateThread(0, 0, o9, 0, 0, 0);
			audio9();
			Sleep(30000);
            TerminateThread(t9, 0);
            rfresh();
			HANDLE t10 = CreateThread(0, 0, o10, 0, 0, 0);
    		audio10();
    		Sleep(30000);
            TerminateThread(t10, 0);
            rfresh();
        	HANDLE t11 = CreateThread(0, 0, o11, 0, 0, 0);
    		audio11();
    		Sleep(30000);
            TerminateThread(t11, 0);
            rfresh();
        	HANDLE t12 = CreateThread(0, 0, o12, 0, 0, 0);
    		audio12();
    		Sleep(30000);
            TerminateThread(t12, 0);
            rfresh();
        	HANDLE t13d1 = CreateThread(0, 0, bg, 0, 0, 0); //octahedron
			HANDLE t13 = CreateThread(0, 0, o13, 0, 0, 0);
			audio13();
		    Sleep(60000);
            TerminateThread(t13, 0);
            HANDLE t14 = CreateThread(0, 0, ng, 0, 0, 0);
			HANDLE t14d1 = CreateThread(0, 0, gg, 0, 0, 0);
			audio14();
			Sleep(60000);
            TerminateThread(t14, 0);
            TerminateThread(t14d1, 0);
            TerminateThread(t13d1, 0);
            HANDLE t15 = CreateThread(0, 0, g1, 0, 0, 0);
			audio15();
			Sleep(45000);
            TerminateThread(t15, 0);
        	HANDLE t16 = CreateThread(0, 0, g2, 0, 0, 0);
			audio16();
			Sleep(45000);
            TerminateThread(t16, 0);
            HANDLE t17 = CreateThread(0, 0, g3, 0, 0, 0);
        	audio17();
			Sleep(30000);
            TerminateThread(t17, 0);
            HANDLE t18 = CreateThread(0, 0, g4, 0, 0, 0);
        	audio18();
			Sleep(30000);
            TerminateThread(t18, 0);
            HANDLE t19 = CreateThread(0, 0, g5, 0, 0, 0);
        	audio19();
			Sleep(30000);
            TerminateThread(t19, 0);
            HANDLE t20 = CreateThread(0, 0, g6, 0, 0, 0);
        	audio20();
    		Sleep(30000);
            TerminateThread(t20, 0);
            HANDLE t21 = CreateThread(0, 0, g7, 0, 0, 0);
        	audio21();
    		Sleep(6E4); //same as 60000
            TerminateThread(t21, 0);
            HANDLE t22 = CreateThread(0, 0, g8, 0, 0, 0);
        	audio22();
    		Sleep(6E4);
            TerminateThread(t22, 0);
            HANDLE t23 = CreateThread(0, 0, g9, 0, 0, 0);
        	audio23();
    		Sleep(3E4);
            TerminateThread(t23, 0);
            HANDLE t24 = CreateThread(0, 0, g10, 0, 0, 0);
        	audio24();
    		Sleep(45E3);
            TerminateThread(t24, 0);
    }
}
