██████╗ ███████╗██████╗ ██╗   ██╗██╗     ██╗     ██╗██╗   ██╗███╗   ███╗
██╔══██╗██╔════╝██╔══██╗╚██╗ ██╔╝██║     ██║     ██║██║   ██║████╗ ████║
██████╔╝█████╗  ██████╔╝ ╚████╔╝ ██║     ██║     ██║██║   ██║██╔████╔██║
██╔══██╗██╔══╝  ██╔══██╗  ╚██╔╝  ██║     ██║     ██║██║   ██║██║╚██╔╝██║
██████╔╝███████╗██║  ██║   ██║   ███████╗███████╗██║╚██████╔╝██║ ╚═╝ ██║
╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚══════╝╚═╝ ╚═════╝ ╚═╝     ╚═╝
                                                                       
malware name: Beryllium
Malware Type: Trojan
Damage rate: Destructive
Made in: C++, asm
Works Best in: Windows 7, as in Windows XP it memleaks, and if you don't see effects, then enable aero
Created by: pankoza
Creation date: 8 May 2022
the mbr is a remake of the Dr. Mario game: https://github.com/spaceships/boot-sector-drmario