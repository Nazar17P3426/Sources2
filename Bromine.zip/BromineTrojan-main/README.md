# BromineTrojan
GDI Malware
<br>
This is a C++ GDI Malware that will show GDI Payloads, play bytebeat sounds, show hidden process windows, and overwrite mbr with a pacman game but this mbr is from nanochess
<br>
Made for educational purposes Only
<br>
This was made for the Dev-C++ IDE
