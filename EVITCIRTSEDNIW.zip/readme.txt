E V V       tci    s         i
    v     i       rt    ed N    w

made in c++
by Hoang Dat

MY MOST DESTRUC TIVE PROJECT
SHORT TROJAN

NO, NOT SKIDD3D