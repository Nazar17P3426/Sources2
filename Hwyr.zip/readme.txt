hwyr.exe (translate it to english to see a word)


NOTE:
this is comeback malware, but this is short unlike my previous malware,
if you understand what the name of the malware means, then luckly you
don't have to use google translate (if you understand what the word in
english is.) PLEASE after testing it, check the source and modfiy it for
the 2.0 version, if you only have visual studio code, you can use the c++
file to compile it.

INFORMATION:
date: 10/30/2023
Duration: Short (if you do the 2.0 update yourself, it wont be short)
Releases: 1.0 (myself), 2.0 (you do yourself whatever you want)

WARNING:
It may terminate dwm and explorer, so if you use windows 10 or
newer, it might not work, so try Using Windows 8.1 or Older
and also, it repeatly terminates task manager and command
prompt, but you can use powershell or a batch file to terminate
it, and its not for people with Higher chance of seizures, strokes,
heart failures or even brain death, so if you have one of those that
has higher chance for you, please don't use it, if you are ready
or ok with a older windows, then you can test it, :)