﻿//Dependencies
// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Media;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;
using System.Drawing.Drawing2D;
using static System.Net.Mime.MediaTypeNames;
using System.Windows.Forms;
using static Program;
using WinFormsApp = System.Windows.Forms.Application;
using MimeApp = System.Net.Mime.MediaTypeNames.Application;
using System.Windows.Media.Media3D;

//////////////////////////////////////////////////////////////////////////////////////////////////
//Stuff
internal static class Program
{

    [DllImport("gdi32.dll")]
    static extern bool PlgBlt(IntPtr hdcDest, POINT[] lpPoint, IntPtr hdcSrc,
int nXSrc, int nYSrc, int nWidth, int nHeight, IntPtr hbmMask, int xMask,
int yMask);
    [DllImport("user32.dll")]
    static extern IntPtr GetDesktopWindow();
    [DllImport("user32.dll")]
    static extern IntPtr GetWindowDC(IntPtr hWnd);
    public struct POINT
    {
        public int X;
        public int Y;

        public POINT(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }

        public static implicit operator System.Drawing.Point(POINT p)
        {
            return new System.Drawing.Point(p.X, p.Y);
        }

        public static implicit operator POINT(System.Drawing.Point p)
        {
            return new POINT(p.X, p.Y);
        }
    }
    private enum RedrawWindowFlags : uint
    {
        Invalidate = 1u,
        InternalPaint = 2u,
        Erase = 4u,
        Validate = 8u,
        NoInternalPaint = 0x10u,
        NoErase = 0x20u,
        NoChildren = 0x40u,
        AllChildren = 0x80u,
        UpdateNow = 0x100u,
        EraseNow = 0x200u,
        Frame = 0x400u,
        NoFrame = 0x800u
    }
    private static void Sound1(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 8000;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    t * (t >> 4 & t >> 6) & 128
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    private static void Sound2(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 8000;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    (t * (t ^ t >> 10) * 67) ^ 45
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    private static void Sound3(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 8000;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    (t * (2 + (t >> 6 & t)) & 128) * 45
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    private static void Sound4(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 22050;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    (t * (4 + (t >> 6 & t >> 3)) >> ((t * 5) & 8)) - 1
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    private static void Sound5(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 16000;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    ((t & t >> 12) * (t | t >> 5)) * t ^ (t & t >> 5)
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    private static void Sound6(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 8000;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    (t >> 9 ^ (t >> 9) - 1 ^ 1) % 13 * t * t
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    private static void Sound7(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 8000;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    (t * (t >> 5)) >> (t * t + ((t >> 6 ^ t >> 4) * 127) + (5 + (t >> 5) - 6) >> (t * (t >> 10)))
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    private static void Sound8(int secs)
    {
        using (var stream = new MemoryStream())
        {
            var writer = new BinaryWriter(stream);

            writer.Write("RIFF".ToCharArray());
            writer.Write((UInt32)0);
            writer.Write("WAVE".ToCharArray());

            writer.Write("fmt ".ToCharArray());
            writer.Write((UInt32)16);
            writer.Write((UInt16)1);

            var channels = 1;
            var sample_rate = 16000;
            var bits_per_sample = 8;

            writer.Write((UInt16)channels);
            writer.Write((UInt32)sample_rate);
            writer.Write((UInt32)(sample_rate * channels * bits_per_sample / 8));
            writer.Write((UInt16)(channels * bits_per_sample / 8));
            writer.Write((UInt16)bits_per_sample);

            writer.Write("data".ToCharArray());

            var seconds = secs;

            var data = new byte[sample_rate * seconds];

            for (var t = 5; t < data.Length; t++)
                data[t] = (byte)(
                    4 * (t * ((t >> 4 | t >> 8)))
                    );

            writer.Write((UInt32)(data.Length * channels * bits_per_sample / 8));

            foreach (var elt in data) writer.Write(elt);

            writer.Seek(4, SeekOrigin.Begin);
            writer.Write((UInt32)(writer.BaseStream.Length - 8));

            stream.Seek(0, SeekOrigin.Begin);

            new SoundPlayer(stream).PlaySync();
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //GDIs
    #region rgb to hsl
    public struct RGB
    {
        private byte _r;
        private byte _g;
        private byte _b;

        public RGB(byte r, byte g, byte b)
        {
            this._r = r;
            this._g = g;
            this._b = b;
        }

        public byte R
        {
            get { return this._r; }
            set { this._r = value; }
        }

        public byte G
        {
            get { return this._g; }
            set { this._g = value; }
        }

        public byte B
        {
            get { return this._b; }
            set { this._b = value; }
        }

        public bool Equals(RGB rgb)
        {
            return (this.R == rgb.R) && (this.G == rgb.G) && (this.B == rgb.B);
        }
    }

    public struct HSL
    {
        private int _h;
        private float _s;
        private float _l;

        public HSL(int h, float s, float l)
        {
            this._h = h;
            this._s = s;
            this._l = l;
        }

        public int H
        {
            get { return this._h; }
            set { this._h = value; }
        }

        public float S
        {
            get { return this._s; }
            set { this._s = value; }
        }

        public float L
        {
            get { return this._l; }
            set { this._l = value; }
        }

        public bool Equals(HSL hsl)
        {
            return (this.H == hsl.H) && (this.S == hsl.S) && (this.L == hsl.L);
        }
    }

    public static RGB HSLToRGB(HSL hsl)
    {
        byte r = 0;
        byte g = 0;
        byte b = 0;

        if (hsl.S == 0)
        {
            r = g = b = (byte)(hsl.L * 255);
        }
        else
        {
            float v1, v2;
            float hue = (float)hsl.H / 360;

            v2 = (hsl.L < 0.5) ? (hsl.L * (1 + hsl.S)) : ((hsl.L + hsl.S) - (hsl.L * hsl.S));
            v1 = 2 * hsl.L - v2;

            r = (byte)(255 * HueToRGB(v1, v2, hue + (1.0f / 3)));
            g = (byte)(255 * HueToRGB(v1, v2, hue));
            b = (byte)(255 * HueToRGB(v1, v2, hue - (1.0f / 3)));
        }

        return new RGB(r, g, b);
    }

    private static float HueToRGB(float v1, float v2, float vH)
    {
        if (vH < 0)
            vH += 1;

        if (vH > 1)
            vH -= 1;

        if ((6 * vH) < 1)
            return (v1 + (v2 - v1) * 6 * vH);

        if ((2 * vH) < 1)
            return v2;

        if ((3 * vH) < 2)
            return (v1 + (v2 - v1) * ((2.0f / 3) - vH) * 6);

        return v1;
    }
    #endregion
    private class PlgBlt1 : Drawer
    {
        public override void Draw(IntPtr hdc)
        {
            Random r = new Random();
            int x = Screen.PrimaryScreen.Bounds.X;
            int y = Screen.PrimaryScreen.Bounds.Y;
            int left = Screen.PrimaryScreen.Bounds.Left;
            int top = Screen.PrimaryScreen.Bounds.Top;
            int right = Screen.PrimaryScreen.Bounds.Right;
            int bottom = Screen.PrimaryScreen.Bounds.Bottom;
            IntPtr hwnd = GetDesktopWindow();
            POINT[] lppoint = new POINT[3];
            lppoint[0].X = left + (random.Next(screenW));
            lppoint[0].Y = top + (random.Next(screenH));
            lppoint[1].X = right + (random.Next(screenW));
            lppoint[1].Y = top + (random.Next(screenH));
            lppoint[2].X = left + (random.Next(screenW));
            lppoint[2].Y = bottom + (random.Next(screenH));
            PlgBlt(hdc, lppoint, hdc, left, top, right - left, bottom - top, IntPtr.Zero, 0, 0);
            PatBlt(hdc, 0, 0, random.Next(screenW), random.Next(screenH), CopyPixelOperation.PatInvert);
            Thread.Sleep(0);
        }
    }
    private class PlgBlt2 : Drawer
    {
        public override void Draw(IntPtr hdc)
        {
            Random random = new Random();
            int screenW = Screen.PrimaryScreen.Bounds.Width;
            int screenH = Screen.PrimaryScreen.Bounds.Height;

            int left = Screen.PrimaryScreen.Bounds.Left;
            int top = Screen.PrimaryScreen.Bounds.Top;
            int right = Screen.PrimaryScreen.Bounds.Right;
            int bottom = Screen.PrimaryScreen.Bounds.Bottom;

            IntPtr hwnd = GetDesktopWindow();

            POINT[] lppoint = new POINT[3];
            lppoint[0].X = left + random.Next(screenW);
            lppoint[0].Y = top + random.Next(screenH);
            lppoint[1].X = right + random.Next(screenW);
            lppoint[1].Y = top + random.Next(screenH);
            lppoint[2].X = left + random.Next(screenW);
            lppoint[2].Y = bottom + random.Next(screenH);

            PlgBlt(hdc, lppoint, hdc, left, top, right - left, bottom - top, IntPtr.Zero, 0, 0);

            PatBlt(hdc, 0, 0, random.Next(screenW), random.Next(screenH), CopyPixelOperation.PatInvert);

            Thread.Sleep(0);
        }
    }
    private class PlgBlt3 : Drawer
    {
        [DllImport("gdi32.dll", EntryPoint = "PlgBlt", SetLastError = true)]
        public static extern bool PlgBlt(
        IntPtr hdcDest,
        [In] POINT[] lpPoint,
        IntPtr hdcSrc,
        int nXSrc,
        int nYSrc,
        int nWidth,
        int nHeight,
        IntPtr hbmMask,
        int xMask,
        int yMask);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetDesktopWindow();

        private double angle = 0;

        public override void Draw(IntPtr hdc)
        {
            int screenW = Screen.PrimaryScreen.Bounds.Width;
            int screenH = Screen.PrimaryScreen.Bounds.Height;

            int centerX = screenW / 2;
            int centerY = screenH / 2;

            IntPtr hwnd = GetDesktopWindow();

            POINT[] lppoint = new POINT[3];
            double radius = Math.Min(screenW, screenH) / 2;

            lppoint[0] = RotatePoint(centerX, centerY, radius, angle);
            lppoint[1] = RotatePoint(centerX, centerY, radius, angle + Math.PI / 2);
            lppoint[2] = RotatePoint(centerX, centerY, radius, angle + Math.PI);

            PlgBlt(hdc, lppoint, hdc, 0, 0, screenW, screenH, IntPtr.Zero, 0, 0);

            angle += 0.05;
            if (angle >= 2 * Math.PI) angle = 0;

            Thread.Sleep(16);
        }

        private POINT RotatePoint(int centerX, int centerY, double radius, double angle)
        {
            POINT point = new POINT
            {
                X = centerX + (int)(radius * Math.Cos(angle)),
                Y = centerY + (int)(radius * Math.Sin(angle))
            };
            return point;
        }
    }
    private class Lines1 : Drawer
    {
        [DllImport("gdi32.dll", EntryPoint = "SetPixel", SetLastError = true)]
        private static extern bool SetPixel(IntPtr hdc, int x, int y, uint color);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetDC(IntPtr hwnd);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetDesktopWindow();

        private int frame = 0;

        public override void Draw(IntPtr hdc)
        {
            int screenW = Screen.PrimaryScreen.Bounds.Width;
            int screenH = Screen.PrimaryScreen.Bounds.Height;

            for (int y = 0; y < screenH; y++)
            {
                for (int x = 0; x < screenW; x++)
                {
                    uint color = GenerateColor(x, y, frame);

                    SetPixel(hdc, x, y, color);
                }
            }

            frame++;
            Thread.Sleep(16);
        }

        private uint GenerateColor(int x, int y, int frame)
        {
            byte r = (byte)(128 + 127 * Math.Sin((x + frame) * 0.02));
            byte g = (byte)(128 + 127 * Math.Sin((y + frame) * 0.02));
            byte b = (byte)(128 + 127 * Math.Sin((x + y + frame) * 0.02));

            return (uint)(r | (g << 8) | (b << 16));
        }
    }
    private class PlgBlt4 : Drawer
    {
        [DllImport("gdi32.dll", EntryPoint = "PlgBlt", SetLastError = true)]
        public static extern bool PlgBlt(
        IntPtr hdcDest,
        [In] POINT[] lpPoint,
        IntPtr hdcSrc,
        int nXSrc,
        int nYSrc,
        int nWidth,
        int nHeight,
        IntPtr hbmMask,
        int xMask,
        int yMask);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetDesktopWindow();

        private double angle = 0;

        public override void Draw(IntPtr hdc)
        {
            int screenW = Screen.PrimaryScreen.Bounds.Width;
            int screenH = Screen.PrimaryScreen.Bounds.Height;

            IntPtr hwnd = GetDesktopWindow();

            POINT[] lppoint = new POINT[3];
            int shift = (int)(Math.Sin(angle) * 100);

            lppoint[0].X = 0 + shift;
            lppoint[0].Y = 0;

            lppoint[1].X = screenW - shift;
            lppoint[1].Y = 0;

            lppoint[2].X = 0;
            lppoint[2].Y = screenH;

            PlgBlt(hdc, lppoint, hdc, 0, 0, screenW, screenH, IntPtr.Zero, 0, 0);

            angle += 0.05;
            if (angle >= 2 * Math.PI) angle = 0;

            Thread.Sleep(16);
        }
    }
    public class Ripple1
    {
        private static Thread shaderThread;
        private static bool isRunning = false;

        [DllImport("gdi32.dll", EntryPoint = "PlgBlt", SetLastError = true)]
        public static extern bool PlgBlt(
            IntPtr hdcDest,
            [In] POINT[] lpPoint,
            IntPtr hdcSrc,
            int nXSrc,
            int nYSrc,
            int nWidth,
            int nHeight,
            IntPtr hbmMask,
            int xMask,
            int yMask);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr GetDC(IntPtr hwnd);

        private static Random random = new Random();
        private const int maxRipples = 5;
        private const int maxRadius = 300;
        private static Ripple[] ripples = new Ripple[maxRipples];

        private class Ripple
        {
            public int X { get; private set; }
            public int Y { get; private set; }
            public int Radius { get; private set; }
            public bool Active { get; private set; }

            public Ripple()
            {
                Active = false;
                Radius = 0;
            }

            public void Update()
            {
                Radius += 5;
            }

            public void Reset(Random random, int screenW, int screenH)
            {
                X = random.Next(0, screenW);
                Y = random.Next(0, screenH);
                Radius = 0;
                Active = true;
            }
        }

        public static void Start()
        {
            if (isRunning) return;

            isRunning = true;

            shaderThread = new Thread(() =>
            {
                for (int i = 0; i < maxRipples; i++)
                {
                    ripples[i] = new Ripple();
                }

                IntPtr hdc = GetDC(GetDesktopWindow());

                while (isRunning)
                {
                    Draw(hdc);
                    Thread.Sleep(16);
                }
            });

            shaderThread.Start();
        }

        public static void Stop()
        {
            isRunning = false;
            shaderThread?.Join();
        }

        private static void Draw(IntPtr hdc)
        {
            int screenW = Screen.PrimaryScreen.Bounds.Width;
            int screenH = Screen.PrimaryScreen.Bounds.Height;

            foreach (var ripple in ripples)
            {
                if (ripple.Active)
                {
                    ripple.Update();

                    if (ripple.Radius >= maxRadius)
                    {
                        ripple.Reset(random, screenW, screenH);
                    }

                    POINT[] points = GetDistortedPoints(ripple, screenW, screenH);
                    PlgBlt(hdc, points, hdc, 0, 0, screenW, screenH, IntPtr.Zero, 0, 0);
                }
                else
                {
                    ripple.Reset(random, screenW, screenH);
                }
            }
        }

        private static POINT[] GetDistortedPoints(Ripple ripple, int screenW, int screenH)
        {
            POINT[] points = new POINT[3];
            double distortion = Math.Sin(ripple.Radius * 0.1) * 20;

            points[0].X = (int)(ripple.X - distortion);
            points[0].Y = (int)(ripple.Y - distortion);
            points[1].X = (int)(ripple.X + screenW - distortion);
            points[1].Y = (int)(ripple.Y - distortion);
            points[2].X = (int)(ripple.X - distortion);
            points[2].Y = (int)(ripple.Y + screenH - distortion);

            return points;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
        }
    }
    public class ColorWaveGradient
    {
        private static Thread shaderThread;
        private static bool isRunning = false;

        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        public static extern bool DeleteDC(IntPtr hdc);

        [DllImport("user32.dll")]
        public static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll")]
        public static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        public static void Start()
        {
            if (isRunning) return;

            isRunning = true;

            shaderThread = new Thread(() =>
            {
                IntPtr hwnd = GetDesktopWindow();
                IntPtr hdc = GetDC(hwnd);

                int screenW = Screen.PrimaryScreen.Bounds.Width;
                int screenH = Screen.PrimaryScreen.Bounds.Height;

                while (isRunning)
                {
                    Draw(hdc, screenW, screenH);
                    Thread.Sleep(16);
                }

                ReleaseDC(hwnd, hdc);
            });

            shaderThread.Start();
        }

        public static void Stop()
        {
            isRunning = false;
            shaderThread?.Join();
        }

        private static void Draw(IntPtr hdc, int screenW, int screenH)
        {
            using (Graphics g = Graphics.FromHdc(hdc))
            {
                for (int y = 0; y < screenH; y += 5)
                {
                    for (int x = 0; x < screenW; x += 5)
                    {
                        double time = Environment.TickCount * 0.001;
                        int r = (int)(128 + 127 * Math.Sin(x * 0.01 + time));
                        int gValue = (int)(128 + 127 * Math.Sin(y * 0.01 + time + 2));
                        int b = (int)(128 + 127 * Math.Sin((x + y) * 0.01 + time + 4));

                        using (Brush brush = new SolidBrush(Color.FromArgb(r, gValue, b)))
                        {
                            g.FillRectangle(brush, x, y, 5, 5);
                        }
                    }
                }
            }
        }
    }
    public class Kaleidoscope
    {
        private static Thread shaderThread;
        private static bool isRunning = false;

        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        public static extern bool DeleteDC(IntPtr hdc);

        [DllImport("user32.dll")]
        public static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll")]
        public static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        public static void Start()
        {
            if (isRunning) return;

            isRunning = true;

            shaderThread = new Thread(() =>
            {
                IntPtr hwnd = GetDesktopWindow();
                IntPtr hdc = GetDC(hwnd);

                int screenW = Screen.PrimaryScreen.Bounds.Width;
                int screenH = Screen.PrimaryScreen.Bounds.Height;

                while (isRunning)
                {
                    Draw(hdc, screenW, screenH);
                    Thread.Sleep(30);
                }

                ReleaseDC(hwnd, hdc);
            });

            shaderThread.Start();
        }

        public static void Stop()
        {
            isRunning = false;
            shaderThread?.Join();
        }

        private static void Draw(IntPtr hdc, int screenW, int screenH)
        {
            using (Graphics g = Graphics.FromHdc(hdc))
            {
                double time = Environment.TickCount * 0.001;

                for (int i = 0; i < 10; i++)
                {
                    float centerX = screenW / 2 + (float)(Math.Sin(time + i * 0.5) * screenW * 0.3);
                    float centerY = screenH / 2 + (float)(Math.Cos(time + i * 0.5) * screenH * 0.3);
                    float size = 200 + (float)(Math.Sin(time * 2 + i) * 100);
                    float rotation = (float)(time * 50 + i * 36);

                    int r = (int)(128 + 127 * Math.Sin(i * 0.3 + time));
                    int gValue = (int)(128 + 127 * Math.Cos(i * 0.3 + time + 2));
                    int b = (int)(128 + 127 * Math.Sin(i * 0.5 + time + 4));

                    using (Pen pen = new Pen(Color.FromArgb(r, gValue, b), 4))
                    {
                        DrawRotatingTriangle(g, pen, centerX, centerY, size, rotation);
                    }
                }
            }
        }

        private static void DrawRotatingTriangle(Graphics g, Pen pen, float centerX, float centerY, float size, float rotation)
        {
            PointF[] triangle = new PointF[3];

            for (int i = 0; i < 3; i++)
            {
                double angle = Math.PI * 2 / 3 * i + rotation * Math.PI / 180;
                triangle[i] = new PointF(
                    centerX + (float)(Math.Cos(angle) * size),
                    centerY + (float)(Math.Sin(angle) * size)
                );
            }

            g.DrawPolygon(pen, triangle);
        }
    }
    public class Glitch1
    {
        private static Thread shaderThread;
        private static bool isRunning = false;

        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        public static extern bool DeleteDC(IntPtr hdc);

        [DllImport("user32.dll")]
        public static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll")]
        public static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        [DllImport("gdi32.dll")]
        public static extern bool BitBlt(
            IntPtr hdcDest,
            int nXDest,
            int nYDest,
            int nWidth,
            int nHeight,
            IntPtr hdcSrc,
            int nXSrc,
            int nYSrc,
            CopyPixelOperation rop);

        public static void Start()
        {
            if (isRunning) return;

            isRunning = true;
            shaderThread = new Thread(() =>
            {
                IntPtr hwnd = GetDesktopWindow();
                IntPtr hdc = GetDC(hwnd);

                int screenW = Screen.PrimaryScreen.Bounds.Width;
                int screenH = Screen.PrimaryScreen.Bounds.Height;

                Random random = new Random();

                while (isRunning)
                {
                    ApplyGlitchEffect(hdc, screenW, screenH, random);
                    Thread.Sleep(16);
                }

                ReleaseDC(hwnd, hdc);
            });

            shaderThread.Start();
        }

        public static void Stop()
        {
            isRunning = false;
            shaderThread?.Join();
        }

        private static void ApplyGlitchEffect(IntPtr hdc, int screenW, int screenH, Random random)
        {
            using (Graphics g = Graphics.FromHdc(hdc))
            {
                for (int y = 0; y < screenH; y += random.Next(20, 50))
                {
                    for (int x = 0; x < screenW; x += random.Next(20, 50))
                    {
                        int glitchWidth = random.Next(50, 150);
                        int glitchHeight = random.Next(5, 20);

                        BitBlt(hdc, x + random.Next(-10, 10), y + random.Next(-10, 10), glitchWidth, glitchHeight, hdc, x, y, CopyPixelOperation.SourceCopy);

                        if (random.Next(0, 5) == 0)
                        {
                            g.FillRectangle(new SolidBrush(Color.FromArgb(random.Next(256), random.Next(256), random.Next(256))), x, y, glitchWidth, glitchHeight);
                        }
                    }
                }
            }
        }
    }
    public class Blur1
    {
        private static Thread shaderThread;
        private static bool isRunning = false;
        private static double rotationAngle = 0;
        private static double direction = 1;
        private static readonly Random random = new Random();
        private static int changeDirectionInterval = 1000;
        private static System.Threading.Timer directionTimer;

        [DllImport("user32.dll")]
        public static extern IntPtr GetDesktopWindow();

        public static void Start()
        {
            if (isRunning) return;

            isRunning = true;
            shaderThread = new Thread(() =>
            {
                while (isRunning)
                {
                    // Capture the current screen
                    using (Bitmap screenCapture = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height))
                    {
                        using (Graphics screenGraphics = Graphics.FromImage(screenCapture))
                        {
                            screenGraphics.CopyFromScreen(0, 0, 0, 0, screenCapture.Size);
                        }

                        using (Bitmap blurredImage = new Bitmap(screenCapture.Width, screenCapture.Height))
                        {
                            using (Graphics g = Graphics.FromImage(blurredImage))
                            {
                                ApplyRadialBlur(g, screenCapture);
                            }

                            using (Graphics desktopGraphics = Graphics.FromHwnd(GetDesktopWindow()))
                            {
                                desktopGraphics.DrawImage(blurredImage, 0, 0);
                            }
                        }
                    }

                    Thread.Sleep(16);
                    rotationAngle += 0.05 * direction;
                    if (rotationAngle >= 2 * Math.PI) rotationAngle -= 2 * Math.PI;
                }
            });

            directionTimer = new System.Threading.Timer(ChangeDirection, null, changeDirectionInterval, changeDirectionInterval); // Specify the namespace
            shaderThread.Start();
        }

        public static void Stop()
        {
            isRunning = false;
            directionTimer?.Dispose();
            shaderThread?.Join();
        }

        private static void ChangeDirection(object state)
        {
            direction *= -1;
        }

        private static void ApplyRadialBlur(Graphics g, Bitmap screenCapture)
        {
            int centerX = screenCapture.Width / 2;
            int centerY = screenCapture.Height / 2;
            int radius = Math.Min(centerX, centerY);
            
            Color edgeColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));

            for (int y = 0; y < screenCapture.Height; y++)
            {
                for (int x = 0; x < screenCapture.Width; x++)
                {
                    double angle = Math.Atan2(y - centerY, x - centerX) + rotationAngle;
                    double distance = Math.Sqrt(Math.Pow(x - centerX, 2) + Math.Pow(y - centerY, 2));
                    double blurAmount = Math.Min(distance / radius, 1.0);

                    int srcX = (int)(centerX + blurAmount * radius * Math.Cos(angle));
                    int srcY = (int)(centerY + blurAmount * radius * Math.Sin(angle));

                    srcX = Math.Max(0, Math.Min(screenCapture.Width - 1, srcX));
                    srcY = Math.Max(0, Math.Min(screenCapture.Height - 1, srcY));

                    Color pixelColor = screenCapture.GetPixel(srcX, srcY);
                    g.FillRectangle(new SolidBrush(pixelColor), x, y, 1, 1);

                    if (distance >= radius - 5)
                    {
                        g.FillRectangle(new SolidBrush(edgeColor), x, y, 1, 1);
                    }
                }
            }
        }
    }
    private class Circles1 : Drawer
    {
        private static int circleCount = 30;
        private static Random random = new Random();
        private static Circle[] circles;
        private static Circles1 shaderInstance;
        private static System.Windows.Forms.Timer timer;
        private static Color backgroundColor;

        public Circles1()
        {
            circles = new Circle[circleCount];
            for (int i = 0; i < circleCount; i++)
            {
                circles[i] = new Circle();
            }
            backgroundColor = Color.Black;
        }

        public static void Start()
        {
            shaderInstance = new Circles1();
            timer = new System.Windows.Forms.Timer { Interval = 16 };
            timer.Tick += (s, e) =>
            {
                backgroundColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
                shaderInstance.Draw(GetHdc());
            };
            timer.Start();
        }

        public static void Stop()
        {
            if (timer != null)
            {
                timer.Stop();
                timer.Dispose();
            }
        }

        public override void Draw(IntPtr hdc)
        {
            if (hdc == IntPtr.Zero)
                return;

            using (Graphics g = Graphics.FromHdc(hdc))
            {
                using (BufferedGraphicsContext context = BufferedGraphicsManager.Current)
                {
                    using (BufferedGraphics bufferedGraphics = context.Allocate(g, new Rectangle(0, 0, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)))
                    {
                        Graphics bg = bufferedGraphics.Graphics;

                        bg.Clear(backgroundColor);

                        foreach (var circle in circles)
                        {
                            circle.Move();
                            using (SolidBrush brush = new SolidBrush(circle.Color))
                            {
                                bg.FillEllipse(brush, circle.X - circle.Radius, circle.Y - circle.Radius, circle.Radius * 2, circle.Radius * 2);
                            }
                        }

                        bufferedGraphics.Render(g);
                    }
                }
            }
        }

        private static IntPtr GetHdc()
        {
            var form = System.Windows.Forms.Application.OpenForms[0];
            if (form != null)
            {
                using (Graphics g = form.CreateGraphics())
                {
                    return g.GetHdc();
                }
            }
            return IntPtr.Zero;
        }

        private class Circle
        {
            public int Radius { get; set; }
            public int X { get; set; }
            public int Y { get; set; }
            public Color Color { get; set; }
            private int SpeedX { get; set; }
            private int SpeedY { get; set; }

            public Circle()
            {
                Radius = random.Next(20, 100);
                X = random.Next(Radius, Screen.PrimaryScreen.Bounds.Width - Radius);
                Y = random.Next(Radius, Screen.PrimaryScreen.Bounds.Height - Radius);
                Color = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
                SpeedX = random.Next(-5, 6);
                SpeedY = random.Next(-5, 6);
            }

            public void Move()
            {
                X += SpeedX;
                Y += SpeedY;

                if (X - Radius < 0 || X + Radius > Screen.PrimaryScreen.Bounds.Width)
                    SpeedX = -SpeedX;

                if (Y - Radius < 0 || Y + Radius > Screen.PrimaryScreen.Bounds.Height)
                    SpeedY = -SpeedY;
            }
        }
    }
    public class LayeredWindow1 : Form
    {
        private readonly int alpha;
        private readonly System.Threading.Timer timer;

        public LayeredWindow1(int alpha)
        {
            this.alpha = alpha;
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(0, 0);
            this.Size = Screen.PrimaryScreen.Bounds.Size;
            this.BackColor = Color.Black;
            this.Opacity = alpha / 255.0;
            this.TransparencyKey = Color.Black;
            this.ShowInTaskbar = false;

            timer = new System.Threading.Timer(OnTimerTick, null, 0, 1000);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            for (int y = 0; y < this.ClientSize.Height; y++)
            {
                int r = (int)(255 * Math.Sin((y + 0) * Math.PI / 180));
                int g = (int)(255 * Math.Sin((y + 85) * Math.PI / 180));
                int b = (int)(255 * Math.Sin((y + 170) * Math.PI / 180));

                r = Math.Clamp(r, 0, 255);
                g = Math.Clamp(g, 0, 255);
                b = Math.Clamp(b, 0, 255);

                using (var brush = new SolidBrush(Color.FromArgb(r, g, b)))
                {
                    e.Graphics.FillRectangle(brush, 0, y, this.ClientSize.Width, 1);
                }
            }
        }

        private void OnTimerTick(object state)
        {
            this.Invalidate();
        }

        public void ShowWindow()
        {
            this.Show();
        }

        public void HideWindow()
        {
            this.Hide();
        }
    }
    private class PlgBlt5 : Drawer
    {
        public override void Draw(IntPtr hdc)
        {
            Random random = new Random();
            int screenW = Screen.PrimaryScreen.Bounds.Width;
            int screenH = Screen.PrimaryScreen.Bounds.Height;
            IntPtr hwnd = GetDesktopWindow();

            POINT[] points = new POINT[3];
            points[0].X = random.Next(0, screenW);
            points[0].Y = random.Next(0, screenH);
            points[1].X = random.Next(0, screenW);
            points[1].Y = random.Next(0, screenH);
            points[2].X = random.Next(0, screenW);
            points[2].Y = random.Next(0, screenH);

            using (Graphics g = Graphics.FromHdc(hdc))
            {
                using (Brush brush = new SolidBrush(Color.FromArgb(128, random.Next(256), random.Next(256), random.Next(256))))
                {
                    g.FillPolygon(brush, new Point[]
                    {
                    new Point(points[0].X, points[0].Y),
                    new Point(points[1].X, points[1].Y),
                    new Point(points[2].X, points[2].Y)
                    });
                }
            }

            Thread.Sleep(0);
        }

        [DllImport("user32.dll")]
        private static extern IntPtr GetDesktopWindow();
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //Other
    private abstract class Drawer
    {

        public bool running;

        public Random random = new Random();

        public int screenW = Screen.PrimaryScreen.Bounds.Width;

        public int screenH = Screen.PrimaryScreen.Bounds.Height;

        public void Start()
        {
            if (!running)
            {
                running = true;
                new Thread(DrawLoop).Start();
            }
        }

        public void Stop()
        {
            running = false;
        }
        private void DrawLoop()
        {
            while (running)
            {
                IntPtr dC = GetDC(IntPtr.Zero);
                Draw(dC);
                ReleaseDC(IntPtr.Zero, dC);
            }
        }

        public void Redraw()
        {
            RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
        }

        public abstract void Draw(IntPtr hdc);
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //Code Execution
    [STAThread]
    public static void Main(string[] args)
    {
        Drawer plgblt1 = new PlgBlt1();
        Drawer plgblt2 = new PlgBlt2();
        Drawer plgblt3 = new PlgBlt3();
        Drawer plgblt4 = new PlgBlt4();
        Drawer plgblt5 = new PlgBlt5();
        Drawer lines1 = new Lines1();
        Drawer circles1 = new Circles1();
        var window1 = new LayeredWindow1(230);

       
        if (MessageBox.Show("You've Executed A C# Malware Called Kerferg.exe! If You Don't Know What This Program Is, Them I Suggest You Clicking On No, But If You Know And Doing In In A Safe Environment To Test, Them Press Yes To Proceed, This Malware Won't Harm Your Computer but It May Give You Seizures And Hearing Damage, This Malware Is Only Made For Testing Purposes So Don't Try To Prank Anyone Around Here! Anyways, Good Luck!", "Kerferg.exe - First Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                if (MessageBox.Show("This Is The Last Warning! If You Don't Know You Are Doing, It Is Recomended To Click No, Once You Click Yes, This Malware Will Start! This Is Your Last Chance To Stop The Malware. Are You Sure You Want To Run This?", "Kerferg.exe - Last Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                Thread.Sleep(5000);
                plgblt1.Start();
                plgblt2.Start();
                Sound1(30);
                plgblt1.Stop();
                plgblt2.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
                Thread.Sleep(1000);
                plgblt3.Start();
                Sound2(30);
                plgblt3.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
                Thread.Sleep(1000);
                lines1.Start();
                plgblt4.Start();
                    Sound3(30);
                lines1.Stop();
                plgblt4.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
                Thread.Sleep(1000);
                Ripple1.Start();
                ColorWaveGradient.Start();
                Sound4(30);
                Ripple1.Stop();
                ColorWaveGradient.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
                Thread.Sleep(1000);
                Kaleidoscope.Start();
                Glitch1.Start();
                    Sound5(30);
                Kaleidoscope.Stop();
                Glitch1.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
                Thread.Sleep(1000);
                Blur1.Start();
                Sound6(30);
                Blur1.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
                Thread.Sleep(1000);
                circles1.Start();
                window1.ShowWindow();
                Sound7(30);
                circles1.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
                Thread.Sleep(1000);
                plgblt5.Start();
                Sound8(30);
                plgblt5.Stop();
                RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
            }
            }
        }

        [DllImport("gdi32.dll")]
        public static extern IntPtr SelectObject([In] IntPtr hdc, [In] IntPtr hgdiobj);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateSolidBrush(uint crColor);

        [DllImport("gdi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool DeleteObject([In] IntPtr hObject);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ReleaseDC(IntPtr hWnd, IntPtr hDC);

        [DllImport("gdi32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool BitBlt([In] IntPtr hdc, int nXDest, int nYDest, int nWidth, int nHeight, [In] IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);

        [DllImport("gdi32.dll")]
        private static extern bool PatBlt(IntPtr hdc, int nXLeft, int nYLeft, int nWidth, int nHeight, CopyPixelOperation dwRop);

        [DllImport("user32.dll")]
        private static extern bool RedrawWindow(IntPtr hWnd, IntPtr lprcUpdate, IntPtr hrgnUpdate, RedrawWindowFlags flags);

        [DllImport("gdi32.dll")]
        static extern bool StretchBlt(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest,
        int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc,
        TernaryRasterOperations dwRop);
        public enum TernaryRasterOperations
        {
            SRCCOPY = 0x00CC0020,
            SRCPAINT = 0x00EE0086,
            SRCAND = 0x008800C6,
            SRCINVERT = 0x00660046,
            SRCERASE = 0x00440328,
            NOTSRCCOPY = 0x00330008,
            NOTSRCERASE = 0x001100A6,
            MERGECOPY = 0x00C000CA,
            MERGEPAINT = 0x00BB0226,
            PATCOPY = 0x00F00021,
            PATPAINT = 0x00FB0A09,
            PATINVERT = 0x005A0049,
            DSTINVERT = 0x00550009,
            BLACKNESS = 0x00000042,
            WHITENESS = 0x00FF0062,
            hmm = 0x00100C85
        };
    }