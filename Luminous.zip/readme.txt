LUMINOUS

Malware Name: Luminous
Works Best In: Windows XP
Made In: C++
Malware Type: Trojan
Damage rate: Destructive
Created By: Minhgotuknight19

This trojan is not a Joke, Do you want to run it?