the source code is broken, except if you go to list32 inside it and go to 095623656757 then go to "source" and you will find it

Thats why i named it "Mission 1"
AND PLEASE DONT ASK ME ABOUT "MISSION 2" OR MORE

if you want the malware then go to Release and you see a file then click on it