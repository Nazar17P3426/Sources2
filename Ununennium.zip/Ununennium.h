// main libs
#include <windows.h> // the Windows API
#include <cmath> // trigonometry
#include <ctime> // time shit
#include <tchar.h>
#include <iostream>
#include <xmmintrin.h> // for the __rdtsc intrinsic

// local libs
#include "Defines.h"
#include "Sounds.h"
#include "Payloads.h"

