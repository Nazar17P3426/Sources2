# x86ASM-Rainbow-Text-
This is a simple &amp; easy program that prints a text with a rainbow color using mode 13h. 
# Screenshot
![GitHub Logo](Screenshot_2.png)
![GitHub Logo](Screenshot.png)
