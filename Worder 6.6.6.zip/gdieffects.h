
#define HGDIAPI WINAPI

int w = GetSystemMetrics(0), h = GetSystemMetrics(1);

void dr(HANDLE hehe) {
	TerminateThread(hehe, 0);
	CloseHandle(hehe);
}

namespace GDI {
	

DWORD HGDIAPI RedScreen(LPVOID lpvd)
{
	HDC hdc;
	HBRUSH hbsh;
	while (1){
		hdc = GetDC(0);
		hbsh = CreateSolidBrush(RGB(255, 0, 0));
		SelectObject(hdc, hbsh);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, MERGECOPY);
		DeleteObject(hbsh);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD HGDIAPI xAxisGlitch(LPVOID lpvd)
{
	HDC hdc;
	while (1){
		hdc = GetDC(0);
		BitBlt(hdc, 0, 0, w, rand () % h, hdc, (rand () % 30) - 15, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD HGDIAPI blurGlitch(LPVOID lpvd)
{
	HDC hdc;
	while (1){
		hdc = GetDC(0);
		BitBlt(hdc, 0, 0, w, rand () % h, hdc, (rand () % 30) - 15, 0, SRCAND);
		BitBlt(hdc, 0, 0, rand () % w, h, hdc, 0, (rand () % 30) - 15, SRCPAINT);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD HGDIAPI ErrorRing(LPVOID lpvd)
{
	HDC hdc;
	double radius = 0.0;
	while (1) {
		hdc = GetDC(0);
		int x = (cos(radius) * 500) - 650, y = (sin(radius) * 500) - 350;
		DrawIcon(hdc, x + w + 50, y + h, LoadIcon(NULL, IDI_ERROR));
		radius += 0.05;
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD HGDIAPI InvCC(LPVOID lpvd)
{
	HDC hdc;
	int rw, rh;
	int tw, th, bw, bh;
//	HRGN rgn;
	while (1) {
		hdc = GetDC(0);
		rw = rand () % w, rh = rand () % h;
		tw = 0 + rw, th = 0 + rh, bw = 100 + rw, bh = 100 + rh;
		InvertRgn(hdc, CreateEllipticRgn(tw, th, bw, bh));
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD HGDIAPI EraseShake(LPVOID lpvd)
{
	HDC hdc;
	while (1) {
		hdc = GetDC(0);
		BitBlt(hdc, rand () % 10, rand () % 10, w, h, hdc, rand () % 10, rand () % 10, SRCERASE);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD HGDIAPI TrainGlitch(LPVOID lpvd)
{
	HDC hdc;
	while (1) {
		hdc = GetDC(0);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		BitBlt(hdc, rand () % w, rand () % h, rand () % w, rand () % h, hdc, rand () % w, rand () % h, NOTSRCERASE);
		BitBlt(hdc, 0, -30, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, 0, h - 30, w, h, hdc, 0, 0, NOTSRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

DWORD HGDIAPI MadText(LPVOID lpvd)
{
	HDC hdc;
	HFONT hfnt;
	while (1) {
		hdc = GetDC(0);
		LPCSTR lpStrings[] = {"Worder", "Tubercomi", "666"};
		int iStringOutput = rand () % 3;
		hfnt = CreateFont(40, 20, 0, 0, FW_BOLD, false, false, false, ANSI_CHARSET, 0, 0, 0, 0, "Impact");
		SelectObject(hdc, hfnt);
		SetTextColor(hdc, PALETTERGB(255, 0, 0));
		SetBkColor(hdc, PALETTERGB(0, 0, 0));
		BitBlt(hdc, rand () % 50, rand () % 50, w, h, hdc, rand () % 50, rand () % 50, SRCERASE);
		TextOutA(hdc, rand () % w, rand () % h, lpStrings[iStringOutput], strlen(lpStrings[iStringOutput]));
		DeleteObject(hfnt);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}

}
