#include <windows.h>
#include <cmath>
#include "gdieffects.h"
//#include "payloads.h"

EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBYTE);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS ntStatus, ULONG ulParams, ULONG ustrParam, PULONG Params, ULONG vResponse, PULONG response);

int WINAPI WinMain(HINSTANCE hinst, HINSTANCE hpinst, LPSTR lps, int n) {
	Sleep(3000);
	if (MessageBoxW(NULL, L"WORDER 6.6.6\r\n\r\nYou\'re about to run a destructive piece of software.\r\nPress Yes to continue.\r\nPress No to exit.", L"", MB_ICONWARNING|MB_YESNO) == IDNO)
	{
		return 0;
	}
	else
	{
//		System::KillMBR();
//		System::Disabler();
		Sleep(15000);
		HANDLE gdi = CreateThread(NULL, 0, GDI::RedScreen, NULL, 0, 0);
		Sleep(2000);
		HANDLE gdi1 = CreateThread(NULL, 0, GDI::xAxisGlitch, NULL, 0, 0);
		Sleep(25000);
		dr(gdi1);
		InvalidateRect(0, 0, 0);
		HANDLE gdi2 = CreateThread(NULL, 0, GDI::blurGlitch, NULL, 0, 0);
		Sleep(25000);
		dr(gdi2);
		InvalidateRect(0, 0, 0);
		HANDLE gdi3 = CreateThread(NULL, 0, GDI::ErrorRing, NULL, 0, 0);
		HANDLE gdi3b = CreateThread(NULL, 0, GDI::InvCC, NULL, 0, 0);
		Sleep(25000);
		dr(gdi3); dr(gdi3b);
		InvalidateRect(0, 0, 0);
		HANDLE gdi4 = CreateThread(NULL, 0, GDI::EraseShake, NULL, 0, 0);
		Sleep(30000);
		dr(gdi4);
		InvalidateRect(0, 0, 0);
		HANDLE gdi5 = CreateThread(NULL, 0, GDI::TrainGlitch, NULL, 0, 0);
		Sleep(30000);
		dr(gdi5);
		InvalidateRect(0, 0, 0);
		HANDLE gdi6 = CreateThread(NULL, 0, GDI::MadText, NULL, 0, 0);
		Sleep(30000);
		/* BYTE bt;
		ULONG rsp;
		RtlAdjustPrivilege(19, true, false, &bt);
		NtRaiseHardError(0xC0000135, 0, 0, 0, 6, &rsp);
		Sleep(-1); */
	}
}
