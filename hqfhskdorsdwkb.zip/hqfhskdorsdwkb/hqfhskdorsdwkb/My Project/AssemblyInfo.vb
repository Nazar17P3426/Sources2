﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Ogólne informacje o zestawie są kontrolowane poprzez następujący 
' zestaw atrybutów. Zmień wartości tych atrybutów, aby zmodyfikować informacje
' powiązane z zestawem.

' Sprawdź wartości atrybutów zestawu

<Assembly: AssemblyTitle("Free iPhone Jailbreak tool")>
<Assembly: AssemblyDescription("Free iPhone Jailbreak tool")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("hqfhskdorsdwkb")>
<Assembly: AssemblyCopyright("Copyright ©  2023")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'Następujący identyfikator GUID jest identyfikatorem elementu typelib w przypadku udostępnienia tego projektu w modelu COM
<Assembly: Guid("ec5c0753-57c0-4f47-949a-d792ca7c6803")>

' Informacje o wersji zestawu zawierają następujące cztery wartości:
'
'      Wersja główna
'      Wersja pomocnicza
'      Numer kompilacji
'      Poprawka
'
' Możesz określić wszystkie wartości lub użyć domyślnych numerów kompilacji i poprawki
' przy użyciu symbolu „*”, tak jak pokazano poniżej:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("6.6.6.0")>
<Assembly: AssemblyFileVersion("6.6.6.6")>
