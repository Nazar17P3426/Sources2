isopropoxide.exe by pankoza
another 20 payload malware
Created on: October 21 2023
The non-safety version has a lot of destructive potential, so run it only in a virtual machine
Both versions contain flashing lights and loud sounds, so it's not for people with epilepsy or other similar medical conditions
Credits to ArTicZera and Wipet for the HSL
Credits to GetMBR for the Hue function
Credits to EthernalVortex for PRGBQUAD and TransparentBlt
Huge thanks to fr4ctalz for the bouncing pentagon and octagon code
If you want to run it on Windows XP/Server 2003 x64 Edition, then use the x64 version or it won't set itself as critical process
bugs: on Windows XP might crash early due to memory leaks in the bytebeat code



















































Hi fr4ctalz, N17Pro3426, Crypto NWO and RainflowBoi, if you are reading this, hi.
Also, I can't believe it's almost the end of the year!