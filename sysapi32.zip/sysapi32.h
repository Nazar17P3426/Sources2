#include <Windows.h>

typedef union _RGBQUAD {
	COLORREF rgb;
	
	struct {
		
		BYTE r;
		
		BYTE g;
		
		BYTE b;
		
		BYTE unused;
	};
}*PRGBQUAD;

COLORREF GetRandomRainbowSpectrum() {
	int color = rand () % 7;
	if (color == 0) {
		return RGB(255, 0, 0); // red
	}
	if (color == 1) {
		return RGB(255, 150, 0); // orange
	}
	if (color == 2) {
		return RGB(255, 255, 0); // yellow
	}
	if (color == 3) {
		return RGB(0, 255, 0); // green
	}
	if (color == 4) {
		return RGB(0, 255, 255); // cyan
	}
	if (color == 5) {
		return RGB(0, 0, 255); // blue
	}
	if (color == 6) {
		return RGB(255, 0, 255); // magenta
	}
}
